
'use client';

import { 
    doc, 
    setDoc, 
    deleteDoc, 
    collection, 
    writeBatch,
    query,
    where,
    getDocs,
    getDoc
} from 'firebase/firestore';
import { firestore } from '@/firebase/client';
import type { CustomTest, PatientCode, Supervisor, Therapist, ClinicalInfo, TestResult, ScheduledReminder, TherapistInfo, SpecialtyCategory, AppConfig } from './definitions';

// Generic save function
async function saveData<T extends { id: string }>(collectionName: string, data: T, isNew: boolean): Promise<void> {
    const docRef = doc(firestore, collectionName, data.id);
    await setDoc(docRef, data, { merge: !isNew });
}

// --- App Config ---
export async function saveAppConfig(config: Partial<AppConfig>): Promise<void> {
    const docRef = doc(firestore, 'appConfig', 'main');
    await setDoc(docRef, config, { merge: true });
}

// --- Test Management ---
export async function saveTest(test: CustomTest, isNew: boolean): Promise<void> {
    return saveData('psychologicalTests', test, isNew);
}

export async function deleteTest(testId: string): Promise<void> {
    const docRef = doc(firestore, 'psychologicalTests', testId);
    await deleteDoc(docRef);
}


// --- Professional (Roles) Management ---
export async function saveProfessional(professional: Supervisor | Therapist, role: 'supervisor' | 'therapist', isNew: boolean): Promise<void> {
    const collectionName = role === 'supervisor' ? 'supervisors' : 'therapists';
    return saveData(collectionName, professional, isNew);
}

export async function deleteProfessional(id: string, role: 'supervisor' | 'therapist'): Promise<void> {
    const collectionName = role === 'supervisor' ? 'supervisors' : 'therapists';
    const docRef = doc(firestore, collectionName, id);
    await deleteDoc(docRef);
}


// --- Patient Code Management ---
export async function savePatientCode(patientCode: PatientCode): Promise<void> {
    return saveData('patientAccessCodes', patientCode, true);
}

export async function updatePatientCode(patientCode: PatientCode): Promise<void> {
    return saveData('patientAccessCodes', patientCode, false);
}

export async function deletePatientCode(codeId: string): Promise<void> {
    const docRef = doc(firestore, 'patientAccessCodes', codeId);
    await deleteDoc(docRef);
}

// --- Clinical Info Management ---
export async function saveClinicalInfo(info: ClinicalInfo): Promise<void> {
    return saveData('clinicalInfo', info, false); // Always merge/update
}

// --- Therapist Info Management ---
export async function saveTherapistInfo(info: TherapistInfo): Promise<void> {
    return saveData('therapistInfo', info, false);
}

// --- Specialty Category Management ---
export async function saveSpecialtyCategory(category: SpecialtyCategory): Promise<void> {
    return saveData('specialtyCategories', category, true);
}


// --- Test Result Management ---
export async function saveTestResult(result: TestResult): Promise<void> {
    return saveData('testResults', result, true);
}

export async function deleteTestResult(resultId: string): Promise<void> {
    const docRef = doc(firestore, 'testResults', resultId);
    await deleteDoc(docRef);
}

// --- Scheduled Reminder Management ---
export async function saveScheduledReminder(reminder: ScheduledReminder): Promise<void> {
    return saveData('scheduledReminders', reminder, true);
}

export async function updateScheduledReminder(reminder: ScheduledReminder): Promise<void> {
    return saveData('scheduledReminders', reminder, false);
}

// --- Patient Case Merging ---
export async function mergePatientCases(sourcePatientName: string, targetPatientName: string): Promise<void> {
    const batch = writeBatch(firestore);

    // 1. Re-assign TestResults
    const testResultsQuery = query(collection(firestore, 'testResults'), where('patient_name', '==', sourcePatientName));
    const testResultsSnapshot = await getDocs(testResultsQuery);
    testResultsSnapshot.forEach(doc => {
        batch.update(doc.ref, { patient_name: targetPatientName });
    });

    // 2. Re-assign ScheduledReminders
    const remindersQuery = query(collection(firestore, 'scheduledReminders'), where('patientName', '==', sourcePatientName));
    const remindersSnapshot = await getDocs(remindersQuery);
    remindersSnapshot.forEach(doc => {
        batch.update(doc.ref, { patientName: targetPatientName });
    });

    // 3. Merge ClinicalInfo
    const sourceInfoRef = doc(firestore, 'clinicalInfo', sourcePatientName);
    const targetInfoRef = doc(firestore, 'clinicalInfo', targetPatientName);

    const [sourceInfoSnap, targetInfoSnap] = await Promise.all([
        getDoc(sourceInfoRef),
        getDoc(targetInfoRef),
    ]);

    if (sourceInfoSnap.exists()) {
        const sourceInfo = sourceInfoSnap.data() as ClinicalInfo;
        const targetInfo = targetInfoSnap.exists() ? targetInfoSnap.data() as ClinicalInfo : {
            id: targetPatientName,
            workObjectives: '',
            diagnosis: '',
            notes: '',
            processStatus: 'en-proceso',
        } as Partial<ClinicalInfo>;

        const mergedNotes = [
            targetInfo.notes,
            `\n\n--- DATOS UNIFICADOS DE ${sourcePatientName} EL ${new Date().toLocaleDateString()} ---\n`,
            `Objetivos de Trabajo Anteriores: ${sourceInfo.workObjectives || 'N/A'}`,
            `Diagnóstico Anterior: ${sourceInfo.diagnosis || 'N/A'}`,
            `Notas Anteriores: ${sourceInfo.notes || 'N/A'}`
        ].filter(Boolean).join('\n').trim();

        const updatedTargetInfo: ClinicalInfo = {
            id: targetPatientName,
            notes: mergedNotes,
            workObjectives: targetInfo.workObjectives || '',
            diagnosis: targetInfo.diagnosis || '',
            processStatus: targetInfo.processStatus || 'en-proceso',
            lastUpdated: new Date().toISOString(),
        };

        batch.set(targetInfoRef, updatedTargetInfo, { merge: true });
        batch.delete(sourceInfoRef);
    }
    
    // 4. Delete source PatientAccessCode
    const codesQuery = query(collection(firestore, 'patientAccessCodes'), where('patientName', '==', sourcePatientName));
    const codesSnapshot = await getDocs(codesQuery);
    codesSnapshot.forEach(doc => {
        batch.delete(doc.ref);
    });

    // Commit all changes at once
    await batch.commit();
}


// --- Professional Profile Merging ---
export async function mergeProfessionals(sourceId: string, targetId: string): Promise<void> {
    const batch = writeBatch(firestore);

    // Determine the roles of source and target professionals
    const therapistSourceRef = doc(firestore, 'therapists', sourceId);
    const supervisorSourceRef = doc(firestore, 'supervisors', sourceId);
    const therapistTargetRef = doc(firestore, 'therapists', targetId);
    const supervisorTargetRef = doc(firestore, 'supervisors', targetId);

    const [
        therapistSourceSnap,
        supervisorSourceSnap,
        therapistTargetSnap,
        supervisorTargetSnap,
    ] = await Promise.all([
        getDoc(therapistSourceRef),
        getDoc(supervisorSourceRef),
        getDoc(therapistTargetRef),
        getDoc(supervisorTargetRef),
    ]);

    const sourceIsTherapist = therapistSourceSnap.exists();
    const sourceIsSupervisor = supervisorSourceSnap.exists();
    const targetIsTherapist = therapistTargetSnap.exists();
    const targetIsSupervisor = supervisorTargetSnap.exists();

    if (!sourceIsTherapist && !sourceIsSupervisor) throw new Error("El profesional de origen no existe.");
    if (!targetIsTherapist && !targetIsSupervisor) throw new Error("El profesional de destino no existe.");
    if (sourceIsTherapist && !targetIsTherapist) throw new Error("El profesional de origen es un terapeuta, pero el de destino no.");
    if (sourceIsSupervisor && !targetIsSupervisor) throw new Error("El profesional de origen es un supervisor, pero el de destino no.");

    if (sourceIsTherapist) {
        // --- MERGING THERAPISTS ---
        // 1. Re-assign PatientAccessCodes
        const codesQuery = query(collection(firestore, 'patientAccessCodes'), where('assignedTherapist', '==', sourceId));
        const codesSnapshot = await getDocs(codesQuery);
        codesSnapshot.forEach(doc => batch.update(doc.ref, { assignedTherapist: targetId }));

        // 2. Re-assign TestResults
        const resultsQuery = query(collection(firestore, 'testResults'), where('assigned_therapist', '==', sourceId));
        const resultsSnapshot = await getDocs(resultsQuery);
        resultsSnapshot.forEach(doc => batch.update(doc.ref, { assigned_therapist: targetId }));

        // 3. Update Supervisor assignments
        const supervisorsQuery = query(collection(firestore, 'supervisors'), where('assignedTherapists', 'array-contains', sourceId));
        const supervisorsSnapshot = await getDocs(supervisorsQuery);
        supervisorsSnapshot.forEach(supervisorDoc => {
            const supervisor = supervisorDoc.data() as Supervisor;
            const updatedTherapists = [...new Set([...supervisor.assignedTherapists.filter(id => id !== sourceId), targetId])];
            batch.update(supervisorDoc.ref, { assignedTherapists: updatedTherapists });
        });
        
        // 4. For simplicity, we just delete the source TherapistInfo. The user can re-enter it for the target.
        const sourceInfoRef = doc(firestore, 'therapistInfo', sourceId);
        const sourceInfoSnap = await getDoc(sourceInfoRef);
        if (sourceInfoSnap.exists()) {
            batch.delete(sourceInfoRef);
        }

        // 5. Delete source therapist document
        batch.delete(therapistSourceRef);

    } else if (sourceIsSupervisor) {
        // --- MERGING SUPERVISORS ---
        const sourceSupervisor = supervisorSourceSnap.data() as Supervisor;
        const targetSupervisor = supervisorTargetSnap.data() as Supervisor;

        // 1. Merge assignedTherapists lists
        const mergedTherapists = [...new Set([...sourceSupervisor.assignedTherapists, ...targetSupervisor.assignedTherapists])];
        batch.update(supervisorTargetRef, { assignedTherapists: mergedTherapists });

        // 2. Delete source supervisor document
        batch.delete(supervisorSourceRef);
    }

    // Commit all batched writes
    await batch.commit();
}
