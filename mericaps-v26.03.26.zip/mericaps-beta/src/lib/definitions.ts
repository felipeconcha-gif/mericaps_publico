
export type Question = {
  id: string;
  label: string;
  color: string;
  type: 'slider' | 'image_slider' | 'multiple_choice' | 'text' | 'number' | 'likert' | 'yes_no';
  config: {
    required?: boolean;
    // Slider & Image Slider
    min?: number;
    max?: number;
    step?: number;
    defaultValue?: number;
    // Standard Slider labels
    minLabel?: string;
    maxLabel?: string;
    // Image Slider labels and images
    minImageLabel?: string;
    maxImageLabel?: string;
    minImageUrl?: string;
    maxImageUrl?: string;
    // Multiple Choice
    options?: string[];
    allowMultiple?: boolean;
    // Text
    placeholder?: string;
    // Number
    unit?: string;
    // Likert
    likertOptions?: string[];
  };
  // Scoring properties
  scoring?: 'direct' | 'inverse';
  weighted?: boolean;
  weight?: number;
  // Alerting
  alertEnabled?: boolean;
  alertThreshold?: number;
};

export type PredefinedTest = {
  name: string;
  fields: Omit<Question, 'type' | 'config'>[];
};

export type ScoreCalculation = {
  method: 'sum' | 'average' | 'none';
};

export type CustomTest = {
  id: string;
  name: string;
  instructions?: string;
  fields: Question[];
  cutoffScore?: number | null;
  scoreCalculation: ScoreCalculation;
  created: string;
  isPredefined?: boolean;
};

export type PatientCode = {
  id: string;
  code: string;
  patientName: string;
  patientEmail: string | null;
  assignedTests: string[];
  assignedTherapist: string; // Changed from assignedSupervisor
  expiry: string | null;
  maxUses: number | null;
  created: string;
  usedCount: number;
  lastUsed: string | null;
  autoCreated?: boolean;
};

export type Therapist = {
  id: string;
  code: string;
  name: string;
  email: string | null;
  department: string | null;
  expiry: string | null;
  created: string;
};

export type Supervisor = {
  id: string;
  code: string;
  name: string;
  email: string | null;
  department: string | null;
  assignedTherapists: string[]; // Changed from assignedPatients
  expiry: string | null;
  created: string;
};

export type Professional = Therapist | Supervisor;

export type TestResult = {
  id: string;
  patient_name: string;
  test_date: string;
  session_date: string;
  test_type: string;
  session_status: 'completed' | 'not-completed';
  not_completed_reason: string;
  other_reason_text: string;
  scores: Record<string, number | string | string[]>;
  finalScore?: number;
  notes: string;
  source: 'professional' | 'patient_code';
  patient_code?: string;
  assigned_therapist: string; // Changed from assigned_supervisor
};

export type ClinicalInfo = {
  id: string; // patientName
  workObjectives: string;
  diagnosis: string;
  notes: string;
  processStatus: 'en-proceso' | 'proceso-cerrado';
  lastUpdated: string;
  weeklyTasks?: string;
  sessionMaterialLink?: string;
};

export type TherapistInfo = {
  id: string; // therapistId
  personalNotes: string;
  trainingObjectives: string;
  evaluations: string;
  academicInfo: string;
  continuingEducation: string;
  linkedinUrl?: string;
  socialMediaUrl?: string;
  specialties: string[];
  quickAccessTests?: string[];
  defaultTestVariables?: Record<string, string[]>;
  lastUpdated: string;
};

export type SpecialtyCategory = {
    id: string;
    name: string;
    createdBy: string;
};

export type User = {
  id: string;
  role: 'admin' | 'supervisor' | 'therapist' | 'patient';
  name: string;
  data: PatientCode | Supervisor | Therapist | { id: 'admin'; name: 'Admin' };
};

export type ScheduledReminder = {
  id: string;
  patientName: string;
  patientEmail: string | null;
  sendDate: string;
  status: 'pending' | 'sent';
  created: string;
};

export type ThemeSettings = {
  primary: string; // HSL value like "244 81% 60%"
  background: string;
  accent: string;
  logoUrl: string;
};

export type AppConfig = {
  hiddenTests?: string[];
  themeSettings?: ThemeSettings;
};
