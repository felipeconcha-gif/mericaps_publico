import { clsx, type ClassValue } from "clsx"
import { twMerge } from "tailwind-merge"
import type { ScoreCalculation } from "./definitions";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

export function calculateFinalScore(
  scores: Record<string, number | string | string[]>,
  calculation?: ScoreCalculation
): number | undefined {
  if (!calculation || calculation.method === 'none') {
    return undefined;
  }

  const numericScores = Object.values(scores).map(Number).filter(v => !isNaN(v));
  if (numericScores.length === 0) {
    return 0;
  }

  switch (calculation.method) {
    case 'sum':
      return numericScores.reduce((acc, val) => acc + val, 0);
    case 'average':
      return numericScores.reduce((acc, val) => acc + val, 0) / numericScores.length;
    default:
      return undefined;
  }
}
