"use client";

import * as React from 'react';
import { Skeleton } from '@/components/ui/skeleton';

export function ThemeProvider({ children }: { children: React.ReactNode }) {
  // The theme settings are now managed in page.tsx with useLocalStorage
  // This provider is now just a pass-through to avoid breaking imports.
  // The actual theme logic is applied via useEffect in the Home component.
  
  // A check could be added here if needed, but for now we simplify.
  // The isMounted check in page.tsx handles the initial render skeleton.
  
  return <>{children}</>;
}
