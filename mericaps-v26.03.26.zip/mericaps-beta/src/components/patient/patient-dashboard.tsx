
"use client";

import { useState } from 'react';
import type { User, CustomTest, PatientCode, TestResult, ClinicalInfo } from '@/lib/definitions';
import { PatientTestSelection } from './patient-test-selection';
import { PatientTestInterface } from './patient-test-interface';
import { Button } from '@/components/ui/button';
import { LogOut, BookOpen, CheckSquare } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { saveTestResult, updatePatientCode } from '@/lib/firestore-actions';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';

type AppState = {
  customTests: CustomTest[];
  clinicalInfo: Record<string, ClinicalInfo>;
};

interface PatientDashboardProps {
  user: User;
  onLogout: () => void;
  appState: AppState;
}

export function PatientDashboard({ user, onLogout, appState }: PatientDashboardProps) {
  const [currentView, setCurrentView] = useState<'selection' | 'test' | 'success'>('selection');
  const [selectedTestType, setSelectedTestType] = useState<string | null>(null);
  const { toast } = useToast();

  if (user.role !== 'patient') {
    return null;
  }
  const patientData = user.data as PatientCode;
  const patientClinicalInfo = appState.clinicalInfo?.[patientData.patientName];


  const startTest = (testType: string) => {
    setSelectedTestType(testType);
    setCurrentView('test');
  };

  const handleTestSubmit = async (result: TestResult) => {
    try {
        await saveTestResult(result);

        const updatedPatientData = {
            ...patientData,
            usedCount: (patientData.usedCount || 0) + 1,
            lastUsed: new Date().toISOString(),
        };

        await updatePatientCode(updatedPatientData);

        setCurrentView('success');
        toast({
          title: "¡Test Enviado Exitosamente!",
          description: "Gracias por completar el test. Tu terapeuta recibirá los resultados.",
          className: "bg-green-100 border-green-300 text-green-800"
        });
    } catch (error) {
        console.error("Error submitting test:", error);
        toast({
            variant: "destructive",
            title: "Error al enviar",
            description: "No se pudo guardar tu test. Por favor, intenta de nuevo."
        });
    }
  };

  const backToSelection = () => {
    setSelectedTestType(null);
    setCurrentView('selection');
  };

  const renderSelectionView = () => (
    <div className="space-y-8">
        <div className="grid md:grid-cols-2 gap-6">
            <Card className="flex flex-col">
                <CardHeader>
                    <CardTitle className="flex items-center gap-2"><BookOpen className="h-6 w-6 text-primary"/> Objetivo Terapéutico</CardTitle>
                </CardHeader>
                <CardContent className="flex-grow">
                    <p className="text-muted-foreground">{patientClinicalInfo?.workObjectives || 'Tu terapeuta aún no ha definido un objetivo.'}</p>
                </CardContent>
            </Card>
            <Card className="flex flex-col">
                <CardHeader>
                    <CardTitle className="flex items-center gap-2"><CheckSquare className="h-6 w-6 text-primary"/> Tareas de la Semana</CardTitle>
                </CardHeader>
                <CardContent className="flex-grow">
                     <p className="text-muted-foreground whitespace-pre-wrap">{patientClinicalInfo?.weeklyTasks || 'No tienes tareas asignadas para esta semana.'}</p>
                </CardContent>
                 {patientClinicalInfo?.sessionMaterialLink && (
                    <div className="p-6 pt-0">
                        <Button asChild className="w-full">
                            <a href={patientClinicalInfo.sessionMaterialLink} target="_blank" rel="noopener noreferrer">
                                Ver Material de Sesión
                            </a>
                        </Button>
                    </div>
                 )}
            </Card>
        </div>

        <PatientTestSelection 
            patientData={patientData} 
            onStartTest={startTest}
            customTests={appState.customTests}
        />
    </div>
  );


  return (
    <div className="w-full">
        <div className="flex justify-end mb-4">
             <Button onClick={onLogout} variant="ghost" className="text-primary/70 hover:text-primary">
                <LogOut className="mr-2 h-4 w-4" /> Cambiar Código
            </Button>
        </div>

        {currentView === 'selection' && renderSelectionView()}

        {currentView === 'test' && selectedTestType && (
            <PatientTestInterface
                patientData={patientData}
                testType={selectedTestType}
                customTests={appState.customTests}
                onSubmit={handleTestSubmit}
                onBack={backToSelection}
            />
        )}
        
        {currentView === 'success' && (
             <div className="bg-white rounded-xl shadow-lg p-8 text-center">
                <div className="text-6xl mb-4">✅</div>
                <h3 className="text-2xl font-bold text-green-600 mb-4">¡Test Enviado Exitosamente!</h3>
                <p className="text-gray-600 mb-6">Gracias por completar el test. Tu terapeuta recibirá los resultados.</p>
                <Button onClick={backToSelection}>
                    Completar Otro Test
                </Button>
            </div>
        )}
    </div>
  );
}
