"use client";

import type { CustomTest, PatientCode } from '@/lib/definitions';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { BrainCircuit, Badge } from 'lucide-react';

interface PatientTestSelectionProps {
  patientData: PatientCode;
  onStartTest: (testType: string) => void;
  customTests: CustomTest[];
}

export function PatientTestSelection({ patientData, onStartTest, customTests }: PatientTestSelectionProps) {
  if (!patientData.assignedTests || patientData.assignedTests.length === 0) {
    return (
      <Card className="shadow-lg">
        <CardHeader className="text-center">
          <div className="text-6xl mb-4 mx-auto w-fit">👋</div>
          <CardTitle className="text-3xl font-bold text-gray-800">¡Hola, {patientData.patientName}!</CardTitle>
          <CardDescription>No tienes tests asignados para completar en este momento.</CardDescription>
        </CardHeader>
        <CardContent className="text-center">
            <div className="bg-primary/5 border border-primary/10 rounded-lg p-4">
                <p className="text-sm text-primary/80"><strong>Código:</strong> <span className="font-code">{patientData.code}</span></p>
            </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="shadow-lg">
      <CardHeader className="text-center">
        <div className="text-6xl mb-4 mx-auto w-fit">👋</div>
        <CardTitle className="text-3xl font-bold text-gray-800">¡Hola, {patientData.patientName}!</CardTitle>
        <CardDescription>Tienes los siguientes tests asignados para completar.</CardDescription>
        <div className="bg-primary/5 border border-primary/10 rounded-lg p-4 mt-4 w-fit mx-auto">
            <p className="text-sm text-primary/80 flex items-center gap-2"><Badge className="h-5 w-5"/><strong>Código:</strong> <span className="font-code">{patientData.code}</span></p>
        </div>
      </CardHeader>
      <CardContent>
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {patientData.assignedTests.map((testId) => {
            const testConfig = customTests.find((t) => t.id === testId);

            if (!testConfig) return null;

            return (
              <button
                key={testId}
                onClick={() => onStartTest(testId)}
                className="test-option text-left p-6 border-2 border-gray-200 rounded-xl hover:border-primary hover:bg-primary/5 transition-all focus:outline-none focus:ring-2 focus:ring-ring"
              >
                <div className="text-4xl mb-3 text-primary">
                  <BrainCircuit />
                </div>
                <h3 className="font-semibold text-gray-800 mb-2">{testConfig.name}</h3>
                <p className="text-sm text-gray-600">{testConfig.fields.length} preguntas</p>
                {testConfig.id.startsWith('custom_') && <div className="mt-2 text-xs text-primary/70 bg-primary/10 px-2 py-1 rounded-full w-fit">Personalizado</div>}
              </button>
            );
          })}
        </div>
      </CardContent>
    </Card>
  );
}
