
"use client";

import { useState } from 'react';
import type { CustomTest, PatientCode, TestResult, Question } from '@/lib/definitions';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { ArrowLeft, Brain, AlertTriangle, Smile, Frown } from 'lucide-react';
import { Slider } from '@/components/ui/slider';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Checkbox } from '@/components/ui/checkbox';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { calculateFinalScore } from '@/lib/utils';
import { useToast } from '@/hooks/use-toast';
import Image from 'next/image';
import { format } from 'date-fns';


interface PatientTestInterfaceProps {
  patientData: PatientCode;
  testType: string;
  customTests: CustomTest[];
  onSubmit: (result: TestResult) => void;
  onBack: () => void;
}

type Scores = Record<string, number | string | string[]>;

export function PatientTestInterface({ patientData, testType, customTests, onSubmit, onBack }: PatientTestInterfaceProps) {
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();
  
  const testConfig = customTests.find((t) => t.id === testType);

  const getInitialValue = (field: Question) => {
    switch (field.type) {
      case 'slider':
      case 'image_slider':
        return field.config?.defaultValue ?? 5;
      case 'multiple_choice':
        return [];
      case 'yes_no':
      case 'likert':
      case 'text':
      case 'number':
      default:
        return '';
    }
  }

  const initialScores: Scores = testConfig?.fields.reduce((acc, field) => {
    acc[field.id] = getInitialValue(field);
    return acc;
  }, {} as Scores) ?? {};
  
  const [scores, setScores] = useState<Scores>(initialScores);
  
  if (!testConfig) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Error</CardTitle>
        </CardHeader>
        <CardContent>
          <p>No se pudo cargar el test. Por favor, vuelve a intentarlo.</p>
          <Button onClick={onBack} className="mt-4">Volver</Button>
        </CardContent>
      </Card>
    );
  }
  
  const handleValueChange = (id: string, value: number | string | string[]) => {
    setScores(prev => ({ ...prev, [id]: value }));
  };

  const handleMultipleChoiceChange = (id: string, option: string, isChecked: boolean) => {
    const currentSelection = (scores[id] as string[] || []);
    let newSelection;
    if(isChecked) {
      newSelection = [...currentSelection, option];
    } else {
      newSelection = currentSelection.filter(item => item !== option);
    }
    handleValueChange(id, newSelection);
  }
  
  const checkAlerts = (scores: Scores, test: CustomTest, patientName: string) => {
    for (const field of test.fields) {
        if (field.alertEnabled && typeof field.alertThreshold === 'number') {
            const scoreValue = scores[field.id];
            const numericScore = Number(scoreValue);
            
            if (!isNaN(numericScore) && numericScore >= field.alertThreshold) {
                toast({
                    variant: "destructive",
                    title: `🔴 Alerta de Riesgo Inmediato`,
                    description: `El paciente ${patientName} ha superado el umbral de alerta en la pregunta "${field.label}" del test "${test.name}". Se requiere atención profesional.`,
                    duration: 20000,
                });
            }
        }
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);

    const notesElement = document.getElementById('patient-notes') as HTMLTextAreaElement;
    const patientNotes = notesElement.value.trim();
    const notesText = patientNotes 
      ? `Test completado por el paciente usando código ${patientData.code}. Comentarios: ${patientNotes}`
      : `Test completado por el paciente usando código ${patientData.code}.`;
    
    const finalScore = calculateFinalScore(scores, testConfig.scoreCalculation);
    
    checkAlerts(scores, testConfig, patientData.patientName);

    const result: TestResult = {
      id: `${Date.now()}-${patientData.id}`,
      patient_name: patientData.patientName,
      test_date: new Date().toISOString(),
      session_date: format(new Date(), 'yyyy-MM-dd'),
      test_type: testType,
      session_status: 'completed',
      not_completed_reason: '',
      other_reason_text: '',
      scores: scores,
      finalScore: finalScore,
      notes: notesText,
      source: 'patient_code',
      patient_code: patientData.code,
      assigned_therapist: patientData.assignedTherapist,
    };
    
    setTimeout(() => {
      onSubmit(result);
      setIsLoading(false);
    }, 500);
  };

  const renderQuestionField = (field: Question) => {
    const value = scores[field.id];
    const numericValue = typeof value === 'number' ? value : (field.config?.defaultValue ?? 5);

    switch (field.type) {
      case 'image_slider':
        return (
          <>
            <div className="flex justify-between text-sm text-center text-gray-500 mb-2">
              <span className="w-2/5">{field.config?.minImageLabel}</span>
              <span className="w-1/5"></span>
              <span className="w-2/5">{field.config?.maxImageLabel}</span>
            </div>
            <div className="flex items-center gap-4">
                {field.config?.minImageUrl ? <Image src={field.config.minImageUrl} alt={field.config.minImageLabel || 'Min'} width={40} height={40} unoptimized /> : <Frown className="h-10 w-10 text-muted-foreground"/>}
                <Slider
                  id={`patient-${field.id}`}
                  min={field.config?.min ?? 1}
                  max={field.config?.max ?? 10}
                  step={field.config?.step ?? 1}
                  value={[numericValue]}
                  onValueChange={(val) => handleValueChange(field.id, val[0])}
                  className="w-full"
                />
                {field.config?.maxImageUrl ? <Image src={field.config.maxImageUrl} alt={field.config.maxImageLabel || 'Max'} width={40} height={40} unoptimized /> : <Smile className="h-10 w-10 text-muted-foreground"/>}
            </div>
            <div className="text-center font-bold text-lg mt-2" style={{ color: field.color }}>
                {numericValue.toFixed(field.config?.step && field.config.step < 1 ? 1 : 0)}
            </div>
          </>
        );
      case 'slider':
        return (
          <>
            <Slider
              id={`patient-${field.id}`}
              min={field.config?.min ?? 1}
              max={field.config?.max ?? 10}
              step={field.config?.step ?? 1}
              value={[numericValue]}
              onValueChange={(val) => handleValueChange(field.id, val[0])}
              className="w-full"
            />
            <div className="flex justify-between text-sm text-gray-500 mt-2">
              <span>{field.config?.minLabel ?? (field.config?.min ?? 1)}</span>
              <span className="font-bold text-lg" style={{ color: field.color }}>
                {numericValue.toFixed(field.config?.step && field.config.step < 1 ? 1 : 0)}
              </span>
              <span>{field.config?.maxLabel ?? (field.config?.max ?? 10)}</span>
            </div>
          </>
        );
      case 'likert':
        const likertOptions = field.config?.likertOptions || ['Totalmente en desacuerdo', 'En desacuerdo', 'Neutral', 'De acuerdo', 'Totalmente de acuerdo'];
        return (
          <RadioGroup
            value={value as string}
            onValueChange={(val) => handleValueChange(field.id, val)}
            className="flex flex-col sm:flex-row sm:flex-wrap justify-center gap-x-6 gap-y-4"
          >
            {likertOptions.map((option, index) => (
              <div key={option} className="flex items-center space-x-2">
                 <RadioGroupItem value={String(index + 1)} id={`${field.id}-${index}`} />
                 <Label htmlFor={`${field.id}-${index}`} className="font-normal cursor-pointer">{option}</Label>
              </div>
            ))}
          </RadioGroup>
        );
      case 'multiple_choice':
        return (
          <div className="space-y-2">
            {field.config?.options?.map(option => (
              <div key={option} className="flex items-center space-x-2">
                <Checkbox
                  id={`${field.id}-${option}`}
                  checked={(value as string[]).includes(option)}
                  onCheckedChange={(checked) => handleMultipleChoiceChange(field.id, option, !!checked)}
                />
                <label htmlFor={`${field.id}-${option}`} className="text-sm font-medium leading-none">
                  {option}
                </label>
              </div>
            ))}
          </div>
        );
      case 'text':
        return (
          <Textarea
            id={`patient-${field.id}`}
            value={value as string}
            onChange={e => handleValueChange(field.id, e.target.value)}
            placeholder={field.config?.placeholder || "Escribe tu respuesta aquí..."}
          />
        );
      case 'number':
        return (
            <div className="flex items-center gap-2">
                <Input
                    id={`patient-${field.id}`}
                    type="number"
                    value={value as string}
                    onChange={e => handleValueChange(field.id, e.target.value)}
                    className="max-w-40"
                />
                {field.config?.unit && <span className="text-muted-foreground">{field.config.unit}</span>}
            </div>
        );
      case 'yes_no':
        return (
          <RadioGroup
            value={value as string}
            onValueChange={(val) => handleValueChange(field.id, val)}
            className="flex gap-4"
          >
            <div className="flex items-center space-x-2">
              <RadioGroupItem value="yes" id={`${field.id}-yes`} />
              <Label htmlFor={`${field.id}-yes`}>Sí</Label>
            </div>
            <div className="flex items-center space-x-2">
              <RadioGroupItem value="no" id={`${field.id}-no`} />
              <Label htmlFor={`${field.id}-no`}>No</Label>
            </div>
          </RadioGroup>
        );
      default:
        return <p>Tipo de pregunta no soportado.</p>;
    }
  }

  return (
    <Card className="shadow-lg">
      <CardHeader className="text-center">
        <div className="text-6xl mb-4 mx-auto w-fit text-primary"><Brain /></div>
        <CardTitle className="text-3xl font-bold text-gray-800">{testConfig.name}</CardTitle>
        <CardDescription>{testConfig.instructions || 'Por favor responde con honestidad a cada pregunta.'}</CardDescription>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-8">
          <div className="space-y-6">
            {testConfig.fields.map((field) => (
              <div key={field.id} className="bg-gray-50/50 rounded-lg p-6 border">
                <label htmlFor={`patient-${field.id}`} className="block text-lg font-medium text-gray-700 mb-4 text-center">
                  {field.label}
                  {field.alertEnabled && <AlertTriangle className="inline-block ml-2 text-amber-500" size={16}/>}
                </label>
                {renderQuestionField(field)}
              </div>
            ))}
          </div>

          <div>
            <label htmlFor="patient-notes" className="block text-sm font-medium text-gray-700 mb-2">
              Comentarios Adicionales (Opcional)
            </label>
            <Textarea
              id="patient-notes"
              rows={3}
              placeholder="¿Hay algo más que te gustaría compartir?"
            />
          </div>

          <div className="flex flex-col sm:flex-row space-y-2 sm:space-y-0 sm:space-x-4">
            <Button type="button" onClick={onBack} variant="outline" className="flex-1 py-6 text-base" disabled={isLoading}>
              <ArrowLeft className="mr-2 h-4 w-4" /> Volver a Tests
            </Button>
            <Button type="submit" id="patient-submit-btn" className="flex-1 py-6 text-base" disabled={isLoading}>
              {isLoading ? 'Enviando...' : 'Enviar Test Completado'}
            </Button>
          </div>
        </form>
      </CardContent>
    </Card>
  );
}
