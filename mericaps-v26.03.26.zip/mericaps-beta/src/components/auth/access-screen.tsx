
"use client";

import { useState } from 'react';
import { Lock, Trash2, KeyRound, User, Mail, LogIn, ArrowLeft } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { useToast } from '@/hooks/use-toast';
import type { User as AppUser, PatientCode, Supervisor, Therapist } from '@/lib/definitions';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog"
import { useAuth } from '@/firebase';
import { FirebaseError } from 'firebase/app';
import { signInWithEmailAndPassword } from 'firebase/auth';


interface AccessScreenProps {
  onAccessGranted: (user: AppUser) => void;
  appState: {
    patientCodes?: PatientCode[];
    supervisors?: Supervisor[];
    therapists?: Therapist[];
  };
}

export function AccessScreen({ onAccessGranted, appState }: AccessScreenProps) {
  const [accessCode, setAccessCode] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [view, setView] = useState<'code' | 'adminLogin'>('code');
  const [adminEmail, setAdminEmail] = useState('');
  const [adminPassword, setAdminPassword] = useState('');
  const auth = useAuth();
  const { toast } = useToast();
  const { patientCodes = [], supervisors = [], therapists = [] } = appState;

  const handleAccessCode = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    const code = accessCode.trim().toUpperCase();

    if (!code) {
      toast({
        variant: 'destructive',
        title: 'Error de Acceso',
        description: 'Por favor ingresa un código de acceso.',
      });
      setIsLoading(false);
      return;
    }

    // Check patient codes
    const patient = patientCodes.find(p => p.code === code);
    if (patient) {
        if (patient.expiry && new Date() > new Date(patient.expiry)) {
            toast({ variant: 'destructive', title: 'Código Expirado', description: 'Este código ha expirado. Contacta a tu terapeuta.' });
            setIsLoading(false);
            return;
        }
        if (patient.maxUses && patient.usedCount >= patient.maxUses) {
            toast({ variant: 'destructive', title: 'Límite de Usos Alcanzado', description: 'Este código ha alcanzado el límite de usos permitidos.' });
            setIsLoading(false);
            return;
        }
        onAccessGranted({ id: patient.id, role: 'patient', name: patient.patientName, data: patient });
        setIsLoading(false);
        return;
    }

    // Check supervisor codes
    const supervisor = supervisors.find(s => s.code === code);
    if (supervisor) {
        if (supervisor.expiry && new Date() > new Date(supervisor.expiry)) {
            toast({ variant: 'destructive', title: 'Código Expirado', description: 'Este código de supervisor ha expirado.' });
            setIsLoading(false);
            return;
        }
        onAccessGranted({ id: supervisor.id, role: 'supervisor', name: supervisor.name, data: supervisor });
        setIsLoading(false);
        return;
    }

    // Check therapist codes
    const therapist = therapists.find(t => t.code === code);
    if (therapist) {
        if (therapist.expiry && new Date() > new Date(therapist.expiry)) {
            toast({ variant: 'destructive', title: 'Código Expirado', description: 'Este código de terapeuta ha expirado.' });
            setIsLoading(false);
            return;
        }
        onAccessGranted({ id: therapist.id, role: 'therapist', name: therapist.name, data: therapist });
        setIsLoading(false);
        return;
    }
    
    // If no match found
    toast({
      variant: 'destructive',
      title: 'Código Incorrecto',
      description: 'El código de acceso no es válido. Por favor, verifica e intenta de nuevo.',
    });
    setIsLoading(false);
  };

  const handleAdminLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    try {
      // The onAuthStateChanged listener in AppContent will handle the successful login.
      await signInWithEmailAndPassword(auth, adminEmail, adminPassword);
      // On success, the useUser hook will trigger a re-render of AppContent,
      // which will then render the appropriate dashboard.
    } catch (error: any) {
      let description = 'Ocurrió un error inesperado.';
      if (error instanceof FirebaseError) {
        switch (error.code) {
          case 'auth/user-not-found':
          case 'auth/invalid-credential':
            description = 'El correo o la contraseña son incorrectos.';
            break;
          case 'auth/invalid-email':
            description = 'El formato del correo electrónico no es válido.';
            break;
          default:
            description = `Error: ${error.message}`;
        }
      }
      toast({
        variant: 'destructive',
        title: 'Error de Inicio de Sesión',
        description,
      });
    } finally {
      setIsLoading(false);
    }
  };


  const renderCodeView = () => (
    <>
      <CardHeader className="text-center">
        <div className="mx-auto bg-primary/10 text-primary rounded-full p-3 w-fit mb-4">
          <KeyRound className="h-8 w-8" />
        </div>
        <CardTitle className="text-3xl font-headline">Acceso a la Plataforma</CardTitle>
        <CardDescription>Ingresa tu código de acceso para continuar</CardDescription>
      </CardHeader>
      <CardContent>
        <Alert variant="default" className="bg-accent/10 border-accent/20">
          <AlertTitle className="text-accent-foreground/80">Instrucciones</AlertTitle>
          <AlertDescription className="text-foreground/70">
            <ul className="list-disc list-inside space-y-1">
              <li><strong>Pacientes, Terapeutas y Supervisores:</strong> Usen su código de acceso único.</li>
              <li>* Para mayor seguridad, los administradores pueden habilitar el inicio de sesión con correo electrónico para profesionales en la pestaña de "Roles".</li>
            </ul>
          </AlertDescription>
        </Alert>
        <form onSubmit={handleAccessCode} className="mt-6">
          <div className="space-y-2">
            <Input
              id="patient-code"
              type="text"
              value={accessCode}
              onChange={(e) => setAccessCode(e.target.value)}
              required
              className="w-full px-4 py-3 h-14 border-input rounded-lg focus:ring-2 focus:ring-ring focus:border-ring text-center text-2xl font-mono uppercase tracking-widest"
              placeholder="TU-CÓDIGO-AQUÍ"
              disabled={isLoading}
              aria-label="Código de Acceso"
            />
          </div>
          <Button type="submit" className="w-full mt-6 py-6 text-lg" disabled={isLoading}>
            {isLoading ? 'Verificando...' : 'Acceder'}
          </Button>
        </form>
      </CardContent>
      <CardFooter className="flex-col gap-4">
          <Button variant="link" onClick={() => setView('adminLogin')}>
              <LogIn className="mr-2 h-4 w-4" />
              ¿Eres profesional? Inicia sesión aquí
          </Button>
          <p className="text-xs text-muted-foreground text-center w-full">Tu acceso y respuestas son confidenciales y seguros.</p>
           <AlertDialog>
            <AlertDialogTrigger asChild>
              <Button variant="link" size="sm" className="text-xs text-muted-foreground hover:text-destructive">
                <Trash2 className="mr-2 h-3 w-3"/>
                Limpiar todos los datos de la aplicación
              </Button>
            </AlertDialogTrigger>
            <AlertDialogContent>
              <AlertDialogHeader>
                <AlertDialogTitle>¿Estás seguro de limpiar los datos?</AlertDialogTitle>
                <AlertDialogDescription>
                  Esta acción borrará TODOS los datos de la aplicación (configuración, tests, resultados, etc.) almacenados en tu navegador.
                  Es útil si no puedes iniciar sesión o si quieres empezar de cero. Esta acción no se puede deshacer.
                </AlertDialogDescription>
              </AlertDialogHeader>
              <AlertDialogFooter>
                <AlertDialogCancel>Cancelar</AlertDialogCancel>
                <AlertDialogAction onClick={() => {
                  localStorage.clear();
                  window.location.reload();
                }} className="bg-destructive hover:bg-destructive/90">
                  Sí, limpiar datos
                </AlertDialogAction>
              </AlertDialogFooter>
            </AlertDialogContent>
          </AlertDialog>
      </CardFooter>
    </>
  );

  const renderAdminLoginView = () => (
    <>
      <CardHeader>
        <div className="flex items-center justify-between">
          <Button variant="ghost" size="icon" onClick={() => setView('code')}>
            <ArrowLeft />
          </Button>
          <div className="flex-grow text-center">
            <CardTitle className="text-2xl font-headline">Acceso Profesional</CardTitle>
            <CardDescription>Inicia sesión con tu correo y contraseña</CardDescription>
          </div>
          <div className="w-9 h-9"></div> {/* Spacer */}
        </div>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleAdminLogin} className="space-y-4">
          <div className="relative">
            <Mail className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
            <Input
              id="admin-email"
              type="email"
              placeholder="correo@ejemplo.com"
              className="pl-10"
              value={adminEmail}
              onChange={(e) => setAdminEmail(e.target.value)}
              required
              disabled={isLoading}
            />
          </div>
          <div className="relative">
            <Lock className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
            <Input
              id="admin-password"
              type="password"
              placeholder="Contraseña"
              className="pl-10"
              value={adminPassword}
              onChange={(e) => setAdminPassword(e.target.value)}
              required
              disabled={isLoading}
            />
          </div>
          <Button type="submit" className="w-full" disabled={isLoading}>
            {isLoading ? "Iniciando sesión..." : "Iniciar Sesión"}
          </Button>
        </form>
      </CardContent>
      <CardFooter>
        <p className="text-xs text-muted-foreground text-center w-full">
            Si olvidaste tu contraseña, deberás recuperarla a través de la consola de Firebase.
        </p>
      </CardFooter>
    </>
  )

  return (
    <div className="flex items-center justify-center min-h-full p-4 sm:p-6 lg:p-8">
      <Card className="w-full max-w-lg shadow-xl">
        {view === 'code' ? renderCodeView() : renderAdminLoginView()}
      </Card>
    </div>
  );
}
