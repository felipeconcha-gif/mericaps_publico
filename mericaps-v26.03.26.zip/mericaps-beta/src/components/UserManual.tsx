"use client";

import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { HelpCircle } from "lucide-react";
import { ScrollArea } from "./ui/scroll-area";
import { Separator } from "./ui/separator";

export function UserManual() {
  return (
    <Dialog>
      <DialogTrigger asChild>
        <button className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-primary">
          <HelpCircle className="h-4 w-4" />
          <span>README</span>
        </button>
      </DialogTrigger>
      <DialogContent className="max-w-4xl h-[90vh]">
        <DialogHeader>
          <DialogTitle className="text-2xl">README</DialogTitle>
          <DialogDescription>
            Una guía completa para aprovechar al máximo la plataforma.
          </DialogDescription>
        </DialogHeader>
        <ScrollArea className="h-full pr-6">
          <div className="space-y-6 text-sm">
            
            <section>
              <p><strong>Version: March 11, 2026</strong></p>
              <p className="mt-2">For questions, collaboration requests, or institutional inquiries please contact: <strong>[felipeconcha@centroarbol.cl]</strong></p>
            </section>
            
            <Separator className="my-4" />

            <section>
              <h3 className="font-semibold text-lg mb-2">MERICAPS</h3>
              <p><strong>MERICAPS (Measurement and Research of Change in Psychotherapy)</strong> is an open infrastructure and web-based platform designed to enable <strong>Routine Outcome Monitoring (ROM)</strong> in psychotherapy and mental health services across Latin America.</p>
              <p className="mt-2">The platform provides clinicians, supervisors, and institutions with tools to systematically collect, analyze, and visualize psychotherapy outcome data, supporting <strong>data-informed clinical decisions, supervision, and program evaluation</strong>.</p>
              <p className="mt-2">MERICAPS was originally developed to support the implementation of ROM in <strong>Centro Médico Árbol (Chile)</strong> and <strong>Proyecto T at Universidad Diego Portales</strong>, and emerged from technological needs identified by clinical centers participating in the <strong>Consorcio Latinoamericano de Investigación en Psicoterapia (CLIP)</strong>.</p>
              <p className="mt-2">MERICAPS is currently used in real clinical environments and was developed within the context of psychotherapy services and research initiatives in Latin America.</p>
              <p className="mt-2">The project aims to <strong>remove the technical and economic barriers</strong> that historically limited the adoption of ROM systems in the region.</p>
            </section>

            <Separator className="my-4" />

            <section>
              <h3 className="font-semibold text-lg mb-2">Why MERICAPS Exists</h3>
              <p>In many psychotherapy settings across Latin America, treatment outcomes are rarely measured systematically.</p>
              <p className="mt-2">Existing solutions are often:</p>
              <ul className="list-disc list-inside space-y-1 mt-2">
                <li>expensive</li>
                <li>technically complex</li>
                <li>dependent on research projects</li>
                <li>difficult to adapt to local clinical contexts</li>
              </ul>
              <p className="mt-2">As a result:</p>
              <ul className="list-disc list-inside space-y-1 mt-2">
                <li>therapists rely mostly on subjective impressions of improvement</li>
                <li>clinical programs lack systematic evaluation</li>
                <li>the region depends on research produced outside its cultural context</li>
              </ul>
              <p className="mt-2">MERICAPS was created to <strong>democratize access to outcome monitoring infrastructure</strong>, allowing clinical centers to generate their own evidence about psychotherapy effectiveness.</p>
            </section>
            
            <Separator className="my-4" />

            <section>
              <h3 className="font-semibold text-lg mb-2">Core Concept: Routine Outcome Monitoring (ROM)</h3>
              <p>Routine Outcome Monitoring involves <strong>regularly measuring patient progress throughout psychotherapy</strong> using standardized instruments.</p>
              <p className="mt-2">When implemented effectively, ROM can:</p>
              <ul className="list-disc list-inside space-y-1 mt-2">
                <li>detect early signs of deterioration or stagnation</li>
                <li>support therapist decision-making</li>
                <li>improve supervision processes</li>
                <li>evaluate clinical programs</li>
                <li>generate research data about psychotherapy effectiveness</li>
              </ul>
              <p className="mt-2">MERICAPS provides the technological infrastructure necessary to implement this approach in real clinical environments.</p>
            </section>

            <Separator className="my-4" />

            <section>
              <h3 className="font-semibold text-lg mb-2">Open Infrastructure & Adaptability</h3>
              <p>MERICAPS was designed as an <strong>open-access code base</strong> that clinical centers and institutions can adopt, deploy, and adapt according to their specific needs.</p>
              <p className="mt-2">Rather than functioning as a closed proprietary platform, MERICAPS provides a <strong>flexible technological foundation for implementing Routine Outcome Monitoring in psychotherapy services</strong>.</p>
              <p className="mt-2">The system was developed within the <strong>Firebase ecosystem</strong>, allowing institutions to easily deploy and modify the platform using tools such as <strong>Firebase Studio and its AI-assisted code editor</strong>.</p>
              <p className="mt-2">This design enables users to:</p>
              <ul className="list-disc list-inside space-y-1 mt-2">
                <li>deploy their own instance of the platform</li>
                <li>customize assessment instruments and workflows</li>
                <li>adapt the system to local clinical practices</li>
                <li>extend functionality using modern cloud development tools</li>
              </ul>
              <p className="mt-2">By combining <strong>open infrastructure with AI-assisted development environments</strong>, MERICAPS lowers the technical barriers traditionally associated with building and maintaining clinical data systems.</p>
              <p className="mt-2">This approach allows psychotherapy services across Latin America to implement outcome monitoring <strong>without depending on expensive proprietary software or specialized engineering teams</strong>.</p>
            </section>

            <Separator className="my-4" />
            
            <section>
              <h3 className="font-semibold text-lg mb-2">Clinical Context & Real-World Use</h3>
              <p>MERICAPS was developed in response to real clinical needs identified in psychotherapy services in Latin America.</p>
              <p className="mt-2">The platform is currently being implemented in the following contexts.</p>
              
              <Separator className="my-4" />
              
              <h4 className="font-semibold mt-4">Centro Médico Árbol (Chile)</h4>
              <p className="mt-2">Centro Médico Árbol is a psychotherapy center with a strong social orientation, where many therapists are in professional training.</p>
              <p className="mt-2">Routine Outcome Monitoring is used to:</p>
              <ul className="list-disc list-inside space-y-1 mt-2">
                <li>monitor the quality of clinical care</li>
                <li>support supervision processes</li>
                <li>detect early signs of deterioration or stagnation in treatment</li>
                <li>help therapists and patients observe change trajectories over time</li>
              </ul>
              <p className="mt-2">MERICAPS was originally created to replace a previous ROM platform that became financially unsustainable for the center.</p>

              <Separator className="my-4" />
              
              <h4 className="font-semibold mt-4">Proyecto T — Universidad Diego Portales</h4>
              <p className="mt-2">Proyecto T is a free psychological care program for <strong>trans and gender non-conforming individuals</strong> operated by Universidad Diego Portales.</p>
              <p className="mt-2">In this context, Routine Outcome Monitoring plays a crucial role in:</p>
              <ul className="list-disc list-inside space-y-1 mt-2">
                <li>evaluating the effectiveness of the intervention program</li>
                <li>generating empirical data about therapeutic outcomes</li>
                <li>supporting evidence-based responses to public criticism and misinformation about the program</li>
              </ul>
              <p className="mt-2">MERICAPS facilitates the systematic collection and analysis of this clinical data.</p>
              
              <Separator className="my-4" />

              <h4 className="font-semibold mt-4">CLIP — Consorcio Latinoamericano de Investigación en Psicoterapia</h4>
              <p className="mt-2">Centro Médico Árbol and Proyecto T are both members of the <strong>Consorcio Latinoamericano de Investigación en Psicoterapia (CLIP)</strong>.</p>
              <p className="mt-2">Within the consortium, participating centers conducted a needs assessment to identify technological barriers to implementing Routine Outcome Monitoring across Latin America.</p>
              <p className="mt-2">MERICAPS emerged as a response to these identified needs, aiming to provide an accessible technological infrastructure that clinical centers in the region can adopt and adapt.</p>
            </section>

            <Separator className="my-4" />
            
            <section>
              <h3 className="font-semibold text-lg mb-2">User Roles</h3>
              <p>MERICAPS supports multiple user roles designed to reflect real clinical workflows within psychotherapy services and training environments.</p>

              <Separator className="my-4" />
              
              <h4 className="font-semibold mt-4">Administrator</h4>
              <p className="mt-2">Administrators are responsible for the overall configuration and management of the platform.</p>
              <p className="mt-2">Administrators can:</p>
              <ul className="list-disc list-inside space-y-1 mt-2">
                <li>create, edit, and delete user accounts</li>
                <li>assign roles to professionals within the system</li>
                <li>create and manage clinical assessment instruments</li>
                <li>configure institutional settings</li>
              </ul>
              <p className="mt-2">This role ensures institutions maintain <strong>full control over their own system and data governance</strong>.</p>

              <Separator className="my-4" />

              <h4 className="font-semibold mt-4">Supervisor</h4>
              <p className="mt-2">Supervisors oversee the clinical work of therapists.</p>
              <p className="mt-2">Supervisors can:</p>
              <ul className="list-disc list-inside space-y-1 mt-2">
                <li>create and manage clinical assessment instruments</li>
                <li>access the patient lists of assigned therapists</li>
                <li>review patient responses and outcome trajectories</li>
                <li>monitor treatment progress across multiple therapists</li>
              </ul>
              <p className="mt-2">This role supports <strong>evidence-informed supervision</strong>.</p>

              <Separator className="my-4" />

              <h4 className="font-semibold mt-4">Professionals (Therapists / Clinicians)</h4>
              <p className="mt-2">Therapists are responsible for the day-to-day clinical use of the platform.</p>
              <p className="mt-2">Professionals can:</p>
              <ul className="list-disc list-inside space-y-1 mt-2">
                <li>manage patient rosters</li>
                <li>assign clinical assessments to patients</li>
                <li>review patient responses and progress over time</li>
                <li>use visual dashboards to monitor treatment trajectories</li>
              </ul>
              <p className="mt-2">These features support <strong>data-informed clinical decision-making</strong>.</p>
              
              <Separator className="my-4" />

              <h4 className="font-semibold mt-4">Patients</h4>
              <p className="mt-2">Patients access a secure portal where they can:</p>
              <ul className="list-disc list-inside space-y-1 mt-2">
                <li>complete assigned psychological assessments</li>
                <li>track their progress across sessions</li>
              </ul>
              <p className="mt-2">This creates greater <strong>transparency in psychotherapy</strong>, allowing patients and therapists to observe change trajectories together.</p>
            </section>

            <Separator className="my-4" />

            <section>
              <h3 className="font-semibold text-lg mb-2">Key Features</h3>
              <p><strong>Role-Based Access Control:</strong> Separate dashboards and permissions for each user role.</p>
              <p><strong>Patient Management:</strong> Professionals can add, manage, and monitor patient records.</p>
              <p><strong>Clinical Test Editor:</strong> Flexible interface for creating customized psychological assessments.</p>
              <p><strong>Interactive Mural Dashboard:</strong> Visual overview of results and trends across patients.</p>
              <p><strong>Data Migration Tools:</strong> Import clinical data from sources such as Google Sheets.</p>
              <p><strong>Modern UI / UX:</strong> Responsive interface built using a component-based design system.</p>
            </section>

            <Separator className="my-4" />
            
            <section>
              <h3 className="font-semibold text-lg mb-2">Technology Stack</h3>
              <h4 className="font-semibold mt-4">Frontend</h4>
              <ul className="list-disc list-inside space-y-1 mt-2">
                <li>TypeScript</li>
                <li>Next.js (React)</li>
                <li>Tailwind CSS</li>
                <li>Shadcn/UI component library</li>
              </ul>
              <Separator className="my-4" />
              <h4 className="font-semibold mt-4">Backend & Infrastructure</h4>
              <ul className="list-disc list-inside space-y-1 mt-2">
                <li>Google Firebase</li>
                <li>Firestore (NoSQL database)</li>
                <li>Firebase Authentication</li>
                <li>Firebase App Hosting</li>
              </ul>
            </section>

            <Separator className="my-4" />
            
            <section>
              <h3 className="font-semibold text-lg mb-2">System Architecture</h3>
              <p>MERICAPS uses a <strong>serverless architecture built on Next.js and the Firebase ecosystem</strong>.</p>
              <Separator className="my-4" />
              <h4 className="font-semibold mt-4">Frontend</h4>
              <p className="mt-2">The user interface is implemented as a Next.js application responsible for:</p>
              <ul className="list-disc list-inside space-y-1 mt-2">
                <li>rendering the UI</li>
                <li>managing user interactions</li>
                <li>communicating with Firebase services</li>
              </ul>
              <Separator className="my-4" />
              <h4 className="font-semibold mt-4">Backend (Serverless)</h4>
              <h5 className="font-semibold mt-2">Firebase Authentication</h5>
              <p className="mt-2">Handles login and role-based access control.</p>
              <h5 className="font-semibold mt-2">Firestore Database</h5>
              <p className="mt-2">Stores data including:</p>
              <ul className="list-disc list-inside space-y-1 mt-2">
                <li>patients</li>
                <li>clinical tests</li>
                <li>assessment responses</li>
                <li>treatment results</li>
              </ul>
              <p className="mt-2">Real-time listeners allow live updates in the interface.</p>
              <Separator className="my-4" />
              <h4 className="font-semibold mt-4">Google App Hosting</h4>
              <p className="mt-2">Runs and deploys the Next.js application.</p>
            </section>

            <Separator className="my-4" />
            
            <section>
              <h3 className="font-semibold text-lg mb-2">AI Services (Planned)</h3>
              <p>The architecture allows future integration of <strong>AI-based clinical analysis workflows using Google Genkit</strong>.</p>
              <p className="mt-2">These workflows could analyze patient response patterns and generate structured summaries to support clinical interpretation and supervision.</p>
              <p className="mt-2">This functionality is <strong>currently under development</strong> and not active in production.</p>
            </section>

            <Separator className="my-4" />
            
            <section>
              <h3 className="font-semibold text-lg mb-2">Project Structure</h3>
              <pre className="bg-muted p-4 rounded-md mt-2 overflow-x-auto"><code className="font-code text-sm">
{`
.
├── src
│   ├── app/
│   ├── ai/
│   ├── components/
│   │   ├── auth/
│   │   ├── patient/
│   │   ├── professional/
│   │   └── ui/
│   ├── firebase/
│   ├── hooks/
│   └── lib/
│
├── firebase.json
├── apphosting.yaml
└── next.config.ts
`}
              </code></pre>
            </section>

            <Separator className="my-4" />

            <section>
              <h3 className="font-semibold text-lg mb-2">Installation</h3>
              <p>Clone repository</p>
              <pre className="bg-muted p-4 rounded-md mt-2"><code className="font-code text-sm">
{`git clone https://github.com/felipeconcha-gif/mericaps.git
cd mericaps`}
              </code></pre>
              <p className="mt-2">Install dependencies</p>
              <pre className="bg-muted p-4 rounded-md mt-2"><code className="font-code text-sm">
npm install
              </code></pre>
            </section>
            
            <Separator className="my-4" />
            
            <section>
              <h3 className="font-semibold text-lg mb-2">Environment Configuration</h3>
              <p>Create a file named `.env.local` in the root of the project by copying the `.env` template. Then, fill in the values from your Firebase project.</p>
              <pre className="bg-muted p-4 rounded-md mt-2"><code className="font-code text-sm">
{`
# .env.local
NEXT_PUBLIC_FIREBASE_API_KEY="YOUR_API_KEY"
NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN="YOUR_PROJECT_ID.firebaseapp.com"
NEXT_PUBLIC_FIREBASE_PROJECT_ID="YOUR_PROJECT_ID"
NEXT_PUBLIC_FIREBASE_STORAGE_BUCKET="YOUR_PROJECT_ID.appspot.com"
NEXT_PUBLIC_FIREBASE_MESSAGING_SENDER_ID="YOUR_SENDER_ID"
NEXT_PUBLIC_FIREBASE_APP_ID="YOUR_APP_ID"
NEXT_PUBLIC_FIREBASE_MEASUREMENT_ID="YOUR_MEASUREMENT_ID"
`}
              </code></pre>
               <p className="mt-2">These values are available at: Firebase Console → Project Settings → General → Your apps → Web app.</p>
            </section>

            <Separator className="my-4" />

            <section>
              <h3 className="font-semibold text-lg mb-2">Running the Project</h3>
              <pre className="bg-muted p-4 rounded-md mt-2"><code className="font-code text-sm">npm run dev</code></pre>
              <p className="mt-2">Open</p>
              <pre className="bg-muted p-4 rounded-md mt-2"><code className="font-code text-sm">http://localhost:3000</code></pre>
            </section>
            
            <Separator className="my-4" />

            <section>
              <h3 className="font-semibold text-lg mb-2">Deployment</h3>
              <p>Install Firebase CLI</p>
              <pre className="bg-muted p-4 rounded-md mt-2"><code className="font-code text-sm">npm install -g firebase-tools</code></pre>
              <p className="mt-2">Login</p>
              <pre className="bg-muted p-4 rounded-md mt-2"><code className="font-code text-sm">firebase login</code></pre>
              <p className="mt-2">Initialize</p>
              <pre className="bg-muted p-4 rounded-md mt-2"><code className="font-code text-sm">firebase init hosting</code></pre>
              <p className="mt-2">Deploy</p>
              <pre className="bg-muted p-4 rounded-md mt-2"><code className="font-code text-sm">firebase deploy</code></pre>
            </section>
            
            <Separator className="my-4" />

            <section>
              <h3 className="font-semibold text-lg mb-2">Example Workflow</h3>
              <ol className="list-decimal list-inside space-y-1 mt-2">
                <li>Administrator creates user accounts</li>
                <li>Supervisor assigns therapists</li>
                <li>Therapist creates clinical assessments</li>
                <li>Patient completes assessments</li>
                <li>Results appear in real-time dashboards</li>
                <li>Supervisor monitors treatment trajectories</li>
              </ol>
            </section>

            <Separator className="my-4" />
            
            <section>
              <h3 className="font-semibold text-lg mb-2">Impact & Vision</h3>
              <p>MERICAPS was designed not only as software, but as infrastructure supporting the development of a <strong>data-informed psychotherapy culture in Latin America</strong>.</p>
              <p className="mt-2">If widely adopted, systems like MERICAPS could allow clinical centers across the region to:</p>
              <ul className="list-disc list-inside space-y-1 mt-2">
                <li>systematically measure psychotherapy outcomes</li>
                <li>improve clinical decision-making</li>
                <li>strengthen supervision and training processes</li>
                <li>evaluate mental health programs</li>
                <li>generate regional evidence about psychotherapy effectiveness</li>
              </ul>
              <p className="mt-2">By lowering the barriers to implementing Routine Outcome Monitoring, MERICAPS aims to help Latin American institutions <strong>generate their own data about psychotherapy outcomes</strong>.</p>
            </section>
            
            <Separator className="my-4" />

            <section>
              <h3 className="font-semibold text-lg mb-2">Future Development</h3>
              <p>Potential extensions include:</p>
              <ul className="list-disc list-inside space-y-1 mt-2">
                <li>AI-assisted clinical summaries</li>
                <li>advanced visualization tools</li>
                <li>real-time notifications</li>
                <li>institutional analytics dashboards</li>
                <li>large-scale clinical deployment infrastructure</li>
              </ul>
            </section>
            
            <Separator className="my-4" />

            <section>
              <h3 className="font-semibold text-lg mb-2">Contributions</h3>
              <p>MERICAPS is currently maintained by the project creator.</p>
              <p className="mt-2">If you are interested in collaborating, implementing MERICAPS in your institution, or contributing to its development, please contact: <strong>felipeconcha@centroarbol.cl</strong></p>
            </section>
            
            <Separator className="my-4" />
            
            <section>
                <h3 className="font-semibold text-lg mb-2">Términos de Uso y Reconocimiento</h3>
                <p>Al ser una infraestructura abierta y gratuita, el uso de MERICAPS está sujeto a las siguientes condiciones para asegurar el reconocimiento del trabajo original y la sostenibilidad del proyecto:</p>
                <ol className="list-decimal list-inside space-y-2 mt-2">
                  <li><strong>No cambiar el nombre de la plataforma.</strong> El nombre "MERICAPS" debe ser mantenido en cualquier instancia que se despliegue.</li>
                  <li><strong>Mantener el footer intacto.</strong> El pie de página, que incluye los créditos al creador (Dr. Felipe Concha) y la institución patrocinante (Centro Médico Árbol), no debe ser modificado ni eliminado.</li>
                  <li><strong>Mantener el botón de donaciones.</strong> El botón "Buy me a coffee" debe permanecer visible y con su enlace original para apoyar el mantenimiento y desarrollo continuo de la plataforma.</li>
                  <li><strong>Responsabilidad sobre los datos.</strong> La configuración de la seguridad de los datos, así como la gestión de la privacidad y confidencialidad de la información clínica, es responsabilidad exclusiva de la persona o institución que despliega y utiliza la plataforma.</li>
                </ol>
                <p className="mt-2">El cumplimiento de estos términos permite que MERICAPS siga siendo una herramienta accesible para la comunidad.</p>
            </section>

            <Separator className="my-4" />
            
            <section>
                <h3 className="font-semibold text-lg mb-2">License</h3>
                <p>Distributed under the <strong>MIT License</strong>. See `LICENSE`.</p>
            </section>

          </div>
        </ScrollArea>
      </DialogContent>
    </Dialog>
  );
}
