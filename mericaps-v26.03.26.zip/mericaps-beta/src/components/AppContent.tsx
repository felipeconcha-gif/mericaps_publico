
"use client";

import { useState, useEffect, useMemo, type ReactNode } from 'react';
import { AccessScreen } from '@/components/auth/access-screen';
import dynamic from 'next/dynamic';
import type { User, CustomTest, PatientCode, Supervisor, TestResult, ClinicalInfo, Therapist, ScheduledReminder, ThemeSettings, TherapistInfo, SpecialtyCategory, AppConfig } from '@/lib/definitions';
import { Skeleton } from '@/components/ui/skeleton';
import { useToast } from '@/hooks/use-toast';
import { useUser, useFirestore, useCollection, useMemoFirebase, useDoc, useAuth } from '@/firebase';
import { collection, query, where, doc } from 'firebase/firestore';
import Image from 'next/image';
import { AreaChart } from 'lucide-react';
import { initialTests } from '@/lib/constants';

const ProfessionalDashboard = dynamic(() =>
  import('@/components/professional/professional-dashboard').then((mod) => mod.ProfessionalDashboard),
  {
    loading: () => <DashboardSkeleton />,
    ssr: false
  }
);

const PatientDashboard = dynamic(() =>
  import('@/components/patient/patient-dashboard').then((mod) => mod.PatientDashboard),
  {
    loading: () => <DashboardSkeleton />,
    ssr: false
  }
);

function DashboardSkeleton() {
  return (
     <div className="w-full">
      <div className="flex flex-col sm:flex-row justify-between items-center mb-6 gap-4">
        <Skeleton className="h-8 w-48" />
        <Skeleton className="h-9 w-24" />
      </div>
       <div className="flex flex-col md:items-start md:flex-row md:gap-8">
          <div className="grid md:flex md:flex-col md:w-48 h-auto w-full mb-6 md:mb-0 gap-1">
            <Skeleton className="h-12 w-full" />
            <Skeleton className="h-12 w-full" />
            <Skeleton className="h-12 w-full" />
          </div>
          <div className="flex-1">
              <Skeleton className="h-96 w-full" />
          </div>
      </div>
    </div>
  )
}

interface AppContentProps {
  children: ReactNode;
}


export default function AppContent({ children }: AppContentProps) {
  const [isMounted, setIsMounted] = useState(false);
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const { toast } = useToast();
  const { user: firebaseUser, isUserLoading } = useUser();
  const firestore = useFirestore();
  const auth = useAuth();

  const appConfigRef = useMemoFirebase(() => firestore ? doc(firestore, 'appConfig/main') : null, [firestore]);
  const { data: appConfig, isLoading: appConfigLoading } = useDoc<AppConfig>(appConfigRef);

  const defaultTheme: ThemeSettings = {
    primary: '244 81% 60%',
    background: '240 10% 97%',
    accent: '45 93% 47%',
    logoUrl: ''
  };

  const themeSettings = appConfig?.themeSettings || defaultTheme;

  // --- Firestore Data Hooks ---
  const { data: supervisors = [], isLoading: supervisorsLoading } = useCollection<Supervisor>(
    useMemoFirebase(() => firestore ? collection(firestore, 'supervisors') : null, [firestore])
  );
  const { data: therapists = [], isLoading: therapistsLoading } = useCollection<Therapist>(
    useMemoFirebase(() => firestore ? collection(firestore, 'therapists') : null, [firestore])
  );
  const { data: patientCodes = [], isLoading: patientCodesLoading } = useCollection<PatientCode>(
    useMemoFirebase(() => firestore ? collection(firestore, 'patientAccessCodes') : null, [firestore])
  );
  const { data: testResults = [], isLoading: resultsLoading } = useCollection<TestResult>(
    useMemoFirebase(() => firestore ? collection(firestore, 'testResults') : null, [firestore])
  );
  const { data: customTests = [], isLoading: testsLoading } = useCollection<CustomTest>(
    useMemoFirebase(() => firestore ? collection(firestore, 'psychologicalTests') : null, [firestore])
  );
  const { data: clinicalInfoDocs = [], isLoading: clinicalInfoLoading } = useCollection<ClinicalInfo>(
    useMemoFirebase(() => firestore ? collection(firestore, 'clinicalInfo') : null, [firestore])
  );
  const { data: therapistInfoDocs = [], isLoading: therapistInfoLoading } = useCollection<TherapistInfo>(
    useMemoFirebase(() => firestore ? collection(firestore, 'therapistInfo') : null, [firestore])
  );
  const { data: scheduledReminders = [], isLoading: remindersLoading } = useCollection<ScheduledReminder>(
    useMemoFirebase(() => firestore ? collection(firestore, 'scheduledReminders') : null, [firestore])
  );
   const { data: specialtyCategories = [], isLoading: specialtiesLoading } = useCollection<SpecialtyCategory>(
    useMemoFirebase(() => firestore ? collection(firestore, 'specialtyCategories') : null, [firestore])
  );
  
  const clinicalInfo = useMemo(() => {
    return (clinicalInfoDocs || []).reduce((acc, doc) => {
      acc[doc.id] = doc;
      return acc;
    }, {} as Record<string, ClinicalInfo>);
  }, [clinicalInfoDocs]);
  
  const therapistInfo = useMemo(() => {
    return (therapistInfoDocs || []).reduce((acc, doc) => {
      acc[doc.id] = doc;
      return acc;
    }, {} as Record<string, TherapistInfo>);
  }, [therapistInfoDocs]);

  const combinedTests = useMemo(() => {
    const customTestsMap = new Map((customTests || []).map(t => [t.id, t]));
    const combined = initialTests.map(initialTest => 
      customTestsMap.has(initialTest.id) ? customTestsMap.get(initialTest.id)! : initialTest
    );
    const uniqueCustomTests = (customTests || []).filter(t => !initialTests.some(it => it.id === t.id));
    return [...combined, ...uniqueCustomTests];
  }, [customTests]);


  const isDataLoading = supervisorsLoading || therapistsLoading || patientCodesLoading || resultsLoading || testsLoading || clinicalInfoLoading || remindersLoading || appConfigLoading || therapistInfoLoading || specialtiesLoading;

  useEffect(() => {
    setIsMounted(true);
  }, []);
  
  useEffect(() => {
    // Wait for firebase user and data to be loaded
    if (firebaseUser && supervisors && therapists) {
      // Find if user is a supervisor
      const supervisor = supervisors.find(s => s.id === firebaseUser.uid);
      if (supervisor) {
        setCurrentUser({ id: firebaseUser.uid, role: 'supervisor', name: supervisor.name, data: supervisor });
        return;
      }
      
      // Find if user is a therapist
      const therapist = therapists.find(t => t.id === firebaseUser.uid);
       if (therapist) {
        setCurrentUser({ id: firebaseUser.uid, role: 'therapist', name: therapist.name, data: therapist });
        return;
      }

      // Default to admin if in neither collection (or handle as an error)
      const adminUser: User = {
        id: firebaseUser.uid,
        role: 'admin',
        name: firebaseUser.email || 'Administrador',
        data: { id: 'admin', name: 'Admin' }
      };
      setCurrentUser(adminUser);
    } else if (!isUserLoading) {
        setCurrentUser(null);
    }
  }, [firebaseUser, isUserLoading, supervisors, therapists]);

  useEffect(() => {
    if (typeof window !== 'undefined') {
      const root = document.documentElement;
      if (themeSettings.primary) root.style.setProperty('--primary', themeSettings.primary);
      if (themeSettings.background) root.style.setProperty('--background', themeSettings.background);
      if (themeSettings.accent) root.style.setProperty('--accent', themeSettings.accent);
    }
  }, [themeSettings]);


  const handleAccessGranted = (user: User) => {
    // This is now primarily for non-firebase authenticated users (patient codes)
    setCurrentUser(user);
  };

  const handleLogout = () => {
    if (currentUser?.role === 'admin' || currentUser?.role === 'supervisor' || currentUser?.role === 'therapist') {
      auth.signOut();
    }
    setCurrentUser(null);
  };

  const appState = {
    // Data is now sourced from Firestore hooks
    customTests: combinedTests,
    patientCodes,
    supervisors,
    therapists,
    testResults,
    clinicalInfo,
    therapistInfo,
    scheduledReminders: scheduledReminders || [],
    specialtyCategories: specialtyCategories || [],
    themeSettings,
    appConfig,
  };


  if (!isMounted || isUserLoading) {
    return <DashboardSkeleton />;
  }
  
  const renderContent = () => {
    if (isDataLoading && !currentUser) {
       return <DashboardSkeleton />;
    }

    if (!currentUser) {
      return <AccessScreen onAccessGranted={handleAccessGranted} appState={{patientCodes, supervisors, therapists}} />;
    }
    
    switch (currentUser.role) {
      case 'admin':
      case 'supervisor':
      case 'therapist':
        return <ProfessionalDashboard user={currentUser} onLogout={handleLogout} appState={appState} />;
      case 'patient':
        return <PatientDashboard user={currentUser} onLogout={handleLogout} appState={appState} />;
      default:
        return <AccessScreen onAccessGranted={handleAccessGranted} appState={{patientCodes, supervisors, therapists}} />;
    }
  };


  return (
    <>
      <header className="bg-background shadow-md px-4 sm:px-6 lg:px-8 py-3">
        <div className="flex items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            {themeSettings.logoUrl ? (
              <Image src={themeSettings.logoUrl} alt="Logo" width={40} height={40} className="object-contain" />
            ) : (
              <AreaChart className="h-10 w-10 text-primary/80" />
            )}
            <h1 id="app-title" className="text-3xl font-bold font-headline text-primary/90">MERICAPS</h1>
          </div>
          <div className="flex items-center gap-4">
            <a
              href="https://www.buymeacoffee.com/felipeconcha"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-block"
            >
              <Image
                src="https://cdn.buymeacoffee.com/buttons/v2/default-yellow.png"
                alt="Buy Me A Coffee"
                height={40}
                width={144}
                unoptimized
              />
            </a>
          </div>
        </div>
      </header>

      <main className="flex-grow bg-background">
        <div className="min-h-full">
            <div className="text-center pt-8 pb-4">
                <p id="test-instructions" className="text-lg text-foreground/60 mt-1">Aplicación de Medición Rutinaria e Investigación de Cambio en Psicoterapia</p>
            </div>
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pb-8">
                {renderContent()}
            </div>
        </div>
      </main>
    </>
  );
}

    
