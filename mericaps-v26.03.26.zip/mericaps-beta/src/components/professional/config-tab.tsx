
"use client";

import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Palette, Image as ImageIcon, Save, Loader2 } from 'lucide-react';
import type { ThemeSettings } from '@/lib/definitions';
import { Label } from '../ui/label';
import { Input } from '../ui/input';
import { useToast } from '@/hooks/use-toast';
import { saveAppConfig } from '@/lib/firestore-actions';

interface ConfigTabProps {
  themeSettings: ThemeSettings;
}

export function ConfigTab({ themeSettings: initialThemeSettings }: ConfigTabProps) {
  const { toast } = useToast();
  const [localTheme, setLocalTheme] = useState<ThemeSettings>(initialThemeSettings);
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    setLocalTheme(initialThemeSettings);
  }, [initialThemeSettings]);

  const handleThemeChange = (field: keyof ThemeSettings, value: string) => {
    setLocalTheme(prev => ({ ...prev, [field]: value }));
  };

  const saveTheme = async () => {
    setIsLoading(true);
    try {
      await saveAppConfig({ themeSettings: localTheme });
      toast({ title: "Tema guardado", description: "La apariencia ha sido actualizada para todos los usuarios." });
    } catch (error) {
      console.error("Error saving theme:", error);
      toast({
        variant: 'destructive',
        title: 'Error al guardar',
        description: 'No se pudo guardar la configuración del tema. Inténtalo de nuevo.',
      });
    } finally {
      setIsLoading(false);
    }
  };

  function hexToHsl(hex: string): string {
    if (!hex) return '';
    hex = hex.replace(/^#/, '');
    const r = parseInt(hex.substring(0, 2), 16) / 255;
    const g = parseInt(hex.substring(2, 4), 16) / 255;
    const b = parseInt(hex.substring(4, 6), 16) / 255;

    const max = Math.max(r, g, b);
    const min = Math.min(r, g, b);
    let h = 0, s = 0, l = (max + min) / 2;

    if (max !== min) {
      const d = max - min;
      s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
      switch (max) {
        case r: h = (g - b) / d + (g < b ? 6 : 0); break;
        case g: h = (b - r) / d + 2; break;
        case b: h = (r - g) / d + 4; break;
      }
      h /= 6;
    }
    h = Math.round(h * 360);
    s = Math.round(s * 100);
    l = Math.round(l * 100);
    return `${h} ${s}% ${l}%`;
  }

  function hslToHex(hsl: string): string {
    if (!hsl) return '#000000';
    let [h, s, l] = hsl.split(' ').map(val => parseFloat(val.replace('%', '')));
    s /= 100;
    l /= 100;
    const k = (n: number) => (n + h / 30) % 12;
    const a = s * Math.min(l, 1 - l);
    const f = (n: number) => l - a * Math.max(-1, Math.min(k(n) - 3, 9 - k(n), 1));
    return '#' + [0, 8, 4].map(n => Math.round(f(n) * 255).toString(16).padStart(2, '0')).join('');
  }

  const handleLogoUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      if (file.size > 1024 * 1024) { // 1MB limit
        toast({
          variant: 'destructive',
          title: 'Archivo demasiado grande',
          description: 'Por favor, elige una imagen de menos de 1MB.',
        });
        return;
      }
      const reader = new FileReader();
      reader.onload = (e) => {
        const result = e.target?.result;
        if (typeof result === 'string') {
          handleThemeChange('logoUrl', result);
        }
      };
      reader.readAsDataURL(file);
    }
  };


  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2"><Palette/> Personalización de Tema</CardTitle>
          <CardDescription>Ajusta los colores y el logo de la aplicación. Estos cambios se aplicarán a todos los usuarios.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4">
            <div>
              <Label htmlFor="primary-color">Color Primario</Label>
              <Input id="primary-color" type="color" value={hslToHex(localTheme.primary)} onChange={(e) => handleThemeChange('primary', hexToHsl(e.target.value))} />
            </div>
            <div>
              <Label htmlFor="background-color">Color de Fondo</Label>
              <Input id="background-color" type="color" value={hslToHex(localTheme.background)} onChange={(e) => handleThemeChange('background', hexToHsl(e.target.value))} />
            </div>
            <div>
              <Label htmlFor="accent-color">Color de Acento</Label>
              <Input id="accent-color" type="color" value={hslToHex(localTheme.accent)} onChange={(e) => handleThemeChange('accent', hexToHsl(e.target.value))} />
            </div>
          </div>
          <div>
            <Label htmlFor="logo-upload" className="flex items-center gap-2"><ImageIcon size={16}/> Subir Logo (Opcional, máx 1MB)</Label>
            <Input id="logo-upload" type="file" accept="image/*" onChange={handleLogoUpload} className="file:text-primary file:font-medium" />
          </div>
        </CardContent>
        <CardFooter>
          <Button onClick={saveTheme} disabled={isLoading}>
            {isLoading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Save className="mr-2 h-4 w-4"/>}
            {isLoading ? 'Guardando...' : 'Guardar Apariencia'}
          </Button>
        </CardFooter>
      </Card>
    </div>
  );
}
