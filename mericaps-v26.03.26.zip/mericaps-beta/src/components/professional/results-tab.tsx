"use client";

import { useState, useMemo, useEffect } from 'react';
import type { User, CustomTest, PatientCode, Supervisor, TestResult, ClinicalInfo, Therapist, TherapistInfo } from '@/lib/definitions';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';
import { Button } from '@/components/ui/button';
import * as Recharts from 'recharts';
import { ClinicalAnalysis } from './clinical-analysis';
import { Download, Trash2, Calendar as CalendarIcon, X as XIcon } from 'lucide-react';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from "@/components/ui/alert-dialog";
import { useToast } from '@/hooks/use-toast';
import { deleteTestResult } from '@/lib/firestore-actions';
import { Input } from '../ui/input';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Calendar } from '@/components/ui/calendar';
import { format, parseISO } from 'date-fns';
import { cn } from '@/lib/utils';
import type { DateRange } from 'react-day-picker';


interface ResultsTabProps {
  user: User;
  customTests: CustomTest[];
  patientCodes: PatientCode[];
  supervisors: Supervisor[];
  therapists: Therapist[];
  testResults: TestResult[];
  clinicalInfo: Record<string, ClinicalInfo>;
  therapistInfo: Record<string, TherapistInfo>;
}

function convertToCSV(data: any[], testConfigs: CustomTest[], therapists: Therapist[]) {
    if (data.length === 0) return '';

    const allVariableFields = testConfigs.flatMap(t => t.fields);
    
    // Create a map for quick lookup
    const variableMap = new Map(allVariableFields.map(f => [f.id, f.label]));
    testConfigs.forEach(test => {
        if (test.scoreCalculation && test.scoreCalculation.method !== 'none') {
            variableMap.set(`finalScore_${test.id}`, `Puntaje Final - ${test.name}`);
        }
    });


    const headers = [
        'patient_name', 
        'therapist_name',
        'test_date',
        'session_date',
        'test_type_name',
        'session_status',
        'not_completed_reason',
        'notes',
        ...Array.from(variableMap.keys()).map(id => variableMap.get(id) || id)
    ];

    const csvRows = [headers.join(',')];

    for (const row of data) {
        const testTypeName = testConfigs.find(t => t.id === row.test_type)?.name || row.test_type;
        const therapistName = therapists.find(t => t.id === row.assigned_therapist)?.name || 'N/A';

        const values = [
            `"${row.patient_name}"`,
            `"${therapistName}"`,
            `"${row.test_date}"`,
            `"${row.session_date}"`,
            `"${testTypeName}"`,
            `"${row.session_status}"`,
            `"${row.not_completed_reason}"`,
            `"${(row.notes || '').replace(/"/g, '""')}"`,
        ];

        const scores = { ...row.scores, [`finalScore_${row.test_type}`]: row.finalScore };

        for (const headerId of Array.from(variableMap.keys())) {
            const value = scores[headerId];
            if (value !== undefined) {
                 if (Array.isArray(value)) {
                    values.push(`"${value.join('; ')}"`);
                } else {
                    values.push(`"${String(value)}"`);
                }
            } else {
                values.push('');
            }
        }
        csvRows.push(values.join(','));
    }

    return csvRows.join('\n');
}

function getAbsenceReasonText(reason: string) {
    switch (reason) {
        case 'patient_cancelled':
            return 'Suspendió el paciente';
        case 'therapist_cancelled':
            return 'Suspendió el terapeuta';
        case 'no_show':
            return 'Paciente no llegó y no avisó';
        case 'patient_absence': // Legacy from new-test-tab
             return 'Inasistencia del Paciente';
        case 'therapist_suspension': // Legacy from new-test-tab
            return 'Suspensión por Parte del Terapeuta';
        case 'other':
            return 'Otro Motivo';
        default:
            return reason || 'No especificado';
    }
}


export function ResultsTab({ user, customTests = [], patientCodes, supervisors, therapists = [], testResults = [], clinicalInfo, therapistInfo }: ResultsTabProps) {
  const [patientFilter, setPatientFilter] = useState<string>('all');
  const [therapistFilter, setTherapistFilter] = useState<string>('all');
  const [testTypeFilter, setTestTypeFilter] = useState<Record<string, boolean>>({});
  const [selectedVariables, setSelectedVariables] = useState<Record<string, boolean>>({});
  const [variableColors, setVariableColors] = useState<Record<string, string>>({});
  const [dateRange, setDateRange] = useState<DateRange | undefined>(undefined);
  const { toast } = useToast();
  const [isLoading, setIsLoading] = useState(false);

  const selectedTestTypes = useMemo(() => Object.keys(testTypeFilter).filter(key => testTypeFilter[key]), [testTypeFilter]);
  
  const assignedTherapists = useMemo(() => {
    if (user.role !== 'supervisor') return [];
    const supervisor = user.data as Supervisor;
    return therapists.filter(t => supervisor.assignedTherapists.includes(t.id));
  }, [user, therapists]);


  const visibleTherapistIds = useMemo(() => {
    if (user.role === 'admin') {
      if (therapistFilter !== 'all') {
        return [therapistFilter];
      }
      return (therapists || []).map(t => t.id);
    }
    if (user.role === 'supervisor') {
      const supervisor = user.data as Supervisor;
      if (therapistFilter !== 'all') {
        return [therapistFilter];
      }
      return supervisor.assignedTherapists;
    }
    if (user.role === 'therapist') {
      return [user.id];
    }
    return [];
  }, [user, therapists, therapistFilter]);


  const visiblePatientNames = useMemo(() => {
    const patientsOfVisibleTherapists = patientCodes
        .filter(pc => pc.assignedTherapist && visibleTherapistIds.includes(pc.assignedTherapist))
        .map(pc => pc.patientName);
    
    const patientsFromResults = testResults
        .filter(r => r.assigned_therapist && visibleTherapistIds.includes(r.assigned_therapist))
        .map(r => r.patient_name);

    return [...new Set([...patientsOfVisibleTherapists, ...patientsFromResults])];
  }, [patientCodes, testResults, visibleTherapistIds]);


  const filteredResults = useMemo(() => {
    let results = testResults.filter(r => visiblePatientNames.includes(r.patient_name));
    
    if (patientFilter && patientFilter !== 'all') {
      results = results.filter(r => r.patient_name === patientFilter);
    }
    if (selectedTestTypes.length > 0) {
      results = results.filter(r => selectedTestTypes.includes(r.test_type));
    }
    if (dateRange?.from) {
        results = results.filter(r => parseISO(r.session_date) >= dateRange.from!);
    }
    if (dateRange?.to) {
        results = results.filter(r => parseISO(r.session_date) <= dateRange.to!);
    }

    return results;
  }, [testResults, patientFilter, selectedTestTypes, visiblePatientNames, dateRange]);

  const patientOptions = useMemo(() => {
    return [...new Set(visiblePatientNames)].sort();
  }, [visiblePatientNames]);

  const testTypeOptions = useMemo(() => {
    const usedTestTypes = [...new Set(testResults.map(r => r.test_type))];
    return usedTestTypes.map(type => {
      const test = (customTests || []).find(t => t.id === type);
      return {
        value: type,
        label: test?.name || type,
      }
    })
  }, [testResults, customTests]);

  const availableVariables = useMemo(() => {
    if (selectedTestTypes.length === 0) return [];
  
    let variables = selectedTestTypes.flatMap(testId => {
      const testConfig = customTests.find(t => t.id === testId);
      if (!testConfig) return [];
      return testConfig.fields.filter(f => ['slider', 'number', 'likert', 'yes_no'].includes(f.type));
    });
  
    selectedTestTypes.forEach(testId => {
        const testConfig = customTests.find(t => t.id === testId);
        if (testConfig?.scoreCalculation && testConfig.scoreCalculation.method !== 'none') {
            variables.push({
                id: `finalScore_${testId}`,
                label: `Puntaje Final - ${testConfig.name}`,
                color: '#8b5cf6',
                type: 'number',
                config: {}
            } as any);
        }
    });
  
    const uniqueVariables = Array.from(new Map(variables.map(item => [item.id, item])).values());
    return uniqueVariables;
  
  }, [selectedTestTypes, customTests]);

  useEffect(() => {
    // When a patient is selected, automatically apply the default test filters
    if (user.role !== 'therapist') {
      return;
    }

    if (patientFilter === 'all') {
      setTestTypeFilter({}); // Clear filters when going back to "all"
      return;
    }

    const info = therapistInfo[user.id];
    const defaultTestIds = info?.defaultTestVariables ? Object.keys(info.defaultTestVariables) : [];
    
    // Find which of the default-configured tests the selected patient actually has results for
    const patientTestTypes = new Set(
        testResults
            .filter(r => r.patient_name === patientFilter)
            .map(r => r.test_type)
    );

    const newTestTypeFilter: Record<string, boolean> = {};
    defaultTestIds.forEach(testId => {
        if (patientTestTypes.has(testId)) {
            newTestTypeFilter[testId] = true;
        }
    });

    // This will set the filter to the defaults for the selected patient, or clear it if they have no relevant tests
    setTestTypeFilter(newTestTypeFilter);

  }, [patientFilter, user.id, user.role, therapistInfo, testResults]);
  
  useEffect(() => {
    const newColors: Record<string, string> = {};
    availableVariables.forEach(v => {
      if (!variableColors[v.id]) { // Only set default if not already set by user
        newColors[v.id] = v.color || '#000000';
      }
    });
    if (Object.keys(newColors).length > 0) {
      setVariableColors(prev => ({ ...prev, ...newColors }));
    }
  }, [availableVariables, variableColors]);

  useEffect(() => {
    if (user.role !== 'therapist') {
      return;
    }

    const info = therapistInfo[user.id];
    if (!info?.defaultTestVariables) {
      setSelectedVariables({});
      return;
    }

    const newSelectedVariables: Record<string, boolean> = {};
    selectedTestTypes.forEach(testId => {
      const defaultVars = info.defaultTestVariables?.[testId];
      if (defaultVars && defaultVars.length > 0) {
        defaultVars.forEach(varId => {
          newSelectedVariables[varId] = true;
        });
      }
    });

    setSelectedVariables(newSelectedVariables);

  }, [testTypeFilter, user, therapistInfo]);


  const chartData = useMemo(() => {
    const sortedResults = [...filteredResults]
      .filter(r => r.session_status === 'completed')
      .sort((a, b) => new Date(a.session_date).getTime() - new Date(a.session_date).getTime());
    
    if (patientFilter !== 'all') {
      return sortedResults.map(r => {
        const formattedDate = new Date(r.session_date).toLocaleDateString('es-ES', { day: '2-digit', month: 'short' });
        const dataPoint: { [key: string]: any } = { date: formattedDate, patientName: r.patient_name };
        
        for (const key in r.scores) {
          const value = r.scores[key];
          if (typeof value === 'number' || (typeof value === 'string' && !isNaN(Number(value)))) {
            dataPoint[key] = Number(value);
          }
        }
        if (r.finalScore !== undefined) {
          dataPoint[`finalScore_${r.test_type}`] = r.finalScore;
        }
        return dataPoint;
      });
    } else {
      const groupedByDate: Record<string, { [key: string]: { sum: number, count: number } }> = {};

      for (const r of sortedResults) {
        const formattedDate = new Date(r.session_date).toLocaleDateString('es-ES', { day: '2-digit', month: 'short' });
        if (!groupedByDate[formattedDate]) {
          groupedByDate[formattedDate] = {};
        }

        const processScore = (key: string, value: any) => {
          const numericValue = Number(value);
          if (isNaN(numericValue)) return;

          if (!groupedByDate[formattedDate][key]) {
            groupedByDate[formattedDate][key] = { sum: 0, count: 0 };
          }
          groupedByDate[formattedDate][key].sum += numericValue;
          groupedByDate[formattedDate][key].count++;
        };

        for (const key in r.scores) {
          processScore(key, r.scores[key]);
        }
        if (r.finalScore !== undefined) {
          processScore(`finalScore_${r.test_type}`, r.finalScore);
        }
      }
      
      return Object.keys(groupedByDate).map(date => {
        const avgData: { [key: string]: any } = { date };
        for (const key in groupedByDate[date]) {
          avgData[key] = groupedByDate[date][key].sum / groupedByDate[date][key].count;
        }
        return avgData;
      });
    }
  }, [filteredResults, patientFilter]);

  const selectedTestConfigs = useMemo(() => {
    if (selectedTestTypes.length === 0) return [];
    return selectedTestTypes.map(id => customTests.find(t => t.id === id)).filter(t => t !== undefined) as CustomTest[];
  }, [selectedTestTypes, customTests]);

    const handleExport = () => {
    const csvData = convertToCSV(filteredResults, customTests, therapists);
    const blob = new Blob([csvData], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    if (link.download !== undefined) {
        const url = URL.createObjectURL(blob);
        link.setAttribute('href', url);
        link.setAttribute('download', `resultados_${new Date().toISOString().split('T')[0]}.csv`);
        link.style.visibility = 'hidden';
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    }
  };
  
    const handleDeleteResult = async (resultId: string) => {
        setIsLoading(true);
        try {
          await deleteTestResult(resultId);
          toast({ title: 'Éxito', description: 'El registro del test ha sido eliminado.' });
        } catch (error) {
          console.error("Error deleting result: ", error);
          toast({ variant: 'destructive', title: 'Error', description: 'No se pudo eliminar el registro.' });
        } finally {
          setIsLoading(false);
        }
    };


  const isAggregatedView = patientFilter === 'all';
  const canShowAiAnalysis = false;
  const therapistOptions = user.role === 'admin' ? therapists : assignedTherapists;

  return (
    <div className="space-y-8">
      <Card>
        <CardHeader>
          <CardTitle>Resultados de Evaluaciones</CardTitle>
          <CardDescription>Filtra y visualiza los resultados de los tests completados. Puedes ver datos individuales o promedios de grupo.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="space-y-4">
            <div className="flex flex-wrap gap-4 items-center">
              { (user.role === 'supervisor' || user.role === 'admin') && (
                <Select value={therapistFilter} onValueChange={setTherapistFilter}>
                  <SelectTrigger className="w-auto min-w-[200px]"><SelectValue placeholder="Todos los Terapeutas" /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Todos los Terapeutas</SelectItem>
                    {therapistOptions.map(t => <SelectItem key={t.id} value={t.id}>{t.name}</SelectItem>)}
                  </SelectContent>
                </Select>
              )}
              <Select value={patientFilter} onValueChange={setPatientFilter}>
                <SelectTrigger className="w-auto min-w-[200px]"><SelectValue placeholder="Todos los Pacientes" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Todos (Gráficos agregados)</SelectItem>
                  {patientOptions.map(p => <SelectItem key={p} value={p}>{p}</SelectItem>)}
                </SelectContent>
              </Select>

              <Popover>
                <PopoverTrigger asChild>
                  <Button
                    id="date"
                    variant={"outline"}
                    className={cn(
                      "w-auto min-w-[260px] justify-start text-left font-normal",
                      !dateRange && "text-muted-foreground"
                    )}
                  >
                    <CalendarIcon className="mr-2 h-4 w-4" />
                    {dateRange?.from ? (
                      dateRange.to ? (
                        <>
                          {format(dateRange.from, "LLL dd, y")} -{" "}
                          {format(dateRange.to, "LLL dd, y")}
                        </>
                      ) : (
                        format(dateRange.from, "LLL dd, y")
                      )
                    ) : (
                      <span>Elige un rango de fechas</span>
                    )}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0" align="start">
                  <Calendar
                    initialFocus
                    mode="range"
                    defaultMonth={dateRange?.from}
                    selected={dateRange}
                    onSelect={setDateRange}
                    numberOfMonths={2}
                  />
                </PopoverContent>
              </Popover>
              {dateRange && (
                  <Button variant="ghost" size="sm" onClick={() => setDateRange(undefined)}>
                      <XIcon className="mr-2 h-4 w-4" />
                      Limpiar
                  </Button>
              )}
            </div>
            
            <div className="flex flex-wrap gap-4 items-center">
              <Button onClick={handleExport} variant="outline" disabled={filteredResults.length === 0}>
                <Download className="mr-2 h-4 w-4" />
                Exportar a CSV
              </Button>
            </div>
          </div>
          <div>
            <h4 className="font-semibold mb-2">Tests a Mostrar</h4>
            <div className="flex flex-wrap gap-4 p-4 border rounded-md">
                {testTypeOptions.map(t => (
                    <div key={t.value} className="flex items-center space-x-2">
                        <Checkbox id={`test-type-${t.value}`} checked={!!testTypeFilter[t.value]} onCheckedChange={checked => setTestTypeFilter(prev => ({...prev, [t.value]: !!checked}))} />
                        <label htmlFor={`test-type-${t.value}`} className="text-sm">{t.label}</label>
                    </div>
                ))}
            </div>
          </div>
          {selectedTestTypes.length > 0 && (
            <div>
              <h4 className="font-semibold mb-2">Variables a Mostrar</h4>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-4 p-4 border rounded-md">
                {availableVariables.length > 0 ? availableVariables.map(v => (
                  <div key={v.id} className="flex items-center space-x-2">
                    <Checkbox id={`var-${v.id}`} checked={!!selectedVariables[v.id]} onCheckedChange={checked => setSelectedVariables(prev => ({...prev, [v.id]: !!checked}))} />
                    <Input type="color" value={variableColors[v.id] || '#000000'} onChange={e => setVariableColors(prev => ({ ...prev, [v.id]: e.target.value }))} className="h-6 w-6 p-0.5"/>
                    <label htmlFor={`var-${v.id}`} className="text-sm">{v.label}</label>
                  </div>
                )) : <p className="text-sm text-muted-foreground">Este test no contiene variables graficables (slider, numéricas, likert).</p>}
              </div>
            </div>
          )}
        </CardContent>
      </Card>
      
      {chartData.length > 0 && Object.keys(selectedVariables).some(k => selectedVariables[k]) && (
        <Card>
            <CardHeader><CardTitle>Visualización Gráfica</CardTitle></CardHeader>
            <CardContent>
                <div>
                    <h3 className="text-lg font-semibold mb-4">{isAggregatedView ? "Evolución Promedio del Grupo" : "Evolución por Sesiones"}</h3>
                    <Recharts.ResponsiveContainer width="100%" height={300}>
                        <Recharts.LineChart data={chartData}>
                            <Recharts.CartesianGrid strokeDasharray="3 3" />
                            <Recharts.XAxis dataKey="date" />
                            <Recharts.YAxis domain={[0, 'auto']} />
                            <Recharts.Tooltip />
                            <Recharts.Legend />
                            {availableVariables.filter(v => selectedVariables[v.id]).map(v => (
                                <Recharts.Line key={v.id} type="monotone" dataKey={v.id} name={v.label} stroke={variableColors[v.id]} strokeWidth={2} connectNulls />
                            ))}
                            {selectedTestConfigs.map(testConfig => 
                                testConfig?.cutoffScore ? (
                                <Recharts.ReferenceLine key={`cutoff-${testConfig.id}`} y={testConfig.cutoffScore} label={{ value: `Corte (${testConfig.name})`, position: 'insideTopRight' }} stroke="hsl(var(--destructive))" strokeDasharray="3 3" />
                            ) : null)}
                        </Recharts.LineChart>
                    </Recharts.ResponsiveContainer>
                </div>
            </CardContent>
        </Card>
      )}

      {canShowAiAnalysis &&
        <Card>
            <CardHeader><CardTitle>Análisis Clínico con IA</CardTitle></CardHeader>
            <CardContent>
                <ClinicalAnalysis patientName={patientFilter} testResults={filteredResults.filter(r => r.session_status === 'completed')} clinicalInfo={clinicalInfo[patientFilter]} />
            </CardContent>
        </Card>
      }

      <Card>
        <CardHeader><CardTitle>Historial de Evaluaciones</CardTitle></CardHeader>
        <CardContent>
            <div className="space-y-4">
                {patientFilter === 'all' ? (
                  <p className="text-muted-foreground text-center py-8">Por favor, selecciona un paciente para ver su historial detallado.</p>
                ) : filteredResults.length > 0 ? (
                  [...filteredResults].sort((a, b) => new Date(b.session_date).getTime() - new Date(a.session_date).getTime()).map(r => {
                    const testLabel = r.test_type === 'absence' ? 'Inasistencia' : testTypeOptions.find(t=>t.value === r.test_type)?.label;
                    
                    return (
                        <div key={r.id} className={cn("border p-4 rounded-lg", r.session_status === 'not-completed' && 'bg-muted/50')}>
                            <div className="flex justify-between items-start">
                                <div>
                                    <h4 className="font-semibold">{r.patient_name}</h4>
                                    <p className="text-sm text-muted-foreground">{new Date(r.session_date).toLocaleDateString('es-ES')} - {testLabel}</p>
                                    { user.role === 'supervisor' && <p className="text-xs text-muted-foreground">Terapeuta: {therapists.find(t => t.id === r.assigned_therapist)?.name || 'N/A'}</p> }
                                </div>
                                <AlertDialog>
                                    <AlertDialogTrigger asChild>
                                        <Button variant="destructive" size="sm" disabled={isLoading}><Trash2 className="mr-2 h-4 w-4"/>Eliminar</Button>
                                    </AlertDialogTrigger>
                                    <AlertDialogContent>
                                        <AlertDialogHeader>
                                            <AlertDialogTitle>¿Confirmar eliminación?</AlertDialogTitle>
                                            <AlertDialogDescription>Se eliminará este registro permanentemente.</AlertDialogDescription>
                                        </AlertDialogHeader>
                                        <AlertDialogFooter>
                                            <AlertDialogCancel>Cancelar</AlertDialogCancel>
                                            <AlertDialogAction onClick={() => handleDeleteResult(r.id)}>Eliminar</AlertDialogAction>
                                        </AlertDialogFooter>
                                    </AlertDialogContent>
                                </AlertDialog>
                            </div>
                            {r.session_status === 'completed' ? (
                                <>
                                    <div className="flex flex-wrap gap-4 mt-2">
                                        {r.finalScore !== undefined && r.finalScore !== null && (
                                        <div className="text-sm">
                                            <span className="font-medium" style={{color: '#8b5cf6'}}>Puntaje Final: </span>
                                            <span>{typeof r.finalScore === 'number' ? r.finalScore.toFixed(2) : r.finalScore}</span>
                                        </div>
                                        )}
                                        {Object.entries(r.scores).map(([key, value]) => {
                                            const variable = customTests.flatMap(t => t.fields).find(v => v.id === key);
                                            return (
                                            <div key={key} className="text-sm">
                                                <span className="font-medium" style={{color: variableColors[key]}}>{variable?.label || key}: </span>
                                                <span>{Array.isArray(value) ? value.join(', ') : String(value)}</span>
                                            </div>
                                        )})}
                                    </div>
                                    {r.notes && <p className="text-sm mt-2 pt-2 border-t"><strong>Notas:</strong> {r.notes}</p>}
                                </>
                            ) : (
                                <div className="mt-2 pt-2 border-t">
                                    <p className="text-sm font-semibold text-destructive">Sesión no realizada</p>
                                    <p className="text-sm text-muted-foreground">Motivo: {getAbsenceReasonText(r.not_completed_reason)}</p>
                                    {r.notes && <p className="text-sm mt-2"><strong>Notas:</strong> {r.notes}</p>}
                                </div>
                            )}
                        </div>
                    );
                  })
                ) : (
                  <p className="text-muted-foreground text-center py-8">No hay resultados para los filtros seleccionados.</p>
                )}
            </div>
        </CardContent>
      </Card>
    </div>
  );
}
