
"use client";

import { useMemo, useState } from 'react';
import type { User, TestResult, CustomTest, PatientCode, Supervisor, Therapist, TherapistInfo } from '@/lib/definitions';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { AlertCircle, TrendingUp, TrendingDown, Maximize, Minimize, ChevronDown, ChevronUp } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip"
import { Button } from '../ui/button';
import { cn } from '@/lib/utils';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import * as React from 'react';
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip as ChartTooltip,
  Legend,
  ResponsiveContainer,
  ReferenceLine
} from 'recharts';


// New component for the inline chart
function PatientQuickChart({ patientName, userId, allTestResults, customTests, therapistInfo }: {
  patientName: string;
  userId: string;
  allTestResults: TestResult[];
  customTests: CustomTest[];
  therapistInfo: Record<string, TherapistInfo>;
}) {
  const { defaultTests, defaultVariables, variableColors } = useMemo(() => {
    const info = therapistInfo[userId];
    if (!info?.defaultTestVariables) {
      return { defaultTests: [], defaultVariables: {}, variableColors: {} };
    }

    const patientTestTypes = new Set(
      allTestResults
        .filter(r => r.patient_name === patientName)
        .map(r => r.test_type)
    );

    const testsToShow = Object.keys(info.defaultTestVariables).filter(testId => patientTestTypes.has(testId));
    
    const variablesToShow: Record<string, boolean> = {};
    const colors: Record<string, string> = {};

    testsToShow.forEach(testId => {
      const testConfig = customTests.find(t => t.id === testId);
      info.defaultTestVariables?.[testId]?.forEach(varId => {
        variablesToShow[varId] = true;
        const field = testConfig?.fields.find(f => f.id === varId);
        if (field) {
            colors[varId] = field.color || '#000000';
        } else if (varId.startsWith('finalScore')) {
            colors[varId] = '#8b5cf6'; // Default final score color
        }
      });
    });

    return { defaultTests: testsToShow, defaultVariables: variablesToShow, variableColors: colors };
  }, [userId, patientName, allTestResults, customTests, therapistInfo]);

  const chartData = useMemo(() => {
    const results = allTestResults.filter(r => 
        r.patient_name === patientName && 
        defaultTests.includes(r.test_type) &&
        r.session_status === 'completed'
    ).sort((a, b) => new Date(a.session_date).getTime() - new Date(b.session_date).getTime());

    return results.map(r => {
      const formattedDate = new Date(r.session_date).toLocaleDateString('es-ES', { day: '2-digit', month: 'short' });
      const dataPoint: { [key: string]: any } = { date: formattedDate };
      
      for (const key in r.scores) {
        const value = r.scores[key];
        if (typeof value === 'number' || (typeof value === 'string' && !isNaN(Number(value)))) {
          dataPoint[key] = Number(value);
        }
      }
      if (r.finalScore !== undefined) {
        dataPoint[`finalScore_${r.test_type}`] = r.finalScore;
      }
      return dataPoint;
    });
  }, [patientName, allTestResults, defaultTests]);

  const variablesToPlot = useMemo(() => {
     let vars = defaultTests.flatMap(testId => {
      const testConfig = customTests.find(t => t.id === testId);
      if (!testConfig) return [];
      return testConfig.fields.filter(f => ['slider', 'number', 'likert', 'yes_no'].includes(f.type) && defaultVariables[f.id]);
    });
  
    defaultTests.forEach(testId => {
        const testConfig = customTests.find(t => t.id === testId);
        if (testConfig?.scoreCalculation?.method !== 'none' && defaultVariables[`finalScore_${testId}`]) {
            vars.push({
                id: `finalScore_${testId}`,
                label: `Puntaje Final - ${testConfig.name}`,
            } as any);
        }
    });

    return Array.from(new Map(vars.map(item => [item.id, item])).values());
  }, [defaultTests, defaultVariables, customTests]);

  if (variablesToPlot.length === 0) {
    return (
      <div className="p-6 text-center text-muted-foreground bg-secondary/30">
        <p>No hay una vista de gráfico por defecto para este paciente.</p>
        <p className="text-xs mt-1">Puedes configurar los gráficos por defecto en la pestaña "Mi Perfil".</p>
      </div>
    );
  }

  return (
    <div className="p-4 bg-background">
      <ResponsiveContainer width="100%" height={250}>
        <LineChart data={chartData}>
          <CartesianGrid strokeDasharray="3 3" />
          <XAxis dataKey="date" />
          <YAxis domain={[0, 'auto']} />
          <ChartTooltip />
          <Legend />
          {variablesToPlot.map(v => (
            <Line key={v.id} type="monotone" dataKey={v.id} name={v.label} stroke={variableColors[v.id]} strokeWidth={2} connectNulls />
          ))}
          {defaultTests.map(testId => {
             const testConfig = customTests.find(t => t.id === testId);
             return testConfig?.cutoffScore ? (
                <ReferenceLine key={`cutoff-${testConfig.id}`} y={testConfig.cutoffScore} label={{ value: `Corte (${testConfig.name})`, position: 'insideTopRight' }} stroke="hsl(var(--destructive))" strokeDasharray="3 3" />
            ) : null;
          })}
        </LineChart>
      </ResponsiveContainer>
    </div>
  );
}


interface ClinicalDashboardProps {
  user: User;
  testResults: TestResult[];
  customTests: CustomTest[];
  patientCodes: PatientCode[];
  therapists: Therapist[];
  supervisors: Supervisor[];
  therapistInfo: Record<string, TherapistInfo>;
  onStartQuickTest: (patientName: string, testId: string) => void;
}

export function ClinicalDashboard({ user, testResults = [], customTests = [], patientCodes = [], therapists = [], supervisors = [], therapistInfo = {}, onStartQuickTest }: ClinicalDashboardProps) {
  const [isExpanded, setIsExpanded] = useState(false);
  const [therapistFilter, setTherapistFilter] = useState<string>('all');
  const [expandedPatient, setExpandedPatient] = useState<string | null>(null);

  const assignedTherapists = useMemo(() => {
    if (user.role !== 'supervisor') return [];
    const supervisor = user.data as Supervisor;
    return therapists.filter(t => supervisor.assignedTherapists.includes(t.id));
  }, [user, therapists]);

  const patientTherapistMap = useMemo(() => {
    const map = new Map<string, { therapistId: string, therapistName: string }>();
    const allTherapists = [...therapists, ...supervisors.map(s => ({ id: s.id, name: `${s.name} (Sup.)` } as Therapist))];

    patientCodes.forEach(pc => {
      const therapist = allTherapists.find(t => t.id === pc.assignedTherapist);
      if (therapist && !map.has(pc.patientName)) {
        map.set(pc.patientName, { therapistId: therapist.id, therapistName: therapist.name });
      }
    });

    testResults.forEach(r => {
      const therapist = allTherapists.find(t => t.id === r.assigned_therapist);
      if (therapist && !map.has(r.patient_name)) {
        map.set(r.patient_name, { therapistId: therapist.id, therapistName: therapist.name });
      }
    });

    return map;
  }, [patientCodes, testResults, therapists, supervisors]);


  const visiblePatientNames = useMemo(() => {
    let patientNames = new Set<string>();
    
    if (user.role === 'therapist') {
      testResults.forEach(r => { if (r.assigned_therapist === user.id) patientNames.add(r.patient_name) });
      patientCodes.forEach(pc => { if (pc.assignedTherapist === user.id) patientNames.add(pc.patientName) });
    }
    
    if (user.role === 'supervisor') {
      const supervisor = user.data as Supervisor;
      let assignedTherapistIds = new Set(supervisor.assignedTherapists);
      if (therapistFilter !== 'all') {
        assignedTherapistIds = new Set([therapistFilter]);
      }

      testResults.forEach(r => { 
        if (r.assigned_therapist && assignedTherapistIds.has(r.assigned_therapist)) {
          patientNames.add(r.patient_name)
        }
      });
      patientCodes.forEach(pc => { 
        if (pc.assignedTherapist && assignedTherapistIds.has(pc.assignedTherapist)) {
          patientNames.add(pc.patientName)
        }
      });
    }

    return Array.from(patientNames).sort();
  }, [user, testResults, patientCodes, therapistFilter]);

  const dashboardData = useMemo(() => {
    return visiblePatientNames.map(patientName => {
      const patientResults = testResults
        .filter(r => r.patient_name === patientName)
        .sort((a, b) => new Date(b.session_date).getTime() - new Date(a.session_date).getTime());

      // 1. Alert in last response
      let lastResponseAlert = 'no';
      if (patientResults.length > 0) {
        const lastResult = patientResults[0];
        const testConfig = customTests.find(t => t.id === lastResult.test_type);
        if (testConfig && lastResult.session_status === 'completed') {
          for (const field of testConfig.fields) {
            if (field.alertEnabled && typeof field.alertThreshold === 'number') {
              const scoreValue = Number(lastResult.scores[field.id]);
              if (!isNaN(scoreValue) && scoreValue >= field.alertThreshold) {
                lastResponseAlert = 'yes';
                break;
              }
            }
          }
        }
      }

      // 2. Attendances and Absences
      const attendances = patientResults.filter(r => r.session_status === 'completed').length;
      const absences = patientResults.filter(r => r.session_status === 'not-completed').length;
      const totalSessions = attendances + absences;
      const attendanceRate = totalSessions > 0 ? (attendances / totalSessions) * 100 : 0;

      // 3. Score changes (therapeutic and alliance)
      const getScoreChange = (testIdPrefix: string) => {
        const relevantResults = patientResults
            .filter(r => r.test_type.startsWith(testIdPrefix) && r.finalScore !== undefined && r.session_status === 'completed');

        if (relevantResults.length < 2) return null; // Not enough data
        
        const lastScore = relevantResults[0].finalScore!;
        const penultimateScore = relevantResults[1].finalScore!;
        return penultimateScore - lastScore; // Positive means improvement
      };

      const therapeuticChange = getScoreChange('phq') ?? getScoreChange('gad');
      const allianceChange = getScoreChange('srs');

      return {
        patientName,
        therapistName: patientTherapistMap.get(patientName)?.therapistName || 'N/A',
        lastResponseAlert,
        attendances,
        absences,
        attendanceRate,
        therapeuticChange,
        allianceChange
      };
    });
  }, [visiblePatientNames, testResults, customTests, patientTherapistMap]);

  const testsForQuickAccess = useMemo(() => {
    if (user.role === 'therapist') {
      const info = therapistInfo[user.id];
      if (info?.quickAccessTests && info.quickAccessTests.length > 0) {
        return info.quickAccessTests
          .map(testId => customTests.find(t => t.id === testId))
          .filter((t): t is CustomTest => t !== undefined);
      }
    }
    // For supervisors or admins, or therapists without custom settings, show all
    return customTests;
  }, [user, therapistInfo, customTests]);


  if (dashboardData.length === 0 && user.role !== 'supervisor') {
    return null; // Don't show the dashboard if there's no data for the user
  }

  const renderChange = (change: number | null) => {
    if (change === null || change === 0) return <span className="text-muted-foreground">-</span>;
    const isImprovement = change > 0;
    return (
      <span className={`flex items-center gap-1 font-medium ${isImprovement ? 'text-green-600' : 'text-red-600'}`}>
        {isImprovement ? <TrendingUp size={16}/> : <TrendingDown size={16}/>}
        {change.toFixed(2)}
      </span>
    );
  };
  
  const colSpan = user.role === 'supervisor' ? 9 : 8;
  
  return (
    <Card>
      <CardHeader className="flex flex-col sm:flex-row items-start justify-between gap-4">
        <div>
          <CardTitle>Panel Clínico Rápido</CardTitle>
          <CardDescription>Resumen de métricas clave de tus pacientes para guiar la atención.</CardDescription>
        </div>
        <div className="flex gap-2">
          {user.role === 'supervisor' && (
            <Select value={therapistFilter} onValueChange={setTherapistFilter}>
              <SelectTrigger className="w-[200px]">
                <SelectValue placeholder="Filtrar por terapeuta" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todos los Terapeutas</SelectItem>
                {assignedTherapists.map(t => <SelectItem key={t.id} value={t.id}>{t.name}</SelectItem>)}
              </SelectContent>
            </Select>
          )}
          {dashboardData.length > 3 && (
              <Button variant="outline" size="sm" onClick={() => setIsExpanded(!isExpanded)}>
                {isExpanded ? <Minimize className="mr-2 h-4 w-4" /> : <Maximize className="mr-2 h-4 w-4" />}
                {isExpanded ? 'Ver menos' : 'Ver más'}
              </Button>
          )}
        </div>
      </CardHeader>
      <CardContent className={cn("overflow-y-auto transition-all duration-300", isExpanded ? "max-h-[600px]" : "max-h-[260px]")}>
        <TooltipProvider>
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Paciente</TableHead>
              <TableHead>Acceso Directo</TableHead>
              {user.role === 'supervisor' && <TableHead>Terapeuta</TableHead>}
              <TableHead className="text-center">Alerta Última Resp.</TableHead>
              <TableHead className="text-center">Asist.</TableHead>
              <TableHead className="text-center">Ausen.</TableHead>
              <TableHead className="text-center">Tasa Asistencia</TableHead>
              <TableHead className="text-center">Δ Res. Terapéutico</TableHead>
              <TableHead className="text-center">Δ Alianza</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {dashboardData.map((data) => (
              <React.Fragment key={data.patientName}>
                <TableRow>
                  <TableCell 
                    className="font-medium cursor-pointer hover:text-primary"
                    onClick={() => setExpandedPatient(expandedPatient === data.patientName ? null : data.patientName)}
                  >
                    <div className="flex items-center gap-2">
                      {expandedPatient === data.patientName ? <ChevronUp size={16} /> : <ChevronDown size={16} />}
                      {data.patientName}
                    </div>
                  </TableCell>
                  <TableCell>
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="outline" size="sm">Iniciar Test</Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="start">
                        {testsForQuickAccess.length > 0 ? (
                          testsForQuickAccess.map(test => (
                            <DropdownMenuItem key={test.id} onSelect={() => onStartQuickTest(data.patientName, test.id)}>
                              {test.name}
                            </DropdownMenuItem>
                          ))
                        ) : (
                          <DropdownMenuItem disabled>No hay tests disponibles</DropdownMenuItem>
                        )}
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </TableCell>
                  {user.role === 'supervisor' && <TableCell>{data.therapistName}</TableCell>}
                  <TableCell className="text-center">
                    {data.lastResponseAlert === 'yes' ? 
                      <Badge variant="destructive" className="flex items-center gap-1 w-fit mx-auto"><AlertCircle size={14}/> SÍ</Badge>
                       : 
                      <Badge variant="secondary">No</Badge>
                    }
                  </TableCell>
                  <TableCell className="text-center">{data.attendances}</TableCell>
                  <TableCell className="text-center">{data.absences}</TableCell>
                  <TableCell className="text-center">{data.attendanceRate.toFixed(0)}%</TableCell>
                  <TableCell className="text-center">
                    <Tooltip>
                      <TooltipTrigger asChild><div className="flex justify-center">{renderChange(data.therapeuticChange)}</div></TooltipTrigger>
                      <TooltipContent><p>Diferencia entre penúltima y última sesión (PHQ-9/GAD-7)</p></TooltipContent>
                    </Tooltip>
                  </TableCell>
                  <TableCell className="text-center">
                    <Tooltip>
                      <TooltipTrigger asChild><div className="flex justify-center">{renderChange(data.allianceChange)}</div></TooltipTrigger>
                      <TooltipContent><p>Diferencia entre penúltima y última sesión (SRS)</p></TooltipContent>
                    </Tooltip>
                  </TableCell>
                </TableRow>
                {expandedPatient === data.patientName && (
                  <TableRow>
                    <TableCell colSpan={colSpan} className="p-0">
                      <PatientQuickChart 
                        patientName={data.patientName}
                        userId={user.id}
                        allTestResults={testResults}
                        customTests={customTests}
                        therapistInfo={therapistInfo}
                      />
                    </TableCell>
                  </TableRow>
                )}
              </React.Fragment>
            ))}
          </TableBody>
        </Table>
        </TooltipProvider>
      </CardContent>
    </Card>
  );
}
