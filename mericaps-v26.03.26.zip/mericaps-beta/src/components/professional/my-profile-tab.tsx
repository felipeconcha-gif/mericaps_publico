
"use client";

import { useState, useEffect, useMemo } from 'react';
import type { User, TherapistInfo, SpecialtyCategory, CustomTest } from '@/lib/definitions';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { useToast } from '@/hooks/use-toast';
import { saveTherapistInfo, saveSpecialtyCategory } from '@/lib/firestore-actions';
import { User as UserIcon, BookOpen, BrainCircuit, Linkedin, Link as LinkIcon, Plus, Settings2 } from 'lucide-react';
import { Checkbox } from '../ui/checkbox';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '../ui/accordion';

interface MyProfileTabProps {
  user: User;
  therapistInfo: Record<string, TherapistInfo>;
  specialtyCategories: SpecialtyCategory[];
  customTests: CustomTest[];
}

export function MyProfileTab({ user, therapistInfo, specialtyCategories = [], customTests = [] }: MyProfileTabProps) {
  const { toast } = useToast();
  const [currentInfo, setCurrentInfo] = useState<Partial<TherapistInfo>>({});
  const [newSpecialty, setNewSpecialty] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    if (user.role === 'therapist') {
      setCurrentInfo(therapistInfo[user.id] || { specialties: [], quickAccessTests: [], defaultTestVariables: {} });
    }
  }, [user, therapistInfo]);

  const handleInfoChange = (field: keyof Omit<TherapistInfo, 'id' | 'lastUpdated'>, value: any) => {
    setCurrentInfo(prev => ({ ...prev, [field]: value }));
  };

  const handleSpecialtyToggle = (specialtyId: string, isChecked: boolean) => {
    const currentSpecialties = currentInfo.specialties || [];
    let newSpecialties;
    if (isChecked) {
        newSpecialties = [...currentSpecialties, specialtyId];
    } else {
        newSpecialties = currentSpecialties.filter(id => id !== specialtyId);
    }
    handleInfoChange('specialties', newSpecialties);
  };
  
  const handleQuickAccessToggle = (testId: string, isChecked: boolean) => {
    const currentTests = currentInfo.quickAccessTests || [];
    let newTests;
    if (isChecked) {
        newTests = [...currentTests, testId];
    } else {
        newTests = currentTests.filter(id => id !== testId);
    }
    handleInfoChange('quickAccessTests', newTests);
  };

  const handleDefaultVariableToggle = (testId: string, variableId: string, isChecked: boolean) => {
    const currentDefaults = currentInfo.defaultTestVariables || {};
    const testDefaults = currentDefaults[testId] || [];
    let newTestDefaults;

    if (isChecked) {
      newTestDefaults = [...testDefaults, variableId];
    } else {
      newTestDefaults = testDefaults.filter(id => id !== variableId);
    }
    
    const newDefaultTestVariables = {
      ...currentDefaults,
      [testId]: newTestDefaults,
    };

    handleInfoChange('defaultTestVariables', newDefaultTestVariables);
  };

  const handleAddSpecialty = async () => {
    if (!newSpecialty.trim()) {
        toast({ variant: 'destructive', title: 'Error', description: 'El nombre de la especialidad no puede estar vacío.' });
        return;
    }
    const newId = newSpecialty.trim().toLowerCase().replace(/\s+/g, '-');
    if (specialtyCategories.some(s => s.id === newId)) {
        toast({ variant: 'destructive', title: 'Error', description: 'Esta especialidad ya existe.' });
        return;
    }
    
    const newCategory: SpecialtyCategory = {
        id: newId,
        name: newSpecialty.trim(),
        createdBy: user.id
    };

    try {
        await saveSpecialtyCategory(newCategory);
        toast({ title: 'Éxito', description: `Especialidad "${newCategory.name}" agregada.` });
        setNewSpecialty('');
    } catch (error) {
        console.error("Error adding specialty:", error);
        toast({ variant: 'destructive', title: 'Error', description: 'No se pudo agregar la especialidad.' });
    }
  };

  const handleSaveChanges = async (e: React.FormEvent) => {
    e.preventDefault();
    if (user.role !== 'therapist') return;

    setIsLoading(true);
    const infoToSave: TherapistInfo = {
      id: user.id,
      personalNotes: currentInfo.personalNotes || '',
      trainingObjectives: currentInfo.trainingObjectives || '',
      evaluations: currentInfo.evaluations || '',
      academicInfo: currentInfo.academicInfo || '',
      continuingEducation: currentInfo.continuingEducation || '',
      linkedinUrl: currentInfo.linkedinUrl || '',
      socialMediaUrl: currentInfo.socialMediaUrl || '',
      specialties: currentInfo.specialties || [],
      quickAccessTests: currentInfo.quickAccessTests || [],
      defaultTestVariables: currentInfo.defaultTestVariables || {},
      lastUpdated: new Date().toISOString(),
    };

    try {
      await saveTherapistInfo(infoToSave);
      toast({ title: 'Éxito', description: 'Tu perfil ha sido actualizado.' });
    } catch (error) {
      console.error("Error saving therapist info:", error);
      toast({ variant: 'destructive', title: 'Error', description: 'No se pudo actualizar tu perfil.' });
    } finally {
      setIsLoading(false);
    }
  };
  
  const sortedSpecialties = useMemo(() => [...specialtyCategories].sort((a,b) => a.name.localeCompare(b.name)), [specialtyCategories]);
  const sortedTests = useMemo(() => [...customTests].sort((a,b) => a.name.localeCompare(b.name)), [customTests]);

  
  if (user.role !== 'therapist') {
    return null;
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2"><UserIcon /> Mi Perfil Profesional</CardTitle>
        <CardDescription>Aquí puedes gestionar tu información académica, especialidades y ver tu plan de desarrollo.</CardDescription>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSaveChanges} className="space-y-6">
          <div className="space-y-4 p-4 border rounded-lg">
            <h3 className="font-medium text-lg flex items-center gap-2"><BookOpen/>Mi Formación y Enlaces (Editable)</h3>
            <div className="grid md:grid-cols-2 gap-6">
                <div>
                    <Label htmlFor="academic-info">Grados Académicos y Formación Profesional</Label>
                    <Textarea
                    id="academic-info"
                    value={currentInfo.academicInfo || ''}
                    onChange={e => handleInfoChange('academicInfo', e.target.value)}
                    rows={6}
                    placeholder="Ej: Psicólogo, Universidad de..., Magíster en..., Postítulo en..."
                    />
                </div>
                <div>
                    <Label htmlFor="continuing-education">Cursos y Formación Continua</Label>
                    <Textarea
                    id="continuing-education"
                    value={currentInfo.continuingEducation || ''}
                    onChange={e => handleInfoChange('continuingEducation', e.target.value)}
                    rows={6}
                    placeholder="Ej: Curso de Terapia de Aceptación y Compromiso, 2023..."
                    />
                </div>
                <div className="space-y-2">
                    <Label htmlFor="linkedin-url" className="flex items-center gap-2"><Linkedin className="h-4 w-4" /> Perfil de LinkedIn</Label>
                    <Input
                        id="linkedin-url"
                        type="url"
                        value={currentInfo.linkedinUrl || ''}
                        onChange={e => handleInfoChange('linkedinUrl', e.target.value)}
                        placeholder="https://www.linkedin.com/in/tu-perfil"
                    />
                </div>
                <div className="space-y-2">
                    <Label htmlFor="social-media-url" className="flex items-center gap-2"><LinkIcon className="h-4 w-4" /> Otra Red Social o Sitio Web</Label>
                    <Input
                        id="social-media-url"
                        type="url"
                        value={currentInfo.socialMediaUrl || ''}
                        onChange={e => handleInfoChange('socialMediaUrl', e.target.value)}
                        placeholder="URL a tu sitio web o perfil"
                    />
                </div>
            </div>
          </div>
          
          <div className="space-y-4 p-4 border rounded-lg">
            <h3 className="font-medium text-lg flex items-center gap-2">Mis Especialidades</h3>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
              {sortedSpecialties.map(spec => (
                <div key={spec.id} className="flex items-center gap-2">
                    <Checkbox
                        id={`spec-${spec.id}`}
                        checked={(currentInfo.specialties || []).includes(spec.id)}
                        onCheckedChange={(checked) => handleSpecialtyToggle(spec.id, !!checked)}
                    />
                    <Label htmlFor={`spec-${spec.id}`} className="font-normal">{spec.name}</Label>
                </div>
              ))}
            </div>
            <div className="flex items-center gap-2 pt-4 border-t">
              <Input 
                value={newSpecialty}
                onChange={(e) => setNewSpecialty(e.target.value)}
                placeholder="Nombre de la nueva especialidad"
              />
              <Button type="button" onClick={handleAddSpecialty}><Plus className="mr-2 h-4 w-4" /> Agregar</Button>
            </div>
          </div>

          <div className="space-y-4 p-4 border rounded-lg">
            <h3 className="font-medium text-lg flex items-center gap-2"><Settings2 /> Configuración de Acceso Directo</h3>
             <p className="text-sm text-muted-foreground">
                Selecciona los tests que aparecerán en el menú "Iniciar Test" del Panel Clínico Rápido.
            </p>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
              {sortedTests.map(test => (
                <div key={test.id} className="flex items-center gap-2">
                    <Checkbox
                        id={`quick-${test.id}`}
                        checked={(currentInfo.quickAccessTests || []).includes(test.id)}
                        onCheckedChange={(checked) => handleQuickAccessToggle(test.id, !!checked)}
                    />
                    <Label htmlFor={`quick-${test.id}`} className="font-normal">{test.name}</Label>
                </div>
              ))}
            </div>
          </div>
          
          <div className="space-y-4 p-4 border rounded-lg">
            <h3 className="font-medium text-lg flex items-center gap-2"><Settings2 /> Configuración de Vistas por Defecto en Resultados</h3>
            <p className="text-sm text-muted-foreground">
              Selecciona las variables que quieres que aparezcan marcadas por defecto en la pestaña de "Resultados" para cada test.
            </p>
            <Accordion type="multiple" className="w-full">
              {sortedTests.map(test => {
                const variables = [
                  ...test.fields,
                  ...(test.scoreCalculation?.method !== 'none' ? [{
                    id: `finalScore_${test.id}`,
                    label: `Puntaje Final - ${test.name}`
                  }] : [])
                ];
                const defaultVarsForTest = currentInfo.defaultTestVariables?.[test.id] || [];

                return (
                  <AccordionItem value={test.id} key={test.id}>
                    <AccordionTrigger>{test.name}</AccordionTrigger>
                    <AccordionContent>
                      <div className="grid grid-cols-2 md:grid-cols-3 gap-4 p-2">
                        {variables.map(variable => (
                          <div key={variable.id} className="flex items-center gap-2">
                            <Checkbox
                              id={`default-var-${test.id}-${variable.id}`}
                              checked={defaultVarsForTest.includes(variable.id)}
                              onCheckedChange={(checked) => handleDefaultVariableToggle(test.id, variable.id, !!checked)}
                            />
                            <Label htmlFor={`default-var-${test.id}-${variable.id}`} className="font-normal">
                              {variable.label}
                            </Label>
                          </div>
                        ))}
                      </div>
                    </AccordionContent>
                  </AccordionItem>
                );
              })}
            </Accordion>
          </div>

          <div className="space-y-4 p-4 border rounded-lg bg-secondary/30">
            <h3 className="font-medium text-lg flex items-center gap-2"><BrainCircuit/>Mi Plan de Desarrollo (Solo Lectura)</h3>
             <p className="text-sm text-muted-foreground">Esta sección es gestionada por tu supervisor.</p>
            <div className="grid md:grid-cols-2 gap-6">
                <div>
                    <Label htmlFor="training-objectives">Objetivos de Entrenamiento</Label>
                    <Textarea
                    id="training-objectives"
                    value={currentInfo.trainingObjectives || 'Aún no definido por tu supervisor.'}
                    rows={4}
                    readOnly
                    className="bg-background"
                    />
                </div>
                <div>
                    <Label htmlFor="evaluations">Evaluaciones y Notas de Supervisión</Label>
                    <Textarea
                    id="evaluations"
                    value={currentInfo.evaluations || 'Aún no definido por tu supervisor.'}
                    rows={4}
                    readOnly
                    className="bg-background"
                    />
                </div>
            </div>
          </div>
          
          <Button type="submit" disabled={isLoading}>
            {isLoading ? 'Guardando...' : 'Guardar Mis Datos'}
          </Button>
        </form>
      </CardContent>
    </Card>
  );
}
