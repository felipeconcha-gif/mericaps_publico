"use client";

import { Button } from "@/components/ui/button";
import Link from "next/link";

export function MuralTab() {
  return (
    <Button
      asChild
      className="fixed bottom-6 left-6 h-14 px-8 rounded-full shadow-lg text-lg font-semibold bg-primary text-primary-foreground hover:bg-primary/90 focus-visible:ring-ring focus-visible:ring-2 focus-visible:ring-offset-2 transition-transform hover:scale-105 active:scale-100"
    >
      <Link href="/mural">
        News!
      </Link>
    </Button>
  );
}
