
"use client";

import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import type { User, CustomTest, PatientCode, Supervisor, TestResult, ClinicalInfo, Therapist, ScheduledReminder, ThemeSettings, TherapistInfo, SpecialtyCategory, AppConfig } from "@/lib/definitions";
import { LogOut, LayoutGrid, Users, BarChart2, Pencil, UserCog, Settings, Bell, RefreshCw, Briefcase, User as UserIcon } from "lucide-react";
import { NewTestTab } from "./new-test-tab";
import { EditorTab } from "./editor-tab";
import { PatientsTab } from "./patients-tab";
import { RolesTab } from "./roles-tab";
import { TherapistsTab } from "./therapists-tab";
import dynamic from 'next/dynamic';
import { ConfigTab } from "./config-tab";
import { useMemo, useState, useEffect } from "react";
import { cn } from "@/lib/utils";
import { useAuth, useCollection, useMemoFirebase } from "@/firebase";
import { Skeleton } from "../ui/skeleton";
import { ClinicalDashboard } from "./clinical-dashboard";
import { collection, doc } from "firebase/firestore";
import { useFirestore } from "@/firebase/provider";
import { MyProfileTab } from "./my-profile-tab";
import { MuralTab } from "./mural-tab";
import { MigrationTab } from "./migration-tab";


const ResultsTab = dynamic(() => import('./results-tab').then(mod => mod.ResultsTab), {
  loading: () => <Skeleton className="h-96 w-full" />,
});


type AppState = {
  customTests: CustomTest[];
  patientCodes: PatientCode[];
  supervisors: Supervisor[];
  therapists: Therapist[];
  testResults: TestResult[];
  clinicalInfo: Record<string, ClinicalInfo>;
  therapistInfo: Record<string, TherapistInfo>;
  specialtyCategories: SpecialtyCategory[];
  scheduledReminders: ScheduledReminder[];
  themeSettings: ThemeSettings;
  appConfig: AppConfig | null;
};

interface ProfessionalDashboardProps {
  user: User;
  onLogout: () => void;
  appState: AppState;
}

export function ProfessionalDashboard({ user, onLogout, appState }: ProfessionalDashboardProps) {
  const { role, name } = user;
  const auth = useAuth();
  
  const handleLogout = () => {
    if (role === 'admin' || role === 'supervisor' || role === 'therapist') {
      auth.signOut();
    }
    onLogout();
  };

  const getRoleDisplayName = () => {
    switch(role) {
      case 'admin': return `Administrador: ${name}`;
      case 'supervisor': return `Supervisor: ${name}`;
      case 'therapist': return `Terapeuta: ${name}`;
      default: return 'Profesional';
    }
  };
  
  const getDefaultTab = () => {
    return 'new-test';
  }

  const [activeTab, setActiveTab] = useState(getDefaultTab());
  const [quickTestParams, setQuickTestParams] = useState<{ patientName: string; testId: string } | null>(null);

  const handleStartQuickTest = (patientName: string, testId: string) => {
    setQuickTestParams({ patientName, testId });
    setActiveTab('new-test');
  };

  const pendingRemindersCount = useMemo(() => {
    return (appState.scheduledReminders || []).filter(r => r.status === 'pending' && new Date(r.sendDate) <= new Date()).length;
  }, [appState.scheduledReminders]);

  const visibleTests = useMemo(() => {
    const hiddenTests = appState.appConfig?.hiddenTests || [];
    return appState.customTests.filter(test => !hiddenTests.includes(test.id));
  }, [appState.customTests, appState.appConfig]);


  const filteredAppState = {
    ...appState,
    customTests: visibleTests,
  };

  const tabs = [
    { value: 'new-test', label: 'Nuevo Test', icon: <LayoutGrid className="h-5 w-5"/>, roles: ['admin', 'supervisor', 'therapist'] },
    { value: 'results', label: 'Resultados', icon: <BarChart2 className="h-5 w-5"/>, roles: ['admin', 'supervisor', 'therapist'] },
    { value: 'patients', label: 'Pacientes', icon: <Users className="h-5 w-5"/>, roles: ['admin', 'supervisor', 'therapist'], notificationCount: pendingRemindersCount },
    { value: 'my-profile', label: 'Mi Perfil', icon: <UserIcon className="h-5 w-5"/>, roles: ['therapist'] },
    { value: 'therapists', label: 'Terapeutas', icon: <Briefcase className="h-5 w-5"/>, roles: ['admin', 'supervisor'] },
    { value: 'editor', label: 'Editor', icon: <Pencil className="h-5 w-5"/>, roles: ['admin', 'supervisor'] },
    { value: 'roles', label: 'Roles', icon: <UserCog className="h-5 w-5"/>, roles: ['admin', 'supervisor'] },
    { value: 'config', label: 'Configuración', icon: <Settings className="h-5 w-5"/>, roles: ['admin'] },
  ].filter(tab => tab.roles.includes(role));

  const showClinicalDashboard = role === 'supervisor' || role === 'therapist';


  return (
    <div className="w-full space-y-8">
      <nav className="flex flex-col sm:flex-row justify-between items-center mb-6 gap-4">
        <div className="text-sm text-foreground/80">
          <span className="font-semibold text-primary">{getRoleDisplayName()}</span>
        </div>
        <div className="flex items-center gap-2">
            <Button onClick={handleLogout} variant="outline" size="sm">
              <LogOut className="mr-2 h-4 w-4" /> Salir
            </Button>
        </div>
      </nav>
      
      {showClinicalDashboard && (
        <ClinicalDashboard 
          user={user} 
          testResults={appState.testResults} 
          customTests={appState.customTests} 
          patientCodes={appState.patientCodes}
          therapists={appState.therapists}
          supervisors={appState.supervisors}
          therapistInfo={appState.therapistInfo}
          onStartQuickTest={handleStartQuickTest}
        />
      )}

      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full flex flex-col md:items-start md:flex-row md:gap-8">
        <TabsList className="grid md:flex md:flex-col md:w-48 h-auto w-full mb-6 md:mb-0">
          {tabs.map((tab) => (
            <TabsTrigger key={tab.value} value={tab.value} className="w-full justify-start text-base md:text-sm py-3 px-4 gap-3 relative">
              {tab.icon}
              <span>{tab.label}</span>
              {tab.notificationCount > 0 && (
                <span className={cn(
                  "ml-auto flex h-6 w-6 items-center justify-center rounded-full bg-destructive text-destructive-foreground text-xs",
                  "group-data-[state=active]:bg-destructive-foreground group-data-[state=active]:text-destructive"
                )}>
                  {tab.notificationCount}
                </span>
              )}
            </TabsTrigger>
          ))}
        </TabsList>
        
        <div className="flex-1">
          {(role === 'admin' || role === 'supervisor' || role === 'therapist') && <TabsContent value="new-test"><NewTestTab user={user} {...filteredAppState} quickTestParams={quickTestParams} onQuickTestConsumed={() => setQuickTestParams(null)} /></TabsContent>}
          {(role === 'admin' || role === 'supervisor' || role === 'therapist') && <TabsContent value="patients"><PatientsTab {...filteredAppState} supervisors={appState.supervisors} user={user} testResults={appState.testResults} /></TabsContent>}
          <TabsContent value="results"><ResultsTab user={user} {...filteredAppState} therapistInfo={appState.therapistInfo} /></TabsContent>
          {role === 'therapist' && <TabsContent value="my-profile"><MyProfileTab user={user} {...filteredAppState} /></TabsContent>}
          {(role === 'admin' || role === 'supervisor') && <TabsContent value="therapists"><TherapistsTab user={user} {...filteredAppState} /></TabsContent>}
          {(role === 'admin' || role === 'supervisor') && <TabsContent value="editor"><EditorTab customTests={appState.customTests} appConfig={appState.appConfig} /></TabsContent>}
          {(role === 'admin' || role === 'supervisor') && <TabsContent value="roles"><RolesTab supervisors={appState.supervisors} therapists={appState.therapists} patientCodes={appState.patientCodes} onProfessionalsUpdate={() => {}} user={user} /></TabsContent>}
          {role === 'admin' && <TabsContent value="config"><ConfigTab themeSettings={appState.themeSettings} /></TabsContent>}
        </div>
      </Tabs>
      <MuralTab />
    </div>
  );
}
