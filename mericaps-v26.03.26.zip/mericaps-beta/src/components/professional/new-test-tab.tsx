
"use client";

import { useState, useMemo, useEffect } from 'react';
import type { CustomTest, PatientCode, Supervisor, TestResult, ClinicalInfo, Question, Therapist, User } from '@/lib/definitions';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { Slider } from '@/components/ui/slider';
import { useToast } from '@/hooks/use-toast';
import { ArrowLeft, Brain, Shield, Star, Users, Briefcase, Cog, AlertTriangle, Smile, Frown } from 'lucide-react';
import { cn, calculateFinalScore } from '@/lib/utils';
import { Checkbox } from '../ui/checkbox';
import { saveTestResult, savePatientCode } from '@/lib/firestore-actions';
import Image from 'next/image';

const getInitialValue = (field: Question) => {
    switch (field.type) {
      case 'slider':
      case 'image_slider':
        return field.config?.defaultValue ?? 5;
      case 'multiple_choice':
        return [];
      case 'yes_no':
      case 'likert':
      case 'text':
      case 'number':
      default:
        return '';
    }
}


interface NewTestTabProps {
  user: User;
  customTests: CustomTest[];
  patientCodes: PatientCode[];
  therapists: Therapist[];
  testResults: TestResult[];
  quickTestParams: { patientName: string; testId: string } | null;
  onQuickTestConsumed: () => void;
}

const iconMap: Record<string, React.ReactNode> = {
    'phq-9': <Brain />,
    'gad-7': <Shield />,
    srs: <Star />,
    anxiety: <Brain />,
    selfesteem: <Briefcase />,
    relationships: <Users />,
    trauma: <Shield />,
    custom: <Cog />,
};


export function NewTestTab({ user, customTests = [], patientCodes, therapists, testResults, quickTestParams, onQuickTestConsumed }: NewTestTabProps) {
  const [view, setView] = useState<'selection' | 'form'>('selection');
  const [currentTest, setCurrentTest] = useState<CustomTest | null>(null);
  const [currentTestFields, setCurrentTestFields] = useState<any[]>([]);
  const [formState, setFormState] = useState<Record<string, any>>({});
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    if (quickTestParams) {
        const test = customTests.find(t => t.id === quickTestParams.testId);
        if (!test) {
            toast({
                variant: 'destructive',
                title: 'Error',
                description: 'No se pudo encontrar el test seleccionado.',
            });
            onQuickTestConsumed();
            return;
        }

        setCurrentTest(test);
        setCurrentTestFields(test.fields);
        
        const initialScores = test.fields.reduce((acc, field) => {
            acc[field.id] = getInitialValue(field);
            return acc;
        }, {} as Record<string, any>);

        setFormState({
            patient_name: quickTestParams.patientName,
            session_date: new Date().toISOString().split('T')[0],
            session_status: 'completed',
            scores: initialScores
        });
        
        setView('form');
        
        onQuickTestConsumed();
    }
  }, [quickTestParams, onQuickTestConsumed, customTests, toast]);

  const patientOptions = useMemo(() => {
    if (user.role !== 'therapist') {
        return []; // Not used for admin/supervisor in this implementation
    }

    const therapistPatientNames = new Set<string>();
    
    // Get patients from their assigned codes
    (patientCodes || []).forEach(pc => {
        if (pc.assignedTherapist === user.id) {
            therapistPatientNames.add(pc.patientName);
        }
    });

    // Get patients from their test results
    (testResults || []).forEach(r => {
        if (r.assigned_therapist === user.id) {
            therapistPatientNames.add(r.patient_name);
        }
    });

    return Array.from(therapistPatientNames).sort();
  }, [user, patientCodes, testResults]);

  const handleSelectTest = (testId: string) => {
    const test = customTests.find(t => t.id === testId);
    if (!test) return;

    setCurrentTest(test);
    setCurrentTestFields(test.fields);
    
    const initialScores = test.fields.reduce((acc, field) => {
        acc[field.id] = getInitialValue(field);
        return acc;
    }, {} as Record<string, number | string | string[]>);

    setFormState({
        session_date: new Date().toISOString().split('T')[0],
        session_status: 'completed',
        scores: initialScores
    });
    setView('form');
  };

  const handleBackToSelection = () => {
    setView('selection');
    setCurrentTest(null);
    setCurrentTestFields([]);
    setFormState({});
  };
  
  const handleInputChange = (id: string, value: any) => {
    setFormState(prev => ({ ...prev, [id]: value }));
  };

  const handleScoreChange = (id: string, value: any) => {
    setFormState(prev => ({ ...prev, scores: { ...prev.scores, [id]: value }}));
  };

  const handleMultipleChoiceChange = (id: string, option: string, isChecked: boolean) => {
    const currentSelection = (formState.scores[id] as string[] || []);
    let newSelection;
    if(isChecked) {
      newSelection = [...currentSelection, option];
    } else {
      newSelection = currentSelection.filter(item => item !== option);
    }
    handleScoreChange(id, newSelection);
  }
  
  const createPatientCodeIfNotExists = async (patientName: string, therapistId: string) => {
    if (!currentTest) return;
    const existingPatient = patientCodes.find(pc => pc.patientName === patientName);
    if (!existingPatient) {
        const namePart = patientName.split(' ')[0].toUpperCase().substring(0, 5);
        const datePart = new Date().toISOString().slice(2, 10).replace(/-/g, '');
        const code = `${namePart}-${datePart}`;
        const newCode: PatientCode = {
            id: Date.now().toString(),
            code,
            patientName,
            assignedTests: [currentTest.id],
            assignedTherapist: therapistId,
            expiry: null,
            maxUses: null,
            created: new Date().toISOString(),
            usedCount: 0,
            lastUsed: null,
            autoCreated: true,
            patientEmail: null,
        };
        await savePatientCode(newCode);
        toast({ title: "Nuevo Paciente", description: `Paciente ${patientName} creado automáticamente con código ${code}.` });
    }
  };
  
  const checkAlerts = (scores: Record<string, any>, test: CustomTest, patientName: string) => {
    for (const field of test.fields) {
      if (field.alertEnabled && typeof field.alertThreshold === 'number') {
        const scoreValue = scores[field.id];
        const numericScore = Number(scoreValue);
        
        if (!isNaN(numericScore) && numericScore >= field.alertThreshold) {
          toast({
            variant: "destructive",
            title: `🔴 Alerta de Riesgo Inmediato`,
            description: `El paciente ${patientName} ha superado el umbral de alerta en la pregunta "${field.label}" del test "${test.name}". Se requiere atención profesional.`,
            duration: 20000,
          });
        }
      }
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentTest) return;
    setIsLoading(true);

    const { patient_name, session_date, session_status, not_completed_reason, other_reason_text, scores, notes, assigned_therapist } = formState;

    const finalTherapistId = user.role === 'therapist' ? user.id : assigned_therapist;

    if (!patient_name || !session_date || !finalTherapistId) {
        toast({ variant: 'destructive', title: 'Campos requeridos', description: 'Nombre del paciente, fecha y terapeuta son obligatorios.' });
        setIsLoading(false);
        return;
    }

    const finalScore = calculateFinalScore(scores, currentTest.scoreCalculation);
    
    if(session_status === 'completed') {
        checkAlerts(scores, currentTest, patient_name);
    }
    
    const resultId = Date.now().toString();
    
    const newResult: TestResult = {
        id: resultId,
        patient_name,
        session_date: session_date,
        test_date: new Date().toISOString(),
        test_type: currentTest.id,
        session_status,
        not_completed_reason: not_completed_reason || '',
        other_reason_text: other_reason_text || '',
        scores: session_status === 'completed' ? scores : {},
        finalScore: finalScore,
        notes: notes || '',
        source: 'professional',
        assigned_therapist: finalTherapistId,
    };
    
    try {
        await saveTestResult(newResult);
        if (user.role !== 'therapist') {
          await createPatientCodeIfNotExists(patient_name, finalTherapistId);
        }
        toast({ title: 'Éxito', description: 'Evaluación guardada en la base de datos.' });
        handleBackToSelection();
    } catch (error) {
        console.error("Error saving test result: ", error);
        toast({ variant: 'destructive', title: 'Error', description: 'No se pudo guardar la evaluación.' });
    } finally {
        setIsLoading(false);
    }
  };

  const renderQuestionField = (field: Question) => {
    const value = formState.scores?.[field.id];
    const numericValue = typeof value === 'number' ? value : (field.config?.defaultValue ?? 5);

    switch (field.type) {
        case 'image_slider':
            return (
                <>
                    <div className="flex justify-between text-sm text-center text-gray-500 mb-2">
                        <span className="w-2/5">{field.config?.minImageLabel}</span>
                        <span className="w-1/5"></span>
                        <span className="w-2/5">{field.config?.maxImageLabel}</span>
                    </div>
                    <div className="flex items-center gap-4">
                        {field.config?.minImageUrl ? <Image src={field.config.minImageUrl} alt={field.config.minImageLabel || 'Min'} width={40} height={40} unoptimized /> : <Frown className="h-10 w-10 text-muted-foreground"/>}
                        <Slider 
                            id={field.id} 
                            min={field.config?.min ?? 1} 
                            max={field.config?.max ?? 10} 
                            step={field.config?.step ?? 1}
                            value={[numericValue]}
                            onValueChange={([val]) => handleScoreChange(field.id, val)}
                            className="w-full"
                        />
                        {field.config?.maxImageUrl ? <Image src={field.config.maxImageUrl} alt={field.config.maxImageLabel || 'Max'} width={40} height={40} unoptimized /> : <Smile className="h-10 w-10 text-muted-foreground"/>}
                    </div>
                     <div className="text-center font-bold text-lg mt-2" style={{ color: field.color }}>
                        {numericValue.toFixed(field.config?.step && field.config.step < 1 ? 1 : 0)}
                    </div>
                </>
            );
        case 'slider':
            return (
                <>
                    <div className="flex items-center gap-4">
                        <Slider id={field.id} 
                          min={field.config?.min ?? 1} 
                          max={field.config?.max ?? 10} 
                          step={field.config?.step ?? 1}
                          value={[numericValue]}
                          onValueChange={([val]) => handleScoreChange(field.id, val)} 
                        />
                        <span className="font-bold text-lg w-12 text-center" style={{color: field.color}}>{numericValue.toFixed(field.config?.step && field.config.step < 1 ? 1 : 0)}</span>
                    </div>
                    <div className="flex justify-between text-sm text-gray-500 mt-2 px-1">
                        <span className="w-2/5 text-left">{field.config?.minLabel ?? ''}</span>
                        <span className="w-2/5 text-right">{field.config?.maxLabel ?? ''}</span>
                    </div>
                </>
            );
        case 'likert':
            const likertOptions = field.config?.likertOptions || ['Totalmente en desacuerdo', 'En desacuerdo', 'Neutral', 'De acuerdo', 'Totalmente de acuerdo'];
            return (
                <RadioGroup value={value} onValueChange={(val) => handleScoreChange(field.id, val)} className="flex flex-wrap gap-4">
                    {likertOptions.map((option, index) => (
                        <div key={option} className="flex items-center space-x-2">
                            <RadioGroupItem value={String(index + 1)} id={`${field.id}-${index}`} />
                            <Label htmlFor={`${field.id}-${index}`}>{option}</Label>
                        </div>
                    ))}
                </RadioGroup>
            );
        case 'multiple_choice':
            return (
                <div className="space-y-2">
                    {field.config?.options?.map(option => (
                        <div key={option} className="flex items-center space-x-2">
                            <Checkbox id={`${field.id}-${option}`} checked={(value as string[])?.includes(option)} onCheckedChange={(checked) => handleMultipleChoiceChange(field.id, option, !!checked)} />
                            <label htmlFor={`${field.id}-${option}`} className="text-sm font-medium">{option}</label>
                        </div>
                    ))}
                </div>
            );
        case 'text':
            return <Textarea id={field.id} value={value} onChange={e => handleScoreChange(field.id, e.target.value)} placeholder={field.config?.placeholder} />;
        case 'number':
            return (
                <div className="flex items-center gap-2">
                    <Input id={field.id} type="number" value={value} onChange={e => handleScoreChange(field.id, e.target.value)} className="max-w-40" />
                    {field.config?.unit && <span className="text-muted-foreground">{field.config.unit}</span>}
                </div>
            );
        case 'yes_no':
            return (
                <RadioGroup value={value} onValueChange={(val) => handleScoreChange(field.id, val)} className="flex gap-4">
                    <div className="flex items-center space-x-2"><RadioGroupItem value="yes" id={`${field.id}-yes`} /><Label htmlFor={`${field.id}-yes`}>Sí</Label></div>
                    <div className="flex items-center space-x-2"><RadioGroupItem value="no" id={`${field.id}-no`} /><Label htmlFor={`${field.id}-no`}>No</Label></div>
                </RadioGroup>
            );
        default:
            return null;
    }
  }

  const renderTestSelection = () => (
    <Card>
      <CardHeader className="text-center">
        <CardTitle>Selecciona el Tipo de Test</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {(customTests || []).map(test => (
                 <button key={test.id} onClick={() => handleSelectTest(test.id)} className="test-option text-left p-6 border-2 border-gray-200 rounded-xl hover:border-primary hover:bg-primary/5 transition-all focus:outline-none focus:ring-2 focus:ring-ring">
                    <div className="text-4xl mb-3 text-primary">{iconMap[test.id.split('-')[0]] || iconMap.custom}</div>
                    <h3 className="font-semibold text-gray-800 mb-2">{test.name}</h3>
                    <p className="text-sm text-gray-600">{test.fields.length} preguntas</p>
                </button>
            ))}
        </div>
      </CardContent>
    </Card>
  );
  
  const renderTestForm = () => {
    const testName = currentTest?.name;
        
    return (
        <Card>
            <CardHeader>
                <div className="flex items-center justify-between">
                    <CardTitle>Evaluación: {testName}</CardTitle>
                    <Button variant="ghost" onClick={handleBackToSelection}><ArrowLeft className="mr-2 h-4 w-4" /> Cambiar Test</Button>
                </div>
            </CardHeader>
            <CardContent>
                <form onSubmit={handleSubmit} className="space-y-6">
                    <div className="grid md:grid-cols-3 gap-6">
                        <div>
                            <Label htmlFor="patient-name">Nombre del Paciente</Label>
                            {user.role === 'therapist' ? (
                                <Select required value={formState.patient_name || ''} onValueChange={value => handleInputChange('patient_name', value)}>
                                    <SelectTrigger id="patient-name"><SelectValue placeholder="Seleccionar paciente..." /></SelectTrigger>
                                    <SelectContent>
                                        {patientOptions.map(name => <SelectItem key={name} value={name}>{name}</SelectItem>)}
                                    </SelectContent>
                                </Select>
                            ) : (
                                <Input id="patient-name" required value={formState.patient_name || ''} onChange={e => handleInputChange('patient_name', e.target.value)} />
                            )}
                        </div>
                        <div>
                            <Label htmlFor="session-date">Fecha de la Sesión</Label>
                            <Input id="session-date" type="date" required value={formState.session_date || ''} onChange={e => handleInputChange('session_date', e.target.value)} />
                        </div>
                        {user.role !== 'therapist' && (
                            <div>
                                <Label htmlFor="assigned-therapist">Terapeuta Asignado</Label>
                                <Select required value={formState.assigned_therapist || ''} onValueChange={(value) => handleInputChange('assigned_therapist', value)}>
                                    <SelectTrigger><SelectValue placeholder="Seleccionar terapeuta" /></SelectTrigger>
                                    <SelectContent>
                                        {therapists.map(t => <SelectItem key={t.id} value={t.id}>{t.name}</SelectItem>)}
                                    </SelectContent>
                                </Select>
                            </div>
                        )}
                    </div>

                    <div className="bg-secondary/50 rounded-lg p-6">
                         <h3 className="text-lg font-semibold text-foreground mb-4">Estado de la Sesión</h3>
                         <RadioGroup value={formState.session_status} onValueChange={value => handleInputChange('session_status', value)} className="space-y-3">
                            <Label className="flex items-center space-x-3 cursor-pointer">
                                <RadioGroupItem value="completed" id="status-completed" />
                                <div className="flex items-center space-x-2"><span className="text-2xl">✅</span> <span className="font-medium">Test Realizado</span></div>
                            </Label>
                            <Label className="flex items-center space-x-3 cursor-pointer">
                                <RadioGroupItem value="not-completed" id="status-not-completed" />
                                <div className="flex items-center space-x-2"><span className="text-2xl">❌</span> <span className="font-medium">Test No Realizado</span></div>
                            </Label>
                         </RadioGroup>
                         {formState.session_status === 'not-completed' && (
                            <div className="mt-4 pl-12 space-y-4">
                                <div>
                                    <Label htmlFor="not-completed-reason">Motivo de No Realización</Label>
                                    <Select value={formState.not_completed_reason || ''} onValueChange={value => handleInputChange('not_completed_reason', value)}>
                                        <SelectTrigger><SelectValue placeholder="Selecciona un motivo" /></SelectTrigger>
                                        <SelectContent>
                                            <SelectItem value="patient_absence">Inasistencia del Paciente</SelectItem>
                                            <SelectItem value="therapist_suspension">Suspensión por Parte del Terapeuta</SelectItem>
                                            <SelectItem value="other">Otro Motivo</SelectItem>
                                        </SelectContent>
                                    </Select>
                                </div>
                                {formState.not_completed_reason === 'other' && (
                                    <div>
                                        <Label htmlFor="other-reason-text">Especifica el motivo</Label>
                                        <Input id="other-reason-text" value={formState.other_reason_text || ''} onChange={e => handleInputChange('other_reason_text', e.target.value)} />
                                    </div>
                                )}
                            </div>
                         )}
                    </div>
                    
                    <div className={cn("space-y-6", formState.session_status === 'not-completed' && 'hidden')}>
                        {currentTestFields.map(field => (
                            <div key={field.id} className="p-4 border rounded-lg">
                                <Label htmlFor={field.id} className="block mb-4 text-center font-medium">
                                  {field.label}
                                  {field.alertEnabled && <AlertTriangle className="inline-block ml-2 text-amber-500" size={16}/>}
                                </Label>
                                {renderQuestionField(field)}
                            </div>
                        ))}
                    </div>

                    <div>
                        <Label htmlFor="notes">Notas de la Sesión</Label>
                        <Textarea id="notes" value={formState.notes || ''} onChange={e => handleInputChange('notes', e.target.value)} placeholder="Observaciones adicionales..." />
                    </div>

                    <Button type="submit" disabled={isLoading} className="w-full">
                        {isLoading ? "Guardando..." : "Guardar Evaluación"}
                    </Button>
                </form>
            </CardContent>
        </Card>
    );
  }

  return view === 'selection' ? renderTestSelection() : renderTestForm();
}
