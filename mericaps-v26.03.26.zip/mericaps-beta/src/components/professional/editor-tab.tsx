

"use client";

import { useState } from 'react';
import type { CustomTest, Question, ScoreCalculation } from '@/lib/definitions';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useToast } from '@/hooks/use-toast';
import { Plus, Trash2, ArrowLeft, Copy, AlertTriangle, Eye, EyeOff, Smile, Frown } from 'lucide-react';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog"
import { Textarea } from '../ui/textarea';
import { Switch } from '../ui/switch';
import { saveTest, deleteTest as deleteTestFromDb, saveAppConfig } from '@/lib/firestore-actions';
import { Slider } from '../ui/slider';
import Image from 'next/image';


interface EditorTabProps {
  customTests: CustomTest[];
  appConfig: { hiddenTests: string[] } | null;
}

const questionTypes: { value: Question['type']; label: string }[] = [
  { value: 'slider', label: 'Barra Deslizante' },
  { value: 'image_slider', label: 'Barra Deslizante con Imágenes' },
  { value: 'likert', label: 'Escala Likert' },
  { value: 'multiple_choice', label: 'Opción Múltiple' },
  { value: 'text', label: 'Respuesta de Texto' },
  { value: 'number', label: 'Respuesta Numérica' },
  { value: 'yes_no', label: 'Sí / No' },
];

export function EditorTab({ customTests = [], appConfig }: EditorTabProps) {
  const [view, setView] = useState<'list' | 'editor'>('list');
  const [editingTest, setEditingTest] = useState<CustomTest | null>(null);
  const [testName, setTestName] = useState('');
  const [instructions, setInstructions] = useState('');
  const [cutoffScore, setCutoffScore] = useState<number | null>(null);
  const [scoreCalculation, setScoreCalculation] = useState<ScoreCalculation>({ method: 'none' });
  const [questions, setQuestions] = useState<Partial<Question>[]>([]);
  const { toast } = useToast();
  const [isLoading, setIsLoading] = useState(false);

  const hiddenTests = appConfig?.hiddenTests || [];

  const handleCreateNew = () => {
    setEditingTest(null);
    setTestName('');
    setInstructions('');
    setCutoffScore(null);
    setScoreCalculation({ method: 'none' });
    setQuestions([{ label: '', type: 'slider', color: '#000000', scoring: 'direct', weighted: false, weight: 1, alertEnabled: false, alertThreshold: 0, config: { min: 1, max: 10, step: 1, defaultValue: 5 } }]);
    setView('editor');
  };

  const handleEditTest = (testId: string) => {
    const testToEdit = customTests.find(t => t.id === testId);
    if (testToEdit) {
      setEditingTest(testToEdit);
      setTestName(testToEdit.name);
      setInstructions(testToEdit.instructions || '');
      setCutoffScore(testToEdit.cutoffScore || null);
      setScoreCalculation(testToEdit.scoreCalculation || { method: 'none' });
      setQuestions(testToEdit.fields.map(f => ({
        ...f,
        scoring: f.scoring || 'direct',
        weighted: f.weighted || false,
        weight: f.weight ?? 1,
        alertEnabled: f.alertEnabled || false,
        alertThreshold: f.alertThreshold ?? 0,
      })));
      setView('editor');
    }
  };

  const handleBackToList = () => {
    setView('list');
    setEditingTest(null);
  };
  
  const addQuestion = () => {
    setQuestions([...questions, { label: '', type: 'slider', color: '#000000', scoring: 'direct', weighted: false, weight: 1, alertEnabled: false, alertThreshold: 0, config: { min: 1, max: 10, step: 1, defaultValue: 5 } }]);
  };

  const removeQuestion = (index: number) => {
    setQuestions(questions.filter((_, i) => i !== index));
  };
  
  const copyQuestion = (index: number) => {
    const questionToCopy = questions[index];
    const newQuestion = { ...questionToCopy, id: `${questionToCopy.id}-copy-${Date.now()}` };
    const newQuestions = [...questions];
    newQuestions.splice(index + 1, 0, newQuestion);
    setQuestions(newQuestions);
  };

  const updateQuestion = (index: number, field: keyof Question | 'config', value: any) => {
    const newQuestions = [...questions];
    const question = newQuestions[index] as Question;
    if (field === 'config') {
      question.config = { ...question.config, ...value };
    } else if (field === 'type') {
      question.type = value;
      // Reset config on type change, but provide sensible defaults
      switch(value) {
        case 'slider':
            question.config = { min: 1, max: 10, step: 1, defaultValue: 5 };
            break;
        case 'image_slider':
            question.config = {
                min: 1, max: 10, step: 1, defaultValue: 5,
                minImageLabel: 'Extremo izquierdo',
                maxImageLabel: 'Extremo derecho',
                minImageUrl: "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='currentColor' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'%3E%3Ccircle cx='12' cy='12' r='10'%3E%3C/circle%3E%3Cpath d='M16 16s-1.5-2-4-2-4 2-4 2'%3E%3C/path%3E%3Cline x1='9' y1='9' x2='9.01' y2='9'%3E%3C/line%3E%3Cline x1='15' y1='9' x2='15.01' y2='9'%3E%3C/line%3E%3C/svg%3E",
                maxImageUrl: "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='currentColor' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'%3E%3Ccircle cx='12' cy='12' r='10'%3E%3C/circle%3E%3Cpath d='M8 14s1.5 2 4 2 4-2 4-2'%3E%3C/path%3E%3Cline x1='9' y1='9' x2='9.01' y2='9'%3E%3C/line%3E%3Cline x1='15' y1='9' x2='15.01' y2='9'%3E%3C/line%3E%3C/svg%3E"
            };
            break;
        case 'likert':
            question.config = { likertOptions: ['Totalmente en desacuerdo', 'En desacuerdo', 'Neutral', 'De acuerdo', 'Totalmente de acuerdo'] };
            break;
        case 'multiple_choice':
            question.config = { options: ['Opción 1', 'Opción 2'] };
            break;
        default:
            question.config = {};
            break;
      }
    } else {
      (question as any)[field] = value;
    }
    setQuestions(newQuestions);
  };

  const handleOptionChange = (qIndex: number, optionIndex: number, value: string, type: 'likert' | 'multiple_choice') => {
    const newQuestions = [...questions];
    const question = newQuestions[qIndex];
    if (!question || !question.config) return;

    const configKey = type === 'likert' ? 'likertOptions' : 'options';
    const options = [...(question.config[configKey] || [])];
    options[optionIndex] = value;
    updateQuestion(qIndex, 'config', { [configKey]: options });
  };

  const addOption = (qIndex: number, type: 'likert' | 'multiple_choice') => {
    const newQuestions = [...questions];
    const question = newQuestions[qIndex];
    if (!question || !question.config) return;

    const configKey = type === 'likert' ? 'likertOptions' : 'options';
    const options = [...(question.config[configKey] || []), `Nueva Opción ${ (question.config[configKey]?.length || 0) + 1}`];
    updateQuestion(qIndex, 'config', { [configKey]: options });
  };

  const removeOption = (qIndex: number, optionIndex: number, type: 'likert' | 'multiple_choice') => {
    const newQuestions = [...questions];
    const question = newQuestions[qIndex];
    if (!question || !question.config) return;

    const configKey = type === 'likert' ? 'likertOptions' : 'options';
    const options = (question.config[configKey] || []).filter((_, i) => i !== optionIndex);
    updateQuestion(qIndex, 'config', { [configKey]: options });
  };

  const handleSaveTest = async () => {
    if (!testName.trim()) {
      toast({ variant: 'destructive', title: 'Error', description: 'El nombre del test es obligatorio.' });
      return;
    }
    if (questions.some(q => !q.label?.trim())) {
      toast({ variant: 'destructive', title: 'Error', description: 'Todas las preguntas deben tener un texto.' });
      return;
    }
    setIsLoading(true);

    const finalQuestions: Question[] = questions.map((q, i) => {
        const baseQuestion: Partial<Question> = {
            ...q,
            id: q.id || `${testName.replace(/\s+/g, '-').toLowerCase()}-${i + 1}`,
            label: q.label || '',
            color: q.color || '#000000',
            type: q.type || 'slider',
            config: q.config || {},
            scoring: q.scoring || 'direct',
            weighted: q.weighted || false,
            weight: q.weight ?? 1,
            alertEnabled: q.alertEnabled || false,
            alertThreshold: q.alertThreshold ?? 0,
        };

        if (baseQuestion.type === 'slider') {
          baseQuestion.config = { 
            min: 1, max: 10, step: 1, defaultValue: 5,
            ...baseQuestion.config, 
          };
        }
        if (baseQuestion.type === 'likert' && (!baseQuestion.config?.likertOptions || baseQuestion.config.likertOptions.length === 0)) {
          baseQuestion.config = { ...baseQuestion.config, likertOptions: ['Totalmente en desacuerdo', 'En desacuerdo', 'Neutral', 'De acuerdo', 'Totalmente de acuerdo'] };
        }
         if (baseQuestion.type === 'multiple_choice' && (!baseQuestion.config?.options || baseQuestion.config.options.length === 0)) {
          baseQuestion.config = { ...baseQuestion.config, options: ['Opción 1', 'Opción 2'] };
        }


        return baseQuestion as Question;
    });

    const isNew = !editingTest || editingTest.isPredefined;
    const testId = isNew ? `custom-${Date.now().toString()}` : editingTest!.id;
    
    const testData: CustomTest = { 
      id: testId,
      name: testName, 
      instructions: instructions,
      fields: finalQuestions, 
      cutoffScore: cutoffScore,
      scoreCalculation: scoreCalculation,
      created: editingTest?.created || new Date().toISOString(),
      isPredefined: false,
    };
    
    try {
      await saveTest(testData, isNew);
      toast({ title: 'Éxito', description: `Test '${testName}' ${isNew ? 'creado' : 'actualizado'} en la base de datos.` });
      handleBackToList();
    } catch (error) {
      console.error("Error saving test: ", error);
      toast({ variant: 'destructive', title: 'Error de guardado', description: 'No se pudo guardar el test en la base de datos.' });
    } finally {
      setIsLoading(false);
    }
  };
  
  const handleDeleteTest = async (testId: string) => {
    setIsLoading(true);
    
    try {
      await deleteTestFromDb(testId);
      toast({ title: 'Éxito', description: 'Test eliminado de la base de datos.' });
      if(editingTest?.id === testId) {
          handleBackToList();
      }
    } catch (error) {
        console.error("Error deleting test: ", error);
        toast({variant: 'destructive', title: 'Error', description: 'No se pudo eliminar el test.'});
    } finally {
        setIsLoading(false);
    }
  };

  const handleToggleVisibility = async (testId: string) => {
    const isHidden = hiddenTests.includes(testId);
    let newHiddenTests;
    if (isHidden) {
      newHiddenTests = hiddenTests.filter(id => id !== testId);
      toast({ title: 'Test Visible', description: 'El test ahora se mostrará en la aplicación.' });
    } else {
      newHiddenTests = [...hiddenTests, testId];
      toast({ title: 'Test Oculto', description: 'El test ya no se mostrará como opción.' });
    }
    
    try {
      await saveAppConfig({ hiddenTests: newHiddenTests });
    } catch (error) {
      console.error("Error updating hidden tests:", error);
      toast({ variant: 'destructive', title: 'Error', description: 'No se pudo actualizar la visibilidad del test.' });
    }
  };
  
   const renderQuestionConfig = (question: Partial<Question>, index: number) => {
    const numericValue = typeof question.config?.defaultValue === 'number' ? question.config.defaultValue : 5;

    switch (question.type) {
      case 'image_slider':
        return (
          <>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-4 mt-2">
              <div><Label className="text-xs">Mínimo</Label><Input type="number" value={question.config?.min ?? 1} onChange={e => updateQuestion(index, 'config', { min: Number(e.target.value) })}/></div>
              <div><Label className="text-xs">Máximo</Label><Input type="number" value={question.config?.max ?? 10} onChange={e => updateQuestion(index, 'config', { max: Number(e.target.value) })}/></div>
              <div><Label className="text-xs">Paso (decimal)</Label><Input type="number" step="0.1" value={question.config?.step ?? 1} onChange={e => updateQuestion(index, 'config', { step: Number(e.target.value) })}/></div>
            </div>
             <div className="grid grid-cols-2 gap-4 mt-4">
              <div>
                  <Label className="text-xs">Texto Izquierdo</Label>
                  <Input value={question.config?.minImageLabel ?? ''} onChange={e => updateQuestion(index, 'config', { minImageLabel: e.target.value })}/>
              </div>
              <div>
                  <Label className="text-xs">Texto Derecho</Label>
                  <Input value={question.config?.maxImageLabel ?? ''} onChange={e => updateQuestion(index, 'config', { maxImageLabel: e.target.value })}/>
              </div>
              <div>
                  <Label className="text-xs">URL Imagen Izquierda</Label>
                  <Input value={question.config?.minImageUrl ?? ''} onChange={e => updateQuestion(index, 'config', { minImageUrl: e.target.value })} placeholder="Ej: https://.../sad-face.png"/>
              </div>
              <div>
                  <Label className="text-xs">URL Imagen Derecha</Label>
                  <Input value={question.config?.maxImageUrl ?? ''} onChange={e => updateQuestion(index, 'config', { maxImageUrl: e.target.value })} placeholder="Ej: https://.../happy-face.png"/>
              </div>
            </div>
            <div className="mt-4 p-4 border rounded-md bg-background">
                <Label className="text-xs text-muted-foreground">Vista Previa</Label>
                 <div className="flex justify-between text-sm text-gray-500 mb-2">
                    <span className="w-2/5 text-left">{question.config?.minImageLabel}</span>
                    <span className="w-2/5 text-right">{question.config?.maxImageLabel}</span>
                </div>
                <div className="flex items-center gap-4">
                    {question.config?.minImageUrl ? <Image src={question.config.minImageUrl} alt={question.config.minImageLabel || 'Min'} width={40} height={40} unoptimized/> : <Frown className="h-10 w-10 text-muted-foreground"/>}
                    <Slider
                        value={[numericValue]}
                        min={question.config?.min ?? 1}
                        max={question.config?.max ?? 10}
                        step={question.config?.step ?? 1}
                        className="w-full"
                        disabled
                    />
                    {question.config?.maxImageUrl ? <Image src={question.config.maxImageUrl} alt={question.config.maxImageLabel || 'Max'} width={40} height={40} unoptimized/> : <Smile className="h-10 w-10 text-muted-foreground"/>}
                </div>
                 <div className="text-center font-bold text-lg mt-2" style={{ color: question.color }}>
                    {numericValue.toFixed(question.config?.step && question.config.step < 1 ? 1 : 0)}
                 </div>
            </div>
          </>
        );
      case 'slider':
        return (
          <>
            <div className="grid grid-cols-2 md:grid-cols-5 gap-4 mt-2">
              <div><Label className="text-xs">Mínimo</Label><Input type="number" value={question.config?.min ?? 1} onChange={e => updateQuestion(index, 'config', { min: Number(e.target.value) })}/></div>
              <div><Label className="text-xs">Máximo</Label><Input type="number" value={question.config?.max ?? 10} onChange={e => updateQuestion(index, 'config', { max: Number(e.target.value) })}/></div>
              <div><Label className="text-xs">Paso (decimal)</Label><Input type="number" step="0.1" value={question.config?.step ?? 1} onChange={e => updateQuestion(index, 'config', { step: Number(e.target.value) })}/></div>
              <div><Label className="text-xs">Etiqueta Mín.</Label><Input value={question.config?.minLabel ?? ''} onChange={e => updateQuestion(index, 'config', { minLabel: e.target.value })}/></div>
              <div><Label className="text-xs">Etiqueta Máx.</Label><Input value={question.config?.maxLabel ?? ''} onChange={e => updateQuestion(index, 'config', { maxLabel: e.target.value })}/></div>
            </div>
            <div className="mt-4 p-4 border rounded-md bg-background">
                <Label className="text-xs text-muted-foreground">Vista Previa</Label>
                 <div className="flex items-center gap-4 mt-2">
                    <span className="text-sm text-muted-foreground basis-1/4 text-right">{question.config?.minLabel ?? (question.config?.min ?? 1)}</span>
                    <Slider
                        value={[numericValue]}
                        min={question.config?.min ?? 1}
                        max={question.config?.max ?? 10}
                        step={question.config?.step ?? 1}
                        className="w-full basis-1/2"
                        disabled
                    />
                    <span className="text-sm text-muted-foreground basis-1/4">{question.config?.maxLabel ?? (question.config?.max ?? 10)}</span>
                </div>
                 <div className="text-center font-bold text-lg mt-2" style={{ color: question.color }}>
                    {numericValue.toFixed(question.config?.step && question.config.step < 1 ? 1 : 0)}
                 </div>
            </div>
          </>
        );
      case 'likert':
      case 'multiple_choice':
        const options = question.type === 'likert' ? question.config?.likertOptions : question.config?.options;
        const type = question.type;
        return (
          <div className="space-y-2 mt-2">
            <Label className="text-xs">Opciones</Label>
            {options?.map((option, optIndex) => (
              <div key={optIndex} className="flex items-center gap-2">
                <Input 
                  value={option}
                  onChange={e => handleOptionChange(index, optIndex, e.target.value, type)}
                  placeholder={`Opción ${optIndex + 1}`}
                />
                <Button type="button" variant="ghost" size="icon" onClick={() => removeOption(index, optIndex, type)}>
                  <Trash2 className="h-4 w-4 text-destructive"/>
                </Button>
              </div>
            ))}
            <Button type="button" variant="outline" size="sm" onClick={() => addOption(index, type)}>
              <Plus className="mr-2 h-4 w-4"/> Agregar Opción
            </Button>
          </div>
        );
      case 'text':
         return (
          <div className="space-y-2 mt-2">
            <Label className="text-xs">Texto de ejemplo (placeholder)</Label>
            <Input 
              value={question.config?.placeholder || ''}
              onChange={e => updateQuestion(index, 'config', { placeholder: e.target.value })}
            />
          </div>
        );
       case 'number':
         return (
          <div className="space-y-2 mt-2">
            <Label className="text-xs">Unidad (ej: años, kg)</Label>
            <Input 
              value={question.config?.unit || ''}
              onChange={e => updateQuestion(index, 'config', { unit: e.target.value })}
            />
          </div>
        );
      default:
        return null;
    }
  };


  const renderListView = () => (
    <Card>
      <CardHeader>
        <div className="flex justify-between items-center">
            <CardTitle>Editor de Tests</CardTitle>
            <Button onClick={handleCreateNew}><Plus className="mr-2 h-4 w-4" /> Nuevo Test</Button>
        </div>
        <CardDescription>Crea, edita, oculta o elimina tests.</CardDescription>
      </CardHeader>
      <CardContent className="space-y-8">
        <div>
            <h3 className="text-lg font-semibold text-gray-700 mb-4">Listado de Tests</h3>
            {customTests.length > 0 ? (
                <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
                    {[...customTests].sort((a,b) => a.name.localeCompare(b.name)).map(test => {
                        const isHidden = hiddenTests.includes(test.id);
                        return (
                         <div key={test.id} className={`bg-card border rounded-lg p-4 flex flex-col transition-opacity ${isHidden ? 'opacity-50' : ''}`}>
                            <h4 className="font-semibold flex items-center gap-2">{test.name} {test.isPredefined && <span className="text-xs font-normal text-primary/80 bg-primary/10 px-2 py-1 rounded-full">Predefinido</span>}</h4>
                            <p className="text-sm text-muted-foreground flex-grow">{test.fields.length} preguntas</p>
                             <div className="flex gap-1 mt-2">{test.fields.map(f => <div key={f.id} className="w-3 h-3 rounded-full" style={{backgroundColor: f.color}}/>)}</div>
                            <div className="flex gap-2 mt-4">
                                <Button size="sm" variant="outline" onClick={() => handleEditTest(test.id)}>{test.isPredefined ? 'Copiar y Editar' : 'Editar'}</Button>
                                {test.isPredefined ? (
                                     <Button size="sm" variant={isHidden ? 'secondary' : 'outline'} onClick={() => handleToggleVisibility(test.id)}>
                                        {isHidden ? <Eye className="mr-2 h-4 w-4" /> : <EyeOff className="mr-2 h-4 w-4" />}
                                        {isHidden ? 'Mostrar' : 'Ocultar'}
                                    </Button>
                                ) : (
                                <AlertDialog>
                                    <AlertDialogTrigger asChild>
                                        <Button size="sm" variant="destructive" disabled={isLoading}><Trash2 className="mr-2 h-4 w-4"/>Eliminar</Button>
                                    </AlertDialogTrigger>
                                    <AlertDialogContent>
                                        <AlertDialogHeader>
                                          <AlertDialogTitle>¿Estás seguro?</AlertDialogTitle>
                                          <AlertDialogDescription>
                                           Esta acción no se puede deshacer. Se eliminará el test permanentemente.
                                          </AlertDialogDescription>
                                        </AlertDialogHeader>
                                        <AlertDialogFooter>
                                            <AlertDialogCancel>Cancelar</AlertDialogCancel>
                                            <AlertDialogAction onClick={() => handleDeleteTest(test.id)}>Eliminar</AlertDialogAction>
                                        </AlertDialogFooter>
                                    </AlertDialogContent>
                                </AlertDialog>
                                )}
                            </div>
                        </div>
                    )})}
                </div>
            ) : (
                <p className="text-muted-foreground text-center py-8">No hay tests. ¡Crea el primero!</p>
            )}
        </div>
      </CardContent>
    </Card>
  );

  const renderEditorView = () => (
    <Card>
        <CardHeader>
            <div className="flex justify-between items-center">
                <CardTitle>{editingTest && !editingTest.isPredefined ? `Editando: ${testName}` : 'Crear Nuevo Test'}</CardTitle>
                 <Button variant="ghost" onClick={handleBackToList}><ArrowLeft className="mr-2 h-4 w-4" /> Volver</Button>
            </div>
             {editingTest?.isPredefined && <CardDescription className="text-amber-600">Estás creando una copia de un test predefinido. Los cambios se guardarán como un nuevo test personalizado.</CardDescription>}
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Seccion de identificacion y config general */}
            <div className="space-y-4 p-4 border rounded-lg">
                <h3 className="font-medium">Configuración General del Test</h3>
                <div className="grid md:grid-cols-2 gap-4">
                    <div>
                        <Label htmlFor="test-name">Nombre del Test</Label>
                        <Input id="test-name" value={testName} onChange={e => setTestName(e.target.value)} placeholder="Ej: Test de Ansiedad Personalizado" />
                    </div>
                    <div>
                      <Label htmlFor="score-calculation">Cálculo de Puntaje Final</Label>
                      <Select value={scoreCalculation.method} onValueChange={(value) => setScoreCalculation({ method: value as 'sum' | 'average' | 'none' })}>
                          <SelectTrigger id="score-calculation"><SelectValue /></SelectTrigger>
                          <SelectContent>
                              <SelectItem value="none">Sin cálculo</SelectItem>
                              <SelectItem value="sum">Suma Simple</SelectItem>
                              <SelectItem value="average">Promedio</SelectItem>
                          </SelectContent>
                      </Select>
                    </div>
                </div>
                <div>
                  <Label htmlFor="cutoff-score">Puntaje de Corte (Opcional)</Label>
                  <Input id="cutoff-score" type="number" value={cutoffScore ?? ''} onChange={e => setCutoffScore(e.target.value ? Number(e.target.value) : null)} placeholder="Ej: 7"/>
                </div>
                <div>
                    <Label htmlFor="test-instructions">Instrucciones Generales (Opcional)</Label>
                    <Textarea id="test-instructions" value={instructions} onChange={e => setInstructions(e.target.value)} placeholder="Ej: Responde a las siguientes preguntas con la mayor honestidad posible." />
                </div>
            </div>
            
            {/* Seccion de preguntas */}
            <div className="space-y-4">
                <h3 className="text-lg font-semibold">Preguntas</h3>
                {questions.map((q, index) => (
                    <div key={index} className="flex flex-col gap-4 p-4 border rounded-lg bg-secondary/30">
                        <div className="flex items-start gap-4">
                            <div className="flex-grow space-y-2">
                               <Label htmlFor={`q-${index}-label`}>Pregunta {index + 1}</Label>
                               <Input id={`q-${index}-label`} value={q.label || ''} onChange={e => updateQuestion(index, 'label', e.target.value)} placeholder="Texto de la pregunta"/>
                            </div>
                             <div className="flex items-center gap-4 self-end">
                                <div className="space-y-2">
                                    <Label htmlFor={`q-${index}-type`}>Tipo</Label>
                                    <Select value={q.type} onValueChange={(value: Question['type']) => updateQuestion(index, 'type', value)}>
                                        <SelectTrigger id={`q-${index}-type`} className="w-40"><SelectValue/></SelectTrigger>
                                        <SelectContent>
                                            {questionTypes.map(qt => <SelectItem key={qt.value} value={qt.value}>{qt.label}</SelectItem>)}
                                        </SelectContent>
                                    </Select>
                                </div>
                                <div className="space-y-2">
                                    <Label htmlFor={`q-${index}-color`}>Color</Label>
                                    <Input id={`q-${index}-color`} type="color" value={q.color || '#000000'} onChange={e => updateQuestion(index, 'color', e.target.value)} className="p-1 h-10"/>
                                </div>
                                <div className="flex flex-col">
                                  <Button type="button" variant="ghost" size="icon" onClick={() => copyQuestion(index)} title="Copiar pregunta">
                                    <Copy className="h-4 w-4" />
                                  </Button>
                                  <Button type="button" variant="ghost" size="icon" onClick={() => removeQuestion(index)} title="Eliminar pregunta">
                                    <Trash2 className="h-4 w-4 text-destructive" />
                                  </Button>
                                </div>
                            </div>
                        </div>
                        
                        {/* Scoring config */}
                        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 items-center border-t pt-4 mt-2">
                           <div>
                             <Label htmlFor={`q-${index}-scoring`}>Puntaje</Label>
                             <Select value={q.scoring} onValueChange={(value: 'direct' | 'inverse') => updateQuestion(index, 'scoring', value)}>
                                <SelectTrigger id={`q-${index}-scoring`}><SelectValue/></SelectTrigger>
                                <SelectContent>
                                  <SelectItem value="direct">Directo</SelectItem>
                                  <SelectItem value="inverse">Inverso</SelectItem>
                                </SelectContent>
                             </Select>
                           </div>
                           <div className="flex items-center space-x-2 pt-6">
                             <Switch id={`q-${index}-weighted`} checked={q.weighted} onCheckedChange={(checked) => updateQuestion(index, 'weighted', checked)} />
                             <Label htmlFor={`q-${index}-weighted`}>Ponderado</Label>
                           </div>
                           {q.weighted && (
                             <div>
                               <Label htmlFor={`q-${index}-weight`}>Peso (0-1)</Label>
                               <Input 
                                 id={`q-${index}-weight`} 
                                 type="number"
                                 step="0.1" 
                                 min="0"
                                 max="1"
                                 value={q.weight ?? 1} 
                                 onChange={e => updateQuestion(index, 'weight', parseFloat(e.target.value))} />
                             </div>
                           )}
                        </div>

                         {/* Alerting config */}
                        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 items-center border-t pt-4 mt-2 border-amber-500/30">
                            <div className="flex items-center space-x-2 pt-6">
                                <Switch
                                    id={`q-${index}-alertEnabled`}
                                    checked={q.alertEnabled}
                                    onCheckedChange={(checked) => updateQuestion(index, 'alertEnabled', checked)}
                                />
                                <Label htmlFor={`q-${index}-alertEnabled`} className="flex items-center gap-1"><AlertTriangle className="h-4 w-4 text-amber-600"/>Generar Alerta</Label>
                            </div>
                            {q.alertEnabled && (
                                <div>
                                    <Label htmlFor={`q-${index}-alertThreshold`}>Si el valor es ≥ a</Label>
                                    <Input
                                        id={`q-${index}-alertThreshold`}
                                        type="number"
                                        value={q.alertThreshold ?? 0}
                                        onChange={e => updateQuestion(index, 'alertThreshold', parseFloat(e.target.value))}
                                    />
                                </div>
                            )}
                        </div>


                        {renderQuestionConfig(q, index)}
                    </div>
                ))}
                 <Button type="button" variant="outline" onClick={addQuestion}><Plus className="mr-2 h-4 w-4" /> Agregar Pregunta</Button>
            </div>

            <div className="flex gap-4">
                <Button onClick={handleSaveTest} disabled={isLoading}>{isLoading ? "Guardando..." : "Guardar Test"}</Button>
                <Button variant="outline" type="button" onClick={handleBackToList}>Cancelar</Button>
            </div>
        </CardContent>
    </Card>
  );

  return view === 'list' ? renderListView() : renderEditorView();
}
