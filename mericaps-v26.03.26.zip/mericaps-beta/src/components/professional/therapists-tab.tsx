
"use client";

import { useState, useMemo, useEffect } from 'react';
import type { Therapist, Supervisor, User, TherapistInfo, SpecialtyCategory } from '@/lib/definitions';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useToast } from '@/hooks/use-toast';
import { Textarea } from '../ui/textarea';
import { saveTherapistInfo, saveSpecialtyCategory } from '@/lib/firestore-actions';
import { Briefcase, Linkedin, Link as LinkIcon, Plus } from 'lucide-react';
import { Checkbox } from '../ui/checkbox';
import { Input } from '../ui/input';

interface TherapistsTabProps {
  therapists: Therapist[];
  therapistInfo: Record<string, TherapistInfo>;
  specialtyCategories: SpecialtyCategory[];
  user: User;
}

export function TherapistsTab({
  therapists = [],
  therapistInfo = {},
  specialtyCategories = [],
  user,
}: TherapistsTabProps) {
  const { toast } = useToast();
  const [selectedTherapistId, setSelectedTherapistId] = useState('');
  const [currentInfo, setCurrentInfo] = useState<Partial<TherapistInfo>>({});
  const [newSpecialty, setNewSpecialty] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const visibleTherapists = useMemo(() => {
    if (user.role === 'admin') {
      return therapists;
    }
    if (user.role === 'supervisor') {
      const supervisor = user.data as Supervisor;
      return therapists.filter(t => supervisor.assignedTherapists.includes(t.id));
    }
    return [];
  }, [user, therapists]);

  useEffect(() => {
    if (selectedTherapistId) {
      setCurrentInfo(therapistInfo[selectedTherapistId] || { specialties: [] });
    } else {
      setCurrentInfo({});
    }
  }, [selectedTherapistId, therapistInfo]);

  const handleInfoChange = (field: keyof Omit<TherapistInfo, 'id' | 'lastUpdated'>, value: string | string[]) => {
    setCurrentInfo(prev => ({ ...prev, [field]: value }));
  };
  
  const handleSpecialtyToggle = (specialtyId: string, isChecked: boolean) => {
    const currentSpecialties = currentInfo.specialties || [];
    let newSpecialties;
    if (isChecked) {
        newSpecialties = [...currentSpecialties, specialtyId];
    } else {
        newSpecialties = currentSpecialties.filter(id => id !== specialtyId);
    }
    handleInfoChange('specialties', newSpecialties);
  };

  const handleAddSpecialty = async () => {
    if (!newSpecialty.trim()) {
        toast({ variant: 'destructive', title: 'Error', description: 'El nombre de la especialidad no puede estar vacío.' });
        return;
    }
    const newId = newSpecialty.trim().toLowerCase().replace(/\s+/g, '-');
    if (specialtyCategories.some(s => s.id === newId)) {
        toast({ variant: 'destructive', title: 'Error', description: 'Esta especialidad ya existe.' });
        return;
    }
    
    const newCategory: SpecialtyCategory = {
        id: newId,
        name: newSpecialty.trim(),
        createdBy: user.id
    };

    try {
        await saveSpecialtyCategory(newCategory);
        toast({ title: 'Éxito', description: `Especialidad "${newCategory.name}" agregada.` });
        setNewSpecialty('');
    } catch (error) {
        console.error("Error adding specialty:", error);
        toast({ variant: 'destructive', title: 'Error', description: 'No se pudo agregar la especialidad.' });
    }
  };


  const handleSaveInfo = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedTherapistId) return;

    setIsLoading(true);
    const infoToSave: TherapistInfo = {
      id: selectedTherapistId,
      personalNotes: currentInfo.personalNotes || '',
      trainingObjectives: currentInfo.trainingObjectives || '',
      evaluations: currentInfo.evaluations || '',
      academicInfo: currentInfo.academicInfo || '',
      continuingEducation: currentInfo.continuingEducation || '',
      linkedinUrl: currentInfo.linkedinUrl || '',
      socialMediaUrl: currentInfo.socialMediaUrl || '',
      specialties: currentInfo.specialties || [],
      lastUpdated: new Date().toISOString(),
    };

    try {
      await saveTherapistInfo(infoToSave);
      toast({ title: 'Éxito', description: `Ficha del terapeuta guardada.` });
    } catch (error) {
      console.error("Error saving therapist info: ", error);
      toast({ variant: 'destructive', title: 'Error', description: 'No se pudo guardar la información.' });
    } finally {
      setIsLoading(false);
    }
  };
  
  const selectedTherapist = therapists.find(t => t.id === selectedTherapistId);
  const sortedSpecialties = useMemo(() => [...specialtyCategories].sort((a, b) => a.name.localeCompare(b.name)), [specialtyCategories]);


  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2"><Briefcase /> Fichas de Terapeutas</CardTitle>
        <CardDescription>Gestiona la información de desarrollo y supervisión de los terapeutas.</CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        <div>
          <Label htmlFor="therapist-selector">Seleccionar Terapeuta</Label>
          <Select value={selectedTherapistId} onValueChange={setSelectedTherapistId}>
            <SelectTrigger id="therapist-selector">
              <SelectValue placeholder="Selecciona un terapeuta..." />
            </SelectTrigger>
            <SelectContent>
              {visibleTherapists.map(t => (
                <SelectItem key={t.id} value={t.id}>{t.name}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        {selectedTherapistId && (
          <div className="space-y-4 pt-4 border-t">
            <h4 className="font-semibold text-lg">Ficha de {selectedTherapist?.name}</h4>
            <form onSubmit={handleSaveInfo} className="space-y-6">
               <div className="p-4 border rounded-lg bg-secondary/30">
                    <h3 className="font-medium text-lg mb-4">Información del Terapeuta (Solo Lectura)</h3>
                    <div className="grid md:grid-cols-2 gap-6">
                        <div>
                            <Label htmlFor="academic-info">Grados Académicos y Formación Profesional</Label>
                            <Textarea id="academic-info" value={currentInfo.academicInfo || 'No ingresado por el terapeuta.'} rows={4} className="bg-background" readOnly />
                        </div>
                        <div>
                            <Label htmlFor="continuing-education">Cursos y Formación Continua</Label>
                            <Textarea id="continuing-education" value={currentInfo.continuingEducation || 'No ingresado por el terapeuta.'} rows={4} className="bg-background" readOnly />
                        </div>
                        {currentInfo.linkedinUrl && (
                            <div>
                                <Label className="flex items-center gap-2"><Linkedin className="h-4 w-4" /> Perfil de LinkedIn</Label>
                                <a href={currentInfo.linkedinUrl} target="_blank" rel="noopener noreferrer" className="text-primary hover:underline text-sm break-all">{currentInfo.linkedinUrl}</a>
                            </div>
                        )}
                        {currentInfo.socialMediaUrl && (
                            <div>
                                <Label className="flex items-center gap-2"><LinkIcon className="h-4 w-4" /> Otro Enlace</Label>
                                <a href={currentInfo.socialMediaUrl} target="_blank" rel="noopener noreferrer" className="text-primary hover:underline text-sm break-all">{currentInfo.socialMediaUrl}</a>
                            </div>
                        )}
                    </div>
                </div>

                <div className="space-y-4 p-4 border rounded-lg">
                    <h3 className="font-medium text-lg">Especialidades</h3>
                     <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                        {sortedSpecialties.map(spec => (
                            <div key={spec.id} className="flex items-center gap-2">
                                <Checkbox
                                    id={`sup-spec-${spec.id}`}
                                    checked={(currentInfo.specialties || []).includes(spec.id)}
                                    onCheckedChange={(checked) => handleSpecialtyToggle(spec.id, !!checked)}
                                />
                                <Label htmlFor={`sup-spec-${spec.id}`} className="font-normal">{spec.name}</Label>
                            </div>
                        ))}
                    </div>
                    <div className="flex items-center gap-2 pt-4 border-t">
                        <Input
                            value={newSpecialty}
                            onChange={(e) => setNewSpecialty(e.target.value)}
                            placeholder="Nombre de la nueva especialidad"
                        />
                        <Button type="button" onClick={handleAddSpecialty}><Plus className="mr-2 h-4 w-4"/> Agregar</Button>
                    </div>
                </div>

              <div className="p-4 border rounded-lg">
                <h3 className="font-medium text-lg mb-4">Gestión de Supervisión (Editable)</h3>
                <div>
                  <Label htmlFor="personal-notes">Datos Personales / Anamnesis Profesional</Label>
                  <Textarea
                    id="personal-notes"
                    value={currentInfo.personalNotes || ''}
                    onChange={e => handleInfoChange('personalNotes', e.target.value)}
                    rows={4}
                    placeholder="Formación, estilo terapéutico, áreas de interés..."
                  />
                </div>
                <div>
                  <Label htmlFor="training-objectives">Objetivos de Entrenamiento</Label>
                  <Textarea
                    id="training-objectives"
                    value={currentInfo.trainingObjectives || ''}
                    onChange={e => handleInfoChange('trainingObjectives', e.target.value)}
                    rows={4}
                    placeholder="Definir objetivos para el desarrollo de habilidades, nuevas formaciones..."
                  />
                </div>
                <div>
                  <Label htmlFor="evaluations">Evaluaciones y Notas de Supervisión</Label>
                  <Textarea
                    id="evaluations"
                    value={currentInfo.evaluations || ''}
                    onChange={e => handleInfoChange('evaluations', e.target.value)}
                    rows={6}
                    placeholder="Registrar feedback de sesiones, discusiones de casos, evaluaciones de desempeño..."
                  />
                </div>
              </div>
              <Button type="submit" disabled={isLoading}>
                {isLoading ? 'Guardando...' : 'Guardar Ficha'}
              </Button>
            </form>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
