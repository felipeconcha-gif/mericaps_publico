"use client";

import { useState, useEffect } from 'react';
import { analyzeClinicalData } from '@/ai/flows/analyze-clinical-data';
import type { AnalyzeClinicalDataOutput, TestResult, ClinicalInfo } from '@/lib/definitions';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { useToast } from '@/hooks/use-toast';
import { Sparkles, Loader2, Lightbulb, Stethoscope, FileText } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';

interface ClinicalAnalysisProps {
  patientName: string;
  testResults: TestResult[];
  clinicalInfo?: ClinicalInfo;
}

export function ClinicalAnalysis({ patientName, testResults, clinicalInfo }: ClinicalAnalysisProps) {
  const [clinicalNotes, setClinicalNotes] = useState('');
  const [evaluationResults, setEvaluationResults] = useState('');
  const [analysis, setAnalysis] = useState<AnalyzeClinicalDataOutput | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    if (patientName) {
      // Pre-populate fields when a patient is selected
      const patientClinicalNotes = clinicalInfo?.notes || '';
      const patientDiagnosis = clinicalInfo?.diagnosis || '';
      const patientObjectives = clinicalInfo?.workObjectives || '';

      const combinedNotes = `Diagnóstico: ${patientDiagnosis}\nObjetivos: ${patientObjectives}\n\nNotas Adicionales:\n${patientClinicalNotes}`;
      setClinicalNotes(combinedNotes);

      const resultsText = testResults
        .filter(r => r.patient_name === patientName)
        .map(r => 
          `Fecha: ${new Date(r.session_date).toLocaleDateString()}\nTest: ${r.test_type}\nResultados: ${JSON.stringify(r.scores)}\nNotas: ${r.notes}`
        )
        .join('\n\n---\n\n');
      setEvaluationResults(resultsText);
    } else {
        setClinicalNotes('');
        setEvaluationResults('');
    }
    setAnalysis(null);
  }, [patientName, testResults, clinicalInfo]);

  const handleAnalysis = async () => {
    if (!clinicalNotes.trim() && !evaluationResults.trim()) {
      toast({
        variant: 'destructive',
        title: 'Datos insuficientes',
        description: 'Por favor, proporciona notas clínicas o resultados de evaluación.',
      });
      return;
    }
    setIsLoading(true);
    setAnalysis(null);
    try {
      const result = await analyzeClinicalData({
        clinicalNotes: clinicalNotes,
        evaluationResults: evaluationResults,
      });
      setAnalysis(result);
      toast({
        title: 'Análisis completado',
        description: 'La IA ha generado un resumen clínico.',
      });
    } catch (error) {
      console.error('Error analyzing clinical data:', error);
      toast({
        variant: 'destructive',
        title: 'Error de análisis',
        description: 'No se pudo completar el análisis. Inténtalo de nuevo.',
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="grid md:grid-cols-2 gap-6">
        <div>
          <Label htmlFor="clinical-notes-ai">Notas Clínicas del Terapeuta</Label>
          <Textarea
            id="clinical-notes-ai"
            value={clinicalNotes}
            onChange={(e) => setClinicalNotes(e.target.value)}
            rows={8}
            placeholder="Introduce notas, historial, diagnóstico..."
            className="bg-background"
          />
        </div>
        <div>
          <Label htmlFor="evaluation-results-ai">Resultados de Evaluaciones</Label>
          <Textarea
            id="evaluation-results-ai"
            value={evaluationResults}
            onChange={(e) => setEvaluationResults(e.target.value)}
            rows={8}
            placeholder="Pega aquí los resultados de los tests..."
            className="bg-background"
          />
        </div>
      </div>
      <Button onClick={handleAnalysis} disabled={isLoading}>
        {isLoading ? (
          <>
            <Loader2 className="mr-2 h-4 w-4 animate-spin" />
            Analizando...
          </>
        ) : (
          <>
            <Sparkles className="mr-2 h-4 w-4" />
            Analizar con IA
          </>
        )}
      </Button>

      {analysis && (
        <div className="grid md:grid-cols-3 gap-6 mt-6">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Resumen de Síntomas</CardTitle>
              <Lightbulb className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground whitespace-pre-wrap">{analysis.symptomsSummary}</p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Resumen de Tratamientos</CardTitle>
              <FileText className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground whitespace-pre-wrap">{analysis.treatmentsSummary}</p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Posibles Diagnósticos</CardTitle>
              <Stethoscope className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground whitespace-pre-wrap">{analysis.possibleDiagnoses}</p>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  );
}
