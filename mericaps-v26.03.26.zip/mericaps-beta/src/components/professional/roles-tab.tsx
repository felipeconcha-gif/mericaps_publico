
"use client";

import { useState, useMemo } from 'react';
import type { PatientCode, Supervisor, Therapist, User } from '@/lib/definitions';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Checkbox } from '@/components/ui/checkbox';
import { useToast } from '@/hooks/use-toast';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from "@/components/ui/alert-dialog";
import { Plus, ArrowLeft } from 'lucide-react';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { saveProfessional, deleteProfessional as deleteProfessionalFromDb, mergeProfessionals } from '@/lib/firestore-actions';
import { getAuth, createUserWithEmailAndPassword } from 'firebase/auth';
import { FirebaseError } from 'firebase/app';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '../ui/accordion';


interface RolesTabProps {
  supervisors: Supervisor[];
  therapists: Therapist[];
  patientCodes: PatientCode[];
  onProfessionalsUpdate: () => void;
  user: User;
}

export function RolesTab({ supervisors = [], therapists = [], patientCodes = [], onProfessionalsUpdate, user }: RolesTabProps) {
  const { toast } = useToast();
  const [view, setView] = useState<'list' | 'form'>('list');
  const [editingProfessional, setEditingProfessional] = useState<Partial<Supervisor | Therapist> | null>(null);
  const [role, setRole] = useState<'supervisor' | 'therapist'>('therapist');

  const [name, setName] = useState('');
  const [customCode, setCustomCode] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [expiry, setExpiry] = useState('');
  const [department, setDepartment] = useState('');
  const [assignedTherapists, setAssignedTherapists] = useState<Record<string, boolean>>({});
  
  const [sourceProf, setSourceProf] = useState('');
  const [targetProf, setTargetProf] = useState('');

  const [isLoading, setIsLoading] = useState(false);

  // Filter therapists based on the supervisor's department
  const therapistsInDepartment = useMemo(() => {
    if (user.role === 'supervisor' && 'department' in user.data) {
        return (therapists || []).filter(t => t.department === user.data.department);
    }
    return therapists || []; // Admins see all
  }, [therapists, user]);
  
  const allProfessionals = useMemo(() => {
    const supFormatted = (supervisors || []).map(s => ({ id: s.id, name: `${s.name} (Supervisor)` }));
    const therFormatted = (therapists || []).map(t => ({ id: t.id, name: `${t.name} (Terapeuta)` }));
    return [...supFormatted, ...therFormatted].sort((a,b) => a.name.localeCompare(b.name));
  }, [supervisors, therapists]);


  const handleShowForm = (prof: Supervisor | Therapist | null = null) => {
    if (prof) {
      const isSupervisor = 'assignedTherapists' in prof;
      setEditingProfessional(prof);
      setRole(isSupervisor ? 'supervisor' : 'therapist');
      setName(prof.name);
      setCustomCode(prof.code);
      setEmail(prof.email || '');
      setExpiry(prof.expiry || '');
      setDepartment(prof.department || (isSupervisor && user.role === 'supervisor' ? user.data.department : ''));
      setPassword('');
      
      if (isSupervisor && prof.assignedTherapists) {
        const assigned = prof.assignedTherapists.reduce((acc, id) => {
          acc[id] = true;
          return acc;
        }, {} as Record<string, boolean>);
        setAssignedTherapists(assigned);
      } else {
        setAssignedTherapists({});
      }
    } else {
      // Reset form for new professional
      setEditingProfessional(null);
      setName('');
      setCustomCode('');
      setEmail('');
      setPassword('');
      setExpiry('');
      // Pre-fill department for supervisors
      setDepartment(user.role === 'supervisor' ? user.data.department : '');
      setAssignedTherapists({});
      setRole('therapist');
    }
    setView('form');
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);

    if (!name.trim()) {
      toast({ variant: 'destructive', title: 'Error', description: 'El nombre es obligatorio.' });
      setIsLoading(false);
      return;
    }

    const isNew = !editingProfessional;
    let professionalId = editingProfessional?.id || '';

    try {
      // If creating a new user with email/password, create the auth user first
      if (isNew && email && password) {
        const auth = getAuth();
        try {
          const userCredential = await createUserWithEmailAndPassword(auth, email, password);
          professionalId = userCredential.user.uid; // Use the UID from Auth as the document ID
        } catch (authError: any) {
            let description = 'No se pudo crear el usuario de autenticación.';
            if (authError instanceof FirebaseError) {
                switch(authError.code) {
                    case 'auth/email-already-in-use':
                        description = 'Este correo electrónico ya está en uso.';
                        break;
                    case 'auth/weak-password':
                        description = 'La contraseña debe tener al menos 6 caracteres.';
                        break;
                    case 'auth/invalid-email':
                        description = 'El correo electrónico no es válido.';
                        break;
                    default:
                        description = authError.message;
                }
            }
            toast({ variant: 'destructive', title: 'Error de Autenticación', description });
            setIsLoading(false);
            return; // Stop execution if auth user creation fails
        }
      } else if (isNew) {
        professionalId = Date.now().toString(); // Fallback for code-based user
      }

      let code = customCode.trim().toUpperCase();
      if (!code && !isNew) { // Only auto-generate if new and no password was set
          const prefix = role === 'supervisor' ? 'SUP' : 'TER';
          const namePart = name.split(' ')[0].toUpperCase().substring(0, 5);
          const datePart = new Date().toISOString().slice(2, 10).replace(/-/g, '');
          code = `${prefix}-${namePart}-${datePart}`;
      }

      // Uniqueness check for the code, if one is present
      if (code) {
          const isCodeTaken = 
              therapists.some(t => t.code === code && t.id !== professionalId) ||
              supervisors.some(s => s.code === code && s.id !== professionalId) ||
              patientCodes.some(p => p.code === code);
          
          if (isCodeTaken) {
              toast({ variant: 'destructive', title: 'Error', description: 'Este código ya está en uso. Elige uno diferente.' });
              setIsLoading(false);
              return;
          }
      }
      
      let professionalData: Supervisor | Therapist;

      if (role === 'supervisor') {
        professionalData = {
          id: professionalId,
          code: code,
          name,
          email: email || null,
          department: department || null,
          expiry: expiry || null,
          created: editingProfessional?.created || new Date().toISOString(),
          assignedTherapists: Object.keys(assignedTherapists).filter(key => assignedTherapists[key]),
        };
      } else {
         professionalData = {
          id: professionalId,
          code: code,
          name,
          email: email || null,
          department: department || null,
          expiry: expiry || null,
          created: editingProfessional?.created || new Date().toISOString(),
        };
      }

      await saveProfessional(professionalData, role, isNew);
      toast({ title: 'Éxito', description: `Profesional ${isNew ? 'creado' : 'actualizado'} en la base de datos.` });
      onProfessionalsUpdate();
      setView('list');

    } catch (error) {
      console.error("Error saving professional:", error);
      toast({variant: 'destructive', title: 'Error', description: 'No se pudo guardar el profesional.'})
    } finally {
        setIsLoading(false);
    }
  };
  
  const handleDelete = async (id: string, roleToDelete: 'supervisor' | 'therapist') => {
     setIsLoading(true);
      try {
        await deleteProfessionalFromDb(id, roleToDelete);
        toast({ title: 'Éxito', description: "Profesional eliminado de la base de datos." });
        onProfessionalsUpdate();
      } catch (error) {
        console.error("Error deleting professional:", error);
        toast({ variant: 'destructive', title: 'Error', description: "No se pudo eliminar el profesional." });
      } finally {
        setIsLoading(false);
      }
  }
  
  const handleMerge = async () => {
    if (!sourceProf || !targetProf || sourceProf === targetProf) {
        toast({ variant: 'destructive', title: 'Error', description: 'Debes seleccionar dos profesionales diferentes.' });
        return;
    }
    setIsLoading(true);
    try {
        await mergeProfessionals(sourceProf, targetProf);
        toast({ title: 'Éxito', description: `Los perfiles han sido unificados.` });
        setSourceProf('');
        setTargetProf('');
        onProfessionalsUpdate(); // To refresh the lists
    } catch (error: any) {
        console.error("Error merging professionals: ", error);
        toast({ variant: 'destructive', title: 'Error al unificar', description: error.message || 'No se pudieron unificar los perfiles.' });
    } finally {
        setIsLoading(false);
    }
  };

  const renderList = () => (
    <Card>
      <CardHeader>
        <div className="flex justify-between items-center">
          <CardTitle>Gestión de Roles</CardTitle>
           {user.role !== 'therapist' && (
             <Button onClick={() => handleShowForm()}><Plus className="mr-2 h-4 w-4"/>Crear Profesional</Button>
           )}
        </div>
        <CardDescription>Crea y gestiona cuentas para Terapeutas y Supervisores.</CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        {user.role !== 'therapist' && (
          <div>
              <h3 className="text-lg font-semibold mb-2">Supervisores</h3>
              {supervisors.filter(s => user.role === 'admin' || s.id === user.id).length > 0 ? supervisors.filter(s => user.role === 'admin' || s.id === user.id).map(s => {
                const isExpired = s.expiry && new Date(s.expiry) < new Date();
                return (
                  <div key={s.id} className={`border rounded-lg p-4 mb-2 ${isExpired ? 'bg-destructive/10 border-destructive/20' : ''}`}>
                    <div className="flex justify-between items-start">
                      <div>
                        <h4 className="font-semibold flex items-center gap-2">{s.name} {isExpired && <span className="text-xs bg-destructive text-destructive-foreground px-2 py-0.5 rounded-full">Expirado</span>}</h4>
                        <p className="font-code text-primary">{s.code}</p>
                      </div>
                      <div className="flex gap-2">
                        <Button variant="outline" size="sm" onClick={() => handleShowForm(s)}>Editar</Button>
                        {user.role === 'admin' && (
                          <AlertDialog>
                              <AlertDialogTrigger asChild><Button variant="destructive" size="sm" disabled={isLoading}>Eliminar</Button></AlertDialogTrigger>
                              <AlertDialogContent>
                                  <AlertDialogHeader><AlertDialogTitle>¿Confirmar eliminación?</AlertDialogTitle><AlertDialogDescription>Se eliminará al supervisor {s.name}.</AlertDialogDescription></AlertDialogHeader>
                                  <AlertDialogFooter>
                                      <AlertDialogCancel>Cancelar</AlertDialogCancel>
                                      <AlertDialogAction onClick={() => handleDelete(s.id, 'supervisor')}>Eliminar</AlertDialogAction>
                                  </AlertDialogFooter>
                              </AlertDialogContent>
                          </AlertDialog>
                        )}
                      </div>
                    </div>
                     <div className="mt-2 text-sm">
                      <p className="font-medium">Terapeutas asignados:</p>
                      <div className="flex flex-wrap gap-2 mt-1">
                          {s.assignedTherapists && s.assignedTherapists.length > 0 ? s.assignedTherapists.map(id => (
                              <span key={id} className="text-xs bg-secondary px-2 py-1 rounded-full">{(therapists || []).find(t => t.id === id)?.name || 'N/A'}</span>
                          )) : <p className="text-xs text-muted-foreground">Ninguno</p>}
                      </div>
                     </div>
                  </div>
                )
              }) : <p className="text-muted-foreground text-center py-4">No hay supervisores creados.</p>}
          </div>
        )}
        <div>
            <h3 className="text-lg font-semibold mb-2">Terapeutas</h3>
            {therapistsInDepartment.length > 0 ? therapistsInDepartment.map(t => {
              const isExpired = t.expiry && new Date(t.expiry) < new Date();
              return (
                <div key={t.id} className={`border rounded-lg p-4 mb-2 ${isExpired ? 'bg-destructive/10 border-destructive/20' : ''}`}>
                  <div className="flex justify-between items-start">
                    <div>
                      <h4 className="font-semibold flex items-center gap-2">{t.name} {isExpired && <span className="text-xs bg-destructive text-destructive-foreground px-2 py-0.5 rounded-full">Expirado</span>}</h4>
                      <p className="font-code text-primary">{t.code}</p>
                    </div>
                    {user.role !== 'therapist' && (
                      <div className="flex gap-2">
                        <Button variant="outline" size="sm" onClick={() => handleShowForm(t)}>Editar</Button>
                        <AlertDialog>
                            <AlertDialogTrigger asChild><Button variant="destructive" size="sm" disabled={isLoading}>Eliminar</Button></AlertDialogTrigger>
                            <AlertDialogContent>
                                <AlertDialogHeader><AlertDialogTitle>¿Confirmar eliminación?</AlertDialogTitle><AlertDialogDescription>Se eliminará al terapeuta {t.name}.</AlertDialogDescription></AlertDialogHeader>
                                <AlertDialogFooter>
                                    <AlertDialogCancel>Cancelar</AlertDialogCancel>
                                    <AlertDialogAction onClick={() => handleDelete(t.id, 'therapist')}>Eliminar</AlertDialogAction>
                                </AlertDialogFooter>
                            </AlertDialogContent>
                        </AlertDialog>
                      </div>
                    )}
                  </div>
                </div>
              )
            }) : <p className="text-muted-foreground text-center py-4">No hay terapeutas en este departamento.</p>}
        </div>

        <Accordion type="single" collapsible className="w-full mt-6">
            <AccordionItem value="unify-professionals">
                <AccordionTrigger>Unificar Profesionales</AccordionTrigger>
                <AccordionContent className="pt-4 space-y-6">
                    <div className="p-4 border border-destructive/50 rounded-lg bg-destructive/5">
                        <h4 className="font-semibold text-destructive">¡Atención! Acción Destructiva</h4>
                        <p className="text-sm text-destructive/90 mt-1">
                            Esta herramienta se usa para combinar dos perfiles profesionales duplicados.
                            Todos los datos (pacientes, resultados, asignaciones) del profesional de origen se transferirán al de destino.
                            El profesional de origen será **eliminado permanentemente**. Esto es útil para migrar un usuario de "solo código" a uno con "email/contraseña".
                            Usa esta función con extrema precaución.
                        </p>
                    </div>
                    <div className="grid md:grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="source-prof">Profesional de Origen (a eliminar)</Label>
                        <Select value={sourceProf} onValueChange={setSourceProf}>
                          <SelectTrigger><SelectValue placeholder="Seleccionar profesional..." /></SelectTrigger>
                          <SelectContent>
                            {allProfessionals.map(p => <SelectItem key={`source-${p.id}`} value={p.id}>{p.name}</SelectItem>)}
                          </SelectContent>
                        </Select>
                      </div>
                      <div>
                        <Label htmlFor="target-prof">Profesional de Destino (a conservar)</Label>
                        <Select value={targetProf} onValueChange={setTargetProf}>
                          <SelectTrigger><SelectValue placeholder="Seleccionar profesional..." /></SelectTrigger>
                          <SelectContent>
                            {allProfessionals.filter(p => p.id !== sourceProf).map(p => <SelectItem key={`target-${p.id}`} value={p.id}>{p.name}</SelectItem>)}
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                    <AlertDialog>
                      <AlertDialogTrigger asChild>
                        <Button variant="destructive" disabled={!sourceProf || !targetProf || sourceProf === targetProf || isLoading}>
                          Unificar Profesionales
                        </Button>
                      </AlertDialogTrigger>
                      <AlertDialogContent>
                        <AlertDialogHeader>
                          <AlertDialogTitle>¿Estás absolutamente seguro?</AlertDialogTitle>
                          <AlertDialogDescription>
                            Vas a unificar a <span className="font-bold">{allProfessionals.find(p => p.id === sourceProf)?.name}</span> en <span className="font-bold">{allProfessionals.find(p => p.id === targetProf)?.name}</span>.
                            El perfil de origen será eliminado permanentemente. Esta acción no se puede deshacer.
                          </AlertDialogDescription>
                        </AlertDialogHeader>
                        <AlertDialogFooter>
                          <AlertDialogCancel>Cancelar</AlertDialogCancel>
                          <AlertDialogAction onClick={handleMerge} disabled={isLoading}>
                            {isLoading ? 'Unificando...' : 'Sí, unificar perfiles'}
                          </AlertDialogAction>
                        </AlertDialogFooter>
                      </AlertDialogContent>
                    </AlertDialog>
                </AccordionContent>
            </AccordionItem>
        </Accordion>
      </CardContent>
    </Card>
  );

  const renderForm = () => (
     <Card>
      <CardHeader className="flex flex-row justify-between items-center">
        <CardTitle>{editingProfessional ? 'Editando Profesional' : 'Crear Nuevo Profesional'}</CardTitle>
        <Button variant="ghost" onClick={() => setView('list')}><ArrowLeft className="mr-2 h-4 w-4"/> Volver</Button>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSave} className="space-y-4">
          <div className="grid md:grid-cols-3 gap-4">
            <div><Label htmlFor="professional-name">Nombre</Label><Input id="professional-name" value={name} onChange={e => setName(e.target.value)} required /></div>
            <div><Label htmlFor="professional-code">Código de Acceso (Opcional)</Label><Input id="professional-code" value={customCode} onChange={e => setCustomCode(e.target.value)} className="font-code uppercase" placeholder="Generado automáticamente" /></div>
            <div>
              <Label htmlFor="professional-role">Rol</Label>
              <Select value={role} onValueChange={(v) => setRole(v as 'supervisor' | 'therapist')} disabled={!!editingProfessional}>
                  <SelectTrigger><SelectValue/></SelectTrigger>
                  <SelectContent>
                      <SelectItem value="therapist">Terapeuta</SelectItem>
                      <SelectItem value="supervisor">Supervisor</SelectItem>
                  </SelectContent>
              </Select>
            </div>
          </div>
          <div className="grid md:grid-cols-2 gap-4">
             <div><Label htmlFor="professional-email">Email (para acceso con contraseña)</Label><Input id="professional-email" type="email" value={email} onChange={e => setEmail(e.target.value)} /></div>
             {!editingProfessional && (
                <div>
                    <Label htmlFor="professional-password">Contraseña (para nuevo acceso con email)</Label>
                    <Input id="professional-password" type="password" value={password} onChange={e => setPassword(e.target.value)} placeholder="Dejar en blanco para crear solo con código" />
                </div>
              )}
          </div>
           <div className="grid md:grid-cols-2 gap-4">
             <div>
                <Label htmlFor="professional-department">Departamento (Opcional)</Label>
                <Input id="professional-department" value={department} onChange={e => setDepartment(e.target.value)} disabled={user.role === 'supervisor' && !editingProfessional} />
             </div>
             <div><Label htmlFor="professional-expiry">Válido hasta (Opcional)</Label><Input id="professional-expiry" type="date" value={expiry} onChange={e => setExpiry(e.target.value)} /></div>
          </div>
          
          {role === 'supervisor' && (
            <div>
              <Label>Terapeutas Asignados</Label>
              <div className="p-4 border rounded-lg bg-secondary/30 grid grid-cols-2 md:grid-cols-3 gap-3 max-h-48 overflow-y-auto">
                {therapistsInDepartment.map(t => (
                  <div key={t.id} className="flex items-center space-x-2">
                    <Checkbox id={`therapist-${t.id}`} checked={!!assignedTherapists[t.id]} onCheckedChange={checked => setAssignedTherapists(prev => ({...prev, [t.id]: !!checked}))} />
                    <label htmlFor={`therapist-${t.id}`} className="text-sm font-medium">{t.name}</label>
                  </div>
                ))}
              </div>
            </div>
          )}

          <div className="flex gap-4">
            <Button type="submit" disabled={isLoading}>{isLoading ? 'Guardando...' : 'Guardar'}</Button>
            <Button variant="outline" type="button" onClick={() => setView('list')}>Cancelar</Button>
          </div>
        </form>
      </CardContent>
     </Card>
  );

  return view === 'list' ? renderList() : renderForm();
}
