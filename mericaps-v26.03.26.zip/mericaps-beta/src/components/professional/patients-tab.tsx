
"use client";

import { useState, useMemo } from 'react';
import type { CustomTest, PatientCode, Supervisor, ClinicalInfo, User, Therapist, ScheduledReminder, TestResult } from '@/lib/definitions';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '@/components/ui/accordion';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Checkbox } from '@/components/ui/checkbox';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useToast } from '@/hooks/use-toast';
import { Textarea } from '../ui/textarea';
import { Mail, Copy, Send, BellRing, Trash2, CalendarOff, User as UserIcon, Edit } from 'lucide-react';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from "@/components/ui/alert-dialog";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter, DialogClose } from '@/components/ui/dialog';
import { Calendar } from '@/components/ui/calendar';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Calendar as CalendarIcon } from 'lucide-react';
import { format } from 'date-fns';
import { cn } from '@/lib/utils';
import { savePatientCode, deletePatientCode as deletePatientCodeFromDb, saveClinicalInfo, saveTestResult, saveScheduledReminder, updateScheduledReminder, updatePatientCode, mergePatientCases } from '@/lib/firestore-actions';


interface PatientsTabProps {
  patientCodes: PatientCode[];
  customTests: CustomTest[];
  therapists: Therapist[];
  supervisors: Supervisor[];
  clinicalInfo: Record<string, ClinicalInfo>;
  scheduledReminders: ScheduledReminder[];
  testResults: TestResult[];
  user: User;
}

export function PatientsTab({
  patientCodes = [],
  customTests = [],
  therapists = [],
  supervisors = [],
  clinicalInfo = {},
  scheduledReminders = [],
  testResults = [],
  user,
}: PatientsTabProps) {
  const { toast } = useToast();
  const [newPatientName, setNewPatientName] = useState('');
  const [newPatientEmail, setNewPatientEmail] = useState('');
  const [customCode, setCustomCode] = useState('');
  const [expiry, setExpiry] = useState('');
  const [maxUses, setMaxUses] = useState('');
  const [assignedTests, setAssignedTests] = useState<Record<string, boolean>>({});
  const [assignedTherapist, setAssignedTherapist] = useState('');
  
  const [selectedPatient, setSelectedPatient] = useState('');
  const [currentClinicalInfo, setCurrentClinicalInfo] = useState<Partial<ClinicalInfo>>({});

  const [reminderPatient, setReminderPatient] = useState('');
  const [reminderDate, setReminderDate] = useState('');
  
  const [isLoading, setIsLoading] = useState(false);
  
  const [absenceDate, setAbsenceDate] = useState<Date | undefined>(new Date());
  const [absenceReason, setAbsenceReason] = useState('');
  const [absenceNotes, setAbsenceNotes] = useState('');
  const [isAbsenceDialogOpen, setIsAbsenceDialogOpen] = useState(false);

  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [editingPatient, setEditingPatient] = useState<PatientCode | null>(null);
  const [editFormState, setEditFormState] = useState<Partial<PatientCode> & { assignedTests?: Record<string, boolean> }>({});

  const [sourcePatient, setSourcePatient] = useState('');
  const [targetPatient, setTargetPatient] = useState('');


  const allTests = customTests.map(test => ({ id: test.id, name: test.name }));
  
  const visibleTherapists = useMemo(() => {
    if (user.role === 'admin') {
      return therapists;
    }
    if (user.role === 'supervisor' && user.data && 'department' in user.data) {
        const supervisor = user.data as Supervisor;
        return therapists.filter(t => t.department === supervisor.department);
    }
    if (user.role === 'therapist') {
      return therapists.filter(t => t.id === user.id);
    }
    return [];
  }, [user, therapists]);

  const visiblePatientCodes = useMemo(() => {
    const visibleTherapistIds = (visibleTherapists || []).map(t => t.id);
    if (user.role === 'admin') {
      return patientCodes;
    }
    return patientCodes.filter(pc => pc.assignedTherapist && visibleTherapistIds.includes(pc.assignedTherapist));
  }, [patientCodes, visibleTherapists, user.role]);

  const patientOptions = useMemo(() => {
    const namesFromCodes = (visiblePatientCodes || []).map(pc => pc.patientName);
    const namesFromInfo = Object.keys(clinicalInfo).filter(name => {
      const code = (patientCodes || []).find(pc => pc.patientName === name);
      return code ? (visibleTherapists || []).map(t => t.id).includes(code.assignedTherapist) : (user.role === 'admin');
    });
    const namesFromResults = (testResults || [])
        .filter(r => r.assigned_therapist && visibleTherapists.map(t => t.id).includes(r.assigned_therapist))
        .map(r => r.patient_name);

    return [...new Set([...namesFromCodes, ...namesFromInfo, ...namesFromResults])].sort();
  }, [visiblePatientCodes, clinicalInfo, patientCodes, visibleTherapists, user.role, testResults]);

  
  const handleGenerateCode = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newPatientName.trim()) {
        toast({ variant: 'destructive', title: 'Error', description: 'El nombre del paciente es obligatorio.' });
        return;
    }
    const selectedTests = Object.keys(assignedTests).filter(key => assignedTests[key]);
    if (selectedTests.length === 0) {
        toast({ variant: 'destructive', title: 'Error', description: 'Debes asignar al menos un test.' });
        return;
    }
    if (!assignedTherapist) {
        toast({ variant: 'destructive', title: 'Error', description: 'Debes asignar un terapeuta.' });
        return;
    }
    
    setIsLoading(true);

    let code = customCode.trim().toUpperCase();
    if (!code) {
        const namePart = newPatientName.split(' ')[0].toUpperCase().substring(0, 5);
        const datePart = new Date().toISOString().slice(2, 10).replace(/-/g, '');
        code = `${namePart}-${datePart}`;
    }

    if (patientCodes.some(pc => pc.code === code) || therapists.some(t => t.code === code) || supervisors.some(s => s.code === code)) {
        toast({ variant: 'destructive', title: 'Error', description: 'Este código ya existe. Elige uno diferente.' });
        setIsLoading(false);
        return;
    }
    
    const newCodeId = Date.now().toString();
    const newCode: PatientCode = {
        id: newCodeId,
        code,
        patientName: newPatientName.toLowerCase(),
        patientEmail: newPatientEmail.toLowerCase() || null,
        assignedTests: selectedTests,
        assignedTherapist: assignedTherapist,
        expiry: expiry || null,
        maxUses: maxUses ? parseInt(maxUses) : null,
        created: new Date().toISOString(),
        usedCount: 0,
        lastUsed: null,
    };
    
    try {
      await savePatientCode(newCode);
      toast({ title: 'Éxito', description: `Código ${code} generado para ${newPatientName}.` });
      
      // Reset form
      setNewPatientName('');
      setNewPatientEmail('');
      setCustomCode('');
      setExpiry('');
      setMaxUses('');
      setAssignedTests({});
      setAssignedTherapist('');
    } catch (error) {
      console.error("Error saving patient code: ", error);
      toast({ variant: 'destructive', title: 'Error', description: 'No se pudo guardar el código del paciente.' });
    } finally {
      setIsLoading(false);
    }
  };
  
  const handlePatientSelect = (patientName: string) => {
    setSelectedPatient(patientName);
    const info = clinicalInfo[patientName] || {};
    setCurrentClinicalInfo(info);
  };
  
  const handleClinicalInfoSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedPatient) return;
    
    setIsLoading(true);

    const infoToSave: ClinicalInfo = {
        id: selectedPatient,
        workObjectives: currentClinicalInfo.workObjectives || '',
        diagnosis: currentClinicalInfo.diagnosis || '',
        notes: currentClinicalInfo.notes || '',
        processStatus: currentClinicalInfo.processStatus || 'en-proceso',
        weeklyTasks: currentClinicalInfo.weeklyTasks || '',
        sessionMaterialLink: currentClinicalInfo.sessionMaterialLink || '',
        lastUpdated: new Date().toISOString(),
    };
    
    try {
      await saveClinicalInfo(infoToSave);
      toast({title: 'Éxito', description: `Información clínica de ${selectedPatient} guardada.`});
    } catch (error) {
      console.error("Error saving clinical info: ", error);
      toast({ variant: 'destructive', title: 'Error', description: 'No se pudo guardar la información clínica.' });
    } finally {
      setIsLoading(false);
    }
  };
  
   const handleSaveAbsence = async () => {
    if (!selectedPatient || !absenceDate || !absenceReason) {
      toast({ variant: 'destructive', title: 'Error', description: 'La fecha y el motivo de la inasistencia son obligatorios.' });
      return;
    }
    
    setIsLoading(true);

    const patientCode = patientCodes.find(pc => pc.patientName === selectedPatient);
    if (!patientCode) {
      toast({ variant: 'destructive', title: 'Error', description: 'No se encontró el código del paciente. No se puede registrar la inasistencia.' });
      setIsLoading(false);
      return;
    }

    const newAbsence: TestResult = {
      id: `absence-${Date.now()}`,
      patient_name: selectedPatient,
      session_date: format(absenceDate, 'yyyy-MM-dd'),
      test_date: new Date().toISOString(),
      test_type: 'absence',
      session_status: 'not-completed',
      not_completed_reason: absenceReason,
      other_reason_text: '',
      scores: {},
      notes: `Inasistencia registrada por el profesional. ${absenceNotes || ''}`.trim(),
      source: 'professional',
      assigned_therapist: patientCode.assignedTherapist,
    };
    
    try {
      await saveTestResult(newAbsence);
      toast({ title: 'Inasistencia Registrada', description: `Se ha guardado la inasistencia para ${selectedPatient}.` });
      setAbsenceDate(new Date());
      setAbsenceReason('');
      setAbsenceNotes('');
      setIsAbsenceDialogOpen(false);
    } catch (error) {
      console.error("Error saving absence: ", error);
      toast({ variant: 'destructive', title: 'Error', description: 'No se pudo guardar la inasistencia.' });
    } finally {
      setIsLoading(false);
    }
  };


  const handleClinicalInfoChange = (field: keyof Omit<ClinicalInfo, 'id' | 'lastUpdated'>, value: string) => {
    setCurrentClinicalInfo(prev => ({...prev, [field]: value}));
  }

  const handleScheduleReminder = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!reminderPatient || !reminderDate) {
      toast({ variant: 'destructive', title: 'Error', description: 'Debes seleccionar un paciente y una fecha.' });
      return;
    }
    const patientData = patientCodes.find(p => p.patientName === reminderPatient);
    const newReminder: ScheduledReminder = {
      id: Date.now().toString(),
      patientName: reminderPatient,
      patientEmail: patientData?.patientEmail || null,
      sendDate: reminderDate,
      status: 'pending',
      created: new Date().toISOString(),
    };
    
    try {
      await saveScheduledReminder(newReminder);
      toast({ title: 'Recordatorio Programado', description: `Se ha programado un recordatorio para ${reminderPatient}.` });
      setReminderPatient('');
      setReminderDate('');
    } catch (error) {
      console.error("Error saving reminder:", error);
      toast({ variant: 'destructive', title: 'Error', description: 'No se pudo guardar el recordatorio.' });
    }
  };

  const markReminderAsSent = async (reminderId: string) => {
    const reminder = scheduledReminders.find(r => r.id === reminderId);
    if (!reminder) return;
    
    try {
        await updateScheduledReminder({ ...reminder, status: 'sent' });
        toast({ title: 'Recordatorio Marcado', description: 'El recordatorio ha sido marcado como enviado.' });
    } catch (error) {
        console.error("Error updating reminder:", error);
        toast({ variant: 'destructive', title: 'Error', description: 'No se pudo actualizar el recordatorio.' });
    }
  };


  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text).then(() => {
        toast({ title: 'Copiado', description: 'Código copiado al portapapeles.' });
    }, (err) => {
        toast({ variant: 'destructive', title: 'Error', description: 'No se pudo copiar el código.' });
    });
  };

    const handleDeletePatientCode = async (codeId: string) => {
        setIsLoading(true);
        try {
          await deletePatientCodeFromDb(codeId);
          toast({ title: 'Éxito', description: 'El código del paciente ha sido eliminado.' });
        } catch (error) {
          console.error("Error deleting patient code: ", error);
          toast({ variant: 'destructive', title: 'Error', description: 'No se pudo eliminar el código del paciente.' });
        } finally {
          setIsLoading(false);
        }
    };
    
    const handleOpenEditDialog = (patientCode: PatientCode) => {
        setEditingPatient(patientCode);
        const testsRecord: Record<string, boolean> = {};
        patientCode.assignedTests.forEach(testId => {
            testsRecord[testId] = true;
        });
        setEditFormState({
            ...patientCode,
            assignedTests: testsRecord,
        });
        setIsEditDialogOpen(true);
    };

    const handleUpdatePatientCode = async () => {
        if (!editingPatient || !editFormState.code || !editFormState.patientName) {
            toast({ variant: 'destructive', title: 'Error', description: 'El nombre y el código son obligatorios.' });
            return;
        }

        setIsLoading(true);
        const newCode = editFormState.code.trim().toUpperCase();

        const isCodeTaken = patientCodes.some(p => p.code === newCode && p.id !== editingPatient.id) ||
                            therapists.some(t => t.code === newCode) ||
                            supervisors.some(s => s.code === newCode);

        if (isCodeTaken) {
            toast({ variant: 'destructive', title: 'Código en uso', description: 'Este código ya está asignado. Por favor, elige uno diferente.' });
            setIsLoading(false);
            return;
        }

        const updatedTests = editFormState.assignedTests ? Object.keys(editFormState.assignedTests).filter(key => editFormState.assignedTests![key]) : [];

        const updatedPatientCode: PatientCode = {
            ...editingPatient,
            patientName: editFormState.patientName.toLowerCase(),
            patientEmail: editFormState.patientEmail ? editFormState.patientEmail.toLowerCase() : null,
            code: newCode,
            assignedTests: updatedTests,
            assignedTherapist: editFormState.assignedTherapist || editingPatient.assignedTherapist,
            expiry: editFormState.expiry || null,
            maxUses: editFormState.maxUses ? Number(editFormState.maxUses) : null,
        };

        try {
            await updatePatientCode(updatedPatientCode);
            toast({ title: 'Paciente Actualizado', description: `Los datos de ${updatedPatientCode.patientName} han sido guardados.` });
            setIsEditDialogOpen(false);
            setEditingPatient(null);
        } catch (error) {
            console.error("Error updating patient code:", error);
            toast({ variant: 'destructive', title: 'Error', description: 'No se pudo actualizar el código del paciente.' });
        } finally {
            setIsLoading(false);
        }
    };

    const handleEditFormChange = (field: keyof PatientCode, value: any) => {
        setEditFormState(prev => ({ ...prev, [field]: value }));
    };

    const handleEditAssignedTestChange = (testId: string, checked: boolean) => {
        setEditFormState(prev => ({
            ...prev,
            assignedTests: {
                ...prev.assignedTests,
                [testId]: checked,
            }
        }));
    };
    
    const handleMergeCases = async () => {
        if (!sourcePatient || !targetPatient || sourcePatient === targetPatient) {
            toast({ variant: 'destructive', title: 'Error', description: 'Debes seleccionar dos pacientes diferentes.' });
            return;
        }
        setIsLoading(true);
        try {
            await mergePatientCases(sourcePatient, targetPatient);
            toast({ title: 'Éxito', description: `Los casos de ${sourcePatient} y ${targetPatient} han sido unificados.` });
            setSelectedPatient(''); // Reset selections
            setSourcePatient('');
            setTargetPatient('');
        } catch (error) {
            console.error("Error merging patient cases: ", error);
            toast({ variant: 'destructive', title: 'Error', description: 'No se pudieron unificar los casos.' });
        } finally {
            setIsLoading(false);
        }
    };


  const sortedPatientCodes = [...(visiblePatientCodes || [])].sort((a, b) => a.patientName.localeCompare(b.patientName));
  const pendingReminders = (scheduledReminders || []).filter(r => r.status === 'pending' && new Date(r.sendDate) <= new Date() && patientOptions.includes(r.patientName));
  const selectedPatientTherapistName = useMemo(() => {
    if (!selectedPatient) return null;
    const patientCode = patientCodes.find(pc => pc.patientName === selectedPatient);
    if (!patientCode) return null;
    const therapist = therapists.find(t => t.id === patientCode.assignedTherapist);
    return therapist?.name || null;
  }, [selectedPatient, patientCodes, therapists]);

  return (
    <>
      <Card>
        <CardHeader>
          <CardTitle>Gestión de Pacientes</CardTitle>
          <CardDescription>Crea y gestiona códigos, información clínica y recordatorios para pacientes.</CardDescription>
        </CardHeader>
        <CardContent>
          <Accordion type="single" collapsible className="w-full">
            <AccordionItem value="item-1">
              <AccordionTrigger>Crear Nuevo Paciente y Código</AccordionTrigger>
              <AccordionContent>
                <form onSubmit={handleGenerateCode} className="space-y-4 pt-4">
                  <div className="grid md:grid-cols-2 gap-4">
                      <div>
                          <Label htmlFor="code-patient-name">Nombre del Paciente</Label>
                          <Input id="code-patient-name" value={newPatientName} onChange={e => setNewPatientName(e.target.value)} required />
                      </div>
                       <div>
                          <Label htmlFor="code-patient-email">Email del Paciente (Opcional)</Label>
                          <Input id="code-patient-email" type="email" value={newPatientEmail} onChange={e => setNewPatientEmail(e.target.value)} />
                      </div>
                      <div>
                          <Label htmlFor="patient-code-custom">Código Personalizado (Opcional)</Label>
                          <Input id="patient-code-custom" value={customCode} onChange={e => setCustomCode(e.target.value)} className="font-code uppercase" />
                      </div>
                  </div>
                  <div>
                    <Label>Tests Asignados</Label>
                    <div className="p-4 border rounded-lg bg-secondary/30 grid grid-cols-2 md:grid-cols-3 gap-3">
                      {allTests.map(test => (
                          <div key={test.id} className="flex items-center space-x-2">
                             <Checkbox id={`test-${test.id}`} checked={!!assignedTests[test.id]} onCheckedChange={checked => setAssignedTests(prev => ({...prev, [test.id]: !!checked}))}/>
                             <label htmlFor={`test-${test.id}`} className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70">{test.name}</label>
                          </div>
                      ))}
                    </div>
                  </div>
                  <div>
                      <Label htmlFor="assigned-therapist">Asignar Terapeuta</Label>
                      <Select value={assignedTherapist} onValueChange={setAssignedTherapist}>
                          <SelectTrigger><SelectValue placeholder="Seleccionar terapeuta"/></SelectTrigger>
                          <SelectContent>
                              {(visibleTherapists || []).map(t => <SelectItem key={t.id} value={t.id}>{t.name}</SelectItem>)}
                          </SelectContent>
                      </Select>
                  </div>
                  <div className="grid md:grid-cols-2 gap-4">
                      <div>
                          <Label htmlFor="code-expiry">Válido hasta (Opcional)</Label>
                          <Input id="code-expiry" type="date" value={expiry} onChange={e => setExpiry(e.target.value)} />
                      </div>
                      <div>
                          <Label htmlFor="code-max-uses">Máximo de Usos (Opcional)</Label>
                          <Input id="code-max-uses" type="number" min="1" value={maxUses} onChange={e => setMaxUses(e.target.value)} />
                      </div>
                  </div>
                  <Button type="submit" disabled={isLoading}>{isLoading ? 'Generando...' : 'Generar Código'}</Button>
                </form>
              </AccordionContent>
            </AccordionItem>
            <AccordionItem value="item-2">
              <AccordionTrigger>Listado de Pacientes y Códigos</AccordionTrigger>
              <AccordionContent className="pt-4 space-y-2">
                  {sortedPatientCodes.length > 0 ? (
                      sortedPatientCodes.map(pc => {
                          const appUrl = typeof window !== 'undefined' ? window.location.origin : '';
                          const subject = encodeURIComponent('Tu código de acceso a MERICAPS');
                          const body = encodeURIComponent(`¡Hola, ${pc.patientName}!\n\nAquí tienes tu código de acceso para la plataforma de tests psicológicos: ${pc.code}\n\nPuedes acceder directamente desde este enlace: ${appUrl}\n\nGracias.`);
                          const mailtoLink = `mailto:${pc.patientEmail || ''}?subject=${subject}&body=${body}`;
                          const therapistName = therapists.find(t => t.id === pc.assignedTherapist)?.name || 'N/A';

                          return (
                              <div key={pc.id} className="border rounded-lg p-4 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
                                  <div>
                                      <h4 className="font-semibold">{pc.patientName}</h4>
                                      <p className="font-code text-primary text-lg">{pc.code}</p>
                                      <div className="text-xs text-muted-foreground flex flex-wrap items-center gap-x-2">
                                          <span>Creado: {new Date(pc.created).toLocaleDateString()}</span>
                                          <span>| Usos: {pc.usedCount}{pc.maxUses ? `/${pc.maxUses}` : ''}</span>
                                          <span>| Expira: {pc.expiry ? new Date(pc.expiry).toLocaleDateString() : 'Nunca'}</span>
                                          {user.role === 'supervisor' && (
                                              <span className="inline-flex items-center gap-1">| <UserIcon className="h-3 w-3" /> {therapistName}</span>
                                          )}
                                      </div>
                                  </div>
                                  <div className="flex items-center gap-2 flex-wrap">
                                      <Button variant="outline" size="sm" onClick={() => handleOpenEditDialog(pc)}>
                                        <Edit className="mr-2 h-4 w-4" /> Editar
                                      </Button>
                                      <Button variant="outline" size="sm" onClick={() => copyToClipboard(pc.code)}>
                                          <Copy className="mr-2 h-4 w-4" /> Copiar
                                      </Button>
                                      <a href={mailtoLink} target="_blank" rel="noopener noreferrer">
                                          <Button variant="outline" size="sm">
                                              <Mail className="mr-2 h-4 w-4" /> Compartir
                                          </Button>
                                      </a>
                                       <AlertDialog>
                                          <AlertDialogTrigger asChild>
                                              <Button variant="destructive" size="sm" disabled={isLoading}><Trash2 className="mr-2 h-4 w-4"/>Eliminar</Button>
                                          </AlertDialogTrigger>
                                          <AlertDialogContent>
                                              <AlertDialogHeader>
                                                  <AlertDialogTitle>¿Confirmar eliminación?</AlertDialogTitle>
                                                  <AlertDialogDescription>Se eliminará el código de acceso para {pc.patientName}. Esto no borrará sus resultados de tests existentes.</AlertDialogDescription>
                                              </AlertDialogHeader>
                                              <AlertDialogFooter>
                                                  <AlertDialogCancel>Cancelar</AlertDialogCancel>
                                                  <AlertDialogAction onClick={() => handleDeletePatientCode(pc.id)}>Eliminar</AlertDialogAction>
                                              </AlertDialogFooter>
                                          </AlertDialogContent>
                                      </AlertDialog>
                                  </div>
                              </div>
                          )
                      })
                  ) : (
                      <p className="text-muted-foreground text-center py-4">No se han generado códigos para pacientes.</p>
                  )}
              </AccordionContent>
            </AccordionItem>
            <AccordionItem value="item-3">
              <AccordionTrigger>Información Clínica</AccordionTrigger>
              <AccordionContent className="pt-4 space-y-6">
                  <div>
                      <Label htmlFor="patient-selector">Seleccionar Paciente</Label>
                      <Select value={selectedPatient} onValueChange={handlePatientSelect}>
                          <SelectTrigger><SelectValue placeholder="Selecciona un paciente..." /></SelectTrigger>
                          <SelectContent>
                              {patientOptions.map(name => <SelectItem key={name} value={name}>{name}</SelectItem>)}
                          </SelectContent>
                      </Select>
                  </div>
                  {selectedPatient && (
                      <div className="space-y-4">
                        <div className="flex justify-between items-center flex-wrap gap-2">
                           <div className="space-y-1">
                              <h4 className="font-semibold">Información Clínica de {selectedPatient}</h4>
                              {user.role === 'supervisor' && selectedPatientTherapistName && (
                                  <p className="text-sm text-muted-foreground flex items-center gap-1"><UserIcon className="h-4 w-4" /> Terapeuta: {selectedPatientTherapistName}</p>
                              )}
                           </div>
                           <Dialog open={isAbsenceDialogOpen} onOpenChange={setIsAbsenceDialogOpen}>
                              <DialogTrigger asChild>
                                 <Button variant="outline"><CalendarOff className="mr-2 h-4 w-4" /> Registrar Inasistencia</Button>
                              </DialogTrigger>
                              <DialogContent className="sm:max-w-[425px]">
                                  <DialogHeader>
                                      <DialogTitle>Registrar Inasistencia para {selectedPatient}</DialogTitle>
                                  </DialogHeader>
                                  <div className="grid gap-4 py-4">
                                      <div className="grid grid-cols-4 items-center gap-4">
                                          <Label htmlFor="absence-date" className="text-right">Fecha</Label>
                                           <Popover>
                                              <PopoverTrigger asChild>
                                                  <Button
                                                      variant={"outline"}
                                                      className={cn(
                                                          "w-[240px] justify-start text-left font-normal col-span-3",
                                                          !absenceDate && "text-muted-foreground"
                                                      )}
                                                  >
                                                      <CalendarIcon className="mr-2 h-4 w-4" />
                                                      {absenceDate ? format(absenceDate, "PPP") : <span>Elige una fecha</span>}
                                                  </Button>
                                              </PopoverTrigger>
                                              <PopoverContent className="w-auto p-0" align="start">
                                                  <Calendar
                                                      mode="single"
                                                      selected={absenceDate}
                                                      onSelect={setAbsenceDate}
                                                      initialFocus
                                                  />
                                              </PopoverContent>
                                          </Popover>
                                      </div>
                                      <div className="grid grid-cols-4 items-center gap-4">
                                          <Label htmlFor="absence-reason" className="text-right">Motivo</Label>
                                          <Select value={absenceReason} onValueChange={setAbsenceReason}>
                                              <SelectTrigger className="col-span-3">
                                                  <SelectValue placeholder="Selecciona un motivo" />
                                              </SelectTrigger>
                                              <SelectContent>
                                                  <SelectItem value="patient_cancelled">Suspendió el paciente</SelectItem>
                                                  <SelectItem value="therapist_cancelled">Suspendió el terapeuta</SelectItem>
                                                  <SelectItem value="no_show">Paciente no llegó y no avisó</SelectItem>
                                              </SelectContent>
                                          </Select>
                                      </div>
                                       <div className="grid grid-cols-4 items-center gap-4">
                                          <Label htmlFor="absence-notes" className="text-right">Notas</Label>
                                          <Textarea id="absence-notes" value={absenceNotes} onChange={e => setAbsenceNotes(e.target.value)} className="col-span-3" placeholder="(Opcional)"/>
                                      </div>
                                  </div>
                                  <DialogFooter>
                                      <DialogClose asChild><Button variant="ghost">Cancelar</Button></DialogClose>
                                      <Button onClick={handleSaveAbsence} disabled={isLoading}>{isLoading ? 'Guardando...' : 'Guardar Inasistencia'}</Button>
                                  </DialogFooter>
                              </DialogContent>
                          </Dialog>
                        </div>
                         <form onSubmit={handleClinicalInfoSave} className="space-y-4">
                          <div>
                            <Label htmlFor="work-objectives">Objetivos de Trabajo</Label>
                            <Textarea id="work-objectives" value={currentClinicalInfo.workObjectives || ''} onChange={e => handleClinicalInfoChange('workObjectives', e.target.value)} />
                          </div>
                          <div>
                            <Label htmlFor="diagnosis">Diagnóstico</Label>
                            <Textarea id="diagnosis" value={currentClinicalInfo.diagnosis || ''} onChange={e => handleClinicalInfoChange('diagnosis', e.target.value)} />
                          </div>
                          <div>
                            <Label htmlFor="clinical-notes">Notas Clínicas</Label>
                            <Textarea id="clinical-notes" value={currentClinicalInfo.notes || ''} onChange={e => handleClinicalInfoChange('notes', e.target.value)} />
                          </div>
                          <div>
                              <Label htmlFor="weekly-tasks">Tareas Semanales (para el paciente)</Label>
                              <Textarea id="weekly-tasks" value={currentClinicalInfo.weeklyTasks || ''} onChange={e => handleClinicalInfoChange('weeklyTasks', e.target.value)} placeholder="Describe las tareas para el paciente..."/>
                          </div>
                          <div>
                              <Label htmlFor="session-material-link">Enlace a Material de Sesión (para el paciente)</Label>
                              <Input id="session-material-link" value={currentClinicalInfo.sessionMaterialLink || ''} onChange={e => handleClinicalInfoChange('sessionMaterialLink', e.target.value)} placeholder="https://docs.google.com/..."/>
                          </div>
                          <div>
                              <Label htmlFor="process-status">Estado del Proceso</Label>
                              <Select value={currentClinicalInfo.processStatus || 'en-proceso'} onValueChange={value => handleClinicalInfoChange('processStatus', value as 'en-proceso' | 'proceso-cerrado')}>
                                  <SelectTrigger><SelectValue /></SelectTrigger>
                                  <SelectContent>
                                      <SelectItem value="en-proceso">En Proceso</SelectItem>
                                      <SelectItem value="proceso-cerrado">Proceso Cerrado</SelectItem>
                                  </SelectContent>
                              </Select>
                          </div>
                          <Button type="submit" disabled={isLoading}>{isLoading ? 'Guardando...' : 'Guardar Información'}</Button>
                         </form>
                      </div>
                  )}
              </AccordionContent>
            </AccordionItem>
            <AccordionItem value="item-4">
              <AccordionTrigger>
                <span className="flex items-center">
                  Programar Recordatorios
                  {pendingReminders.length > 0 && <span className="ml-2 flex h-5 w-5 items-center justify-center rounded-full bg-destructive text-destructive-foreground text-xs">{pendingReminders.length}</span>}
                </span>
              </AccordionTrigger>
              <AccordionContent className="pt-4 space-y-6">
                <form onSubmit={handleScheduleReminder} className="space-y-4 p-4 border rounded-lg">
                  <h4 className="font-semibold">Nuevo Recordatorio</h4>
                  <div className="grid md:grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="reminder-patient">Paciente</Label>
                      <Select value={reminderPatient} onValueChange={setReminderPatient}>
                        <SelectTrigger><SelectValue placeholder="Seleccionar paciente..." /></SelectTrigger>
                        <SelectContent>
                          {patientOptions.map(name => <SelectItem key={name} value={name}>{name}</SelectItem>)}
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <Label htmlFor="reminder-date">Fecha de Envío</Label>
                      <Input id="reminder-date" type="date" value={reminderDate} onChange={e => setReminderDate(e.target.value)} />
                    </div>
                  </div>
                  <Button type="submit"><Send className="mr-2 h-4 w-4" /> Programar</Button>
                </form>
                <div>
                  <h4 className="font-semibold text-destructive flex items-center gap-2"><BellRing />Recordatorios Pendientes</h4>
                  <div className="space-y-2 mt-2">
                    {pendingReminders.length > 0 ? (
                      pendingReminders.map(r => (
                        <div key={r.id} className="border rounded-lg p-4 flex justify-between items-center bg-destructive/5 border-destructive/20">
                          <div>
                            <p>Enviar recordatorio a <strong>{r.patientName}</strong></p>
                            <p className="text-sm text-muted-foreground">Programado para: {new Date(r.sendDate).toLocaleDateString()}</p>
                          </div>
                          <AlertDialog>
                            <AlertDialogTrigger asChild>
                              <Button variant="outline">Marcar como Enviado</Button>
                            </AlertDialogTrigger>
                            <AlertDialogContent>
                              <AlertDialogHeader>
                                <AlertDialogTitle>¿Confirmar envío?</AlertDialogTitle>
                                <AlertDialogDescription>
                                  Esto marcará el recordatorio como enviado y lo quitará de la lista de pendientes. Esta acción es solo para seguimiento interno y no envía un correo real.
                                </AlertDialogDescription>
                              </AlertDialogHeader>
                              <AlertDialogFooter>
                                <AlertDialogCancel>Cancelar</AlertDialogCancel>
                                <AlertDialogAction onClick={() => markReminderAsSent(r.id)}>Confirmar</AlertDialogAction>
                              </AlertDialogFooter>
                            </AlertDialogContent>
                          </AlertDialog>
                        </div>
                      ))
                    ) : <p className="text-muted-foreground text-center py-4">No hay recordatorios pendientes.</p>}
                  </div>
                </div>
              </AccordionContent>
            </AccordionItem>
            <AccordionItem value="item-5">
              <AccordionTrigger>Unificar Casos de Pacientes</AccordionTrigger>
              <AccordionContent className="pt-4 space-y-6">
                <div className="p-4 border border-destructive/50 rounded-lg bg-destructive/5">
                  <h4 className="font-semibold text-destructive">¡Atención! Acción Destructiva</h4>
                  <p className="text-sm text-destructive/90 mt-1">
                    Esta herramienta se usa para combinar dos perfiles de paciente duplicados en uno solo.
                    Se transferirán todos los datos (resultados, notas) del paciente de origen al de destino.
                    El paciente de origen y su código de acceso serán **eliminados permanentemente**.
                    Usa esta función con extrema precaución.
                  </p>
                </div>
                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="source-patient">Paciente de Origen (a eliminar)</Label>
                    <Select value={sourcePatient} onValueChange={setSourcePatient}>
                      <SelectTrigger><SelectValue placeholder="Seleccionar paciente..." /></SelectTrigger>
                      <SelectContent>
                        {patientOptions.map(name => <SelectItem key={`source-${name}`} value={name}>{name}</SelectItem>)}
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label htmlFor="target-patient">Paciente de Destino (a conservar)</Label>
                    <Select value={targetPatient} onValueChange={setTargetPatient}>
                      <SelectTrigger><SelectValue placeholder="Seleccionar paciente..." /></SelectTrigger>
                      <SelectContent>
                        {patientOptions.filter(name => name !== sourcePatient).map(name => <SelectItem key={`target-${name}`} value={name}>{name}</SelectItem>)}
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <AlertDialog>
                  <AlertDialogTrigger asChild>
                    <Button variant="destructive" disabled={!sourcePatient || !targetPatient || sourcePatient === targetPatient || isLoading}>
                      Unificar Casos
                    </Button>
                  </AlertDialogTrigger>
                  <AlertDialogContent>
                    <AlertDialogHeader>
                      <AlertDialogTitle>¿Estás absolutamente seguro?</AlertDialogTitle>
                      <AlertDialogDescription>
                        Vas a unificar a <span className="font-bold">{sourcePatient}</span> en <span className="font-bold">{targetPatient}</span>.
                        Todos los datos de <span className="font-bold">{sourcePatient}</span> se transferirán y su perfil será eliminado permanentemente.
                        Esta acción no se puede deshacer.
                      </AlertDialogDescription>
                    </AlertDialogHeader>
                    <AlertDialogFooter>
                      <AlertDialogCancel>Cancelar</AlertDialogCancel>
                      <AlertDialogAction onClick={handleMergeCases} disabled={isLoading}>
                        {isLoading ? 'Unificando...' : 'Sí, unificar casos'}
                      </AlertDialogAction>
                    </AlertDialogFooter>
                  </AlertDialogContent>
                </AlertDialog>
              </AccordionContent>
            </AccordionItem>
          </Accordion>
        </CardContent>
      </Card>
      
      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent className="sm:max-w-2xl">
          <DialogHeader>
            <DialogTitle>Editar Paciente: {editingPatient?.patientName}</DialogTitle>
          </DialogHeader>
          <div className="grid gap-4 py-4">
              <div className="grid grid-cols-2 gap-4">
                  <div>
                      <Label htmlFor="edit-patient-name">Nombre del Paciente</Label>
                      <Input id="edit-patient-name" value={editFormState.patientName || ''} onChange={e => handleEditFormChange('patientName', e.target.value)} required />
                  </div>
                  <div>
                      <Label htmlFor="edit-patient-code">Código de Acceso</Label>
                      <Input id="edit-patient-code" value={editFormState.code || ''} onChange={e => handleEditFormChange('code', e.target.value)} required className="font-code uppercase" />
                  </div>
              </div>
               <div>
                  <Label htmlFor="edit-patient-email">Email del Paciente (Opcional)</Label>
                  <Input id="edit-patient-email" type="email" value={editFormState.patientEmail || ''} onChange={e => handleEditFormChange('patientEmail', e.target.value)} />
              </div>
              <div>
                <Label>Tests Asignados</Label>
                <div className="p-4 border rounded-lg bg-secondary/30 grid grid-cols-2 md:grid-cols-3 gap-3">
                  {allTests.map(test => (
                      <div key={`edit-test-${test.id}`} className="flex items-center space-x-2">
                         <Checkbox id={`edit-test-${test.id}`} checked={!!editFormState.assignedTests?.[test.id]} onCheckedChange={checked => handleEditAssignedTestChange(test.id, !!checked)}/>
                         <label htmlFor={`edit-test-${test.id}`} className="text-sm font-medium leading-none">{test.name}</label>
                      </div>
                  ))}
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                  <div>
                      <Label htmlFor="edit-expiry">Válido hasta (Opcional)</Label>
                      <Input id="edit-expiry" type="date" value={editFormState.expiry || ''} onChange={e => handleEditFormChange('expiry', e.target.value)} />
                  </div>
                  <div>
                      <Label htmlFor="edit-max-uses">Máximo de Usos (Opcional)</Label>
                      <Input id="edit-max-uses" type="number" min="1" value={editFormState.maxUses ?? ''} onChange={e => handleEditFormChange('maxUses', e.target.value)} />
                  </div>
              </div>
          </div>
          <DialogFooter>
            <Button variant="ghost" onClick={() => setIsEditDialogOpen(false)}>Cancelar</Button>
            <Button onClick={handleUpdatePatientCode} disabled={isLoading}>{isLoading ? 'Guardando...' : 'Guardar Cambios'}</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}
