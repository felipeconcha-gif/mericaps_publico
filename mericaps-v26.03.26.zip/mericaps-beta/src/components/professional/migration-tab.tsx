
"use client";

// This component is obsolete and no longer used.
export function MigrationTab() {
  return null;
}
