'use client';

import { initializeFirebase } from '@/firebase/index';

const { firebaseApp, auth, firestore } = initializeFirebase();

export { firebaseApp, auth, firestore };
