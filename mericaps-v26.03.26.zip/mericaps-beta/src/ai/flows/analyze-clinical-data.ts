'use server';

/**
 * @fileOverview An AI agent for analyzing clinical data and providing summaries of symptoms, treatments, and diagnoses.
 *
 * - analyzeClinicalData - A function that handles the clinical data analysis process.
 * - AnalyzeClinicalDataInput - The input type for the analyzeClinicalData function.
 * - AnalyzeClinicalDataOutput - The return type for the analyzeClinicalData function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const AnalyzeClinicalDataInputSchema = z.object({
  clinicalNotes: z.string().describe('Clinical notes from the therapist.'),
  evaluationResults: z.string().describe('Evaluation results from the psychological tests.'),
});
export type AnalyzeClinicalDataInput = z.infer<typeof AnalyzeClinicalDataInputSchema>;

const AnalyzeClinicalDataOutputSchema = z.object({
  symptomsSummary: z.string().describe('A summary of common symptoms based on the clinical notes and evaluation results.'),
  treatmentsSummary: z.string().describe('A summary of successful treatments based on the clinical notes and evaluation results.'),
  possibleDiagnoses: z.string().describe('Possible diagnoses based on the clinical notes and evaluation results.'),
});
export type AnalyzeClinicalDataOutput = z.infer<typeof AnalyzeClinicalDataOutputSchema>;

export async function analyzeClinicalData(input: AnalyzeClinicalDataInput): Promise<AnalyzeClinicalDataOutput> {
  return analyzeClinicalDataFlow(input);
}

const analyzeClinicalDataPrompt = ai.definePrompt({
  name: 'analyzeClinicalDataPrompt',
  input: {schema: AnalyzeClinicalDataInputSchema},
  output: {schema: AnalyzeClinicalDataOutputSchema},
  prompt: `You are an AI assistant specialized in analyzing clinical data for therapists.

  Based on the anonymized clinical notes and evaluation results provided, generate:

  1. A summary of common symptoms.
  2. A summary of successful treatments.
  3. Possible diagnoses.

  Anonymized Clinical Notes: {{{clinicalNotes}}}
  Anonymized Evaluation Results: {{{evaluationResults}}}

  Ensure the summaries and diagnoses are concise and informative.
  Output the summaries and diagnoses in a format that is easy to read and understand.
  `,
  config: {
    safetySettings: [
      {
        category: 'HARM_CATEGORY_DANGEROUS_CONTENT',
        threshold: 'BLOCK_ONLY_HIGH',
      },
      {
        category: 'HARM_CATEGORY_HARASSMENT',
        threshold: 'BLOCK_ONLY_HIGH',
      },
      {
        category: 'HARM_CATEGORY_HATE_SPEECH',
        threshold: 'BLOCK_ONLY_HIGH',
      },
      {
        category: 'HARM_CATEGORY_SEXUALLY_EXPLICIT',
        threshold: 'BLOCK_ONLY_HIGH',
      },
    ],
  },
});

const anonymizationPrompt = ai.definePrompt({
  name: 'anonymizationPrompt',
  input: { schema: z.object({ text: z.string() }) },
  output: { schema: z.object({ anonymizedText: z.string() }) },
  prompt: `Anonymize the following text by replacing all personal names with a generic placeholder like [PERSONA]. Do not alter the clinical content.

  Text to anonymize:
  {{{text}}}
  `,
  config: { temperature: 0.0 }
});


const analyzeClinicalDataFlow = ai.defineFlow(
  {
    name: 'analyzeClinicalDataFlow',
    inputSchema: AnalyzeClinicalDataInputSchema,
    outputSchema: AnalyzeClinicalDataOutputSchema,
  },
  async input => {
    // Step 1: Anonymize the input data
    const [anonymizedNotes, anonymizedResults] = await Promise.all([
      anonymizationPrompt({ text: input.clinicalNotes }),
      anonymizationPrompt({ text: input.evaluationResults })
    ]);

    const anonymizedInput = {
      clinicalNotes: anonymizedNotes.output?.anonymizedText || input.clinicalNotes,
      evaluationResults: anonymizedResults.output?.anonymizedText || input.evaluationResults,
    };

    // Step 2: Call the main analysis prompt with the anonymized data
    const {output} = await analyzeClinicalDataPrompt(anonymizedInput);
    return output!;
  }
);
