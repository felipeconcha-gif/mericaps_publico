import { config } from 'dotenv';
config();

import '@/ai/flows/analyze-clinical-data.ts';