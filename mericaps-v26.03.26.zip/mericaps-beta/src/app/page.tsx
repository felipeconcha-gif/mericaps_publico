
import AppContent from "@/components/AppContent";

export default function Home() {
  return (
    <AppContent>
      {/* Children passed to AppContent are rendered inside its structure */}
      {/* This maintains the original dashboard layout for the home page */}
    </AppContent>
  );
}
Home.displayName = 'Home';
