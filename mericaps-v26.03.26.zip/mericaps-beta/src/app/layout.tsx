
import type { Metadata } from "next";
import { Inter } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";
import { Copyright, Mail } from 'lucide-react';
import { Alegreya, Source_Code_Pro } from 'next/font/google';
import { cn } from '@/lib/utils';
import { FirebaseClientProvider } from "@/firebase";
import { ThemeProvider } from "@/components/theme-provider";
import { UserManual } from "@/components/UserManual";

const fontInter = Inter({
  subsets: ['latin'],
  variable: '--font-inter',
})

const fontAlegreya = Alegreya({
  subsets: ['latin'],
  weight: ['400', '700'],
  variable: '--font-alegreya',
})

const fontSourceCodePro = Source_Code_Pro({
  subsets: ['latin'],
  variable: '--font-source-code-pro',
})

export const metadata: Metadata = {
  title: "MERICAPS",
  description: "Plataforma para medición rutinaria e investigación de cambio psicoterapéutico.",
  icons: {
    icon: '/favicon.ico',
  },
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="es" className={cn("h-full font-sans", fontInter.variable, fontAlegreya.variable, fontSourceCodePro.variable)} suppressHydrationWarning>
      <body className="h-full antialiased flex flex-col bg-secondary/30">
        <FirebaseClientProvider>
          <ThemeProvider>
            {children}
            
            <footer className="text-center p-4 bg-background border-t space-y-2">
              <div className="flex justify-center items-center gap-x-6 gap-y-2 flex-wrap">
                <div
                  className="inline-flex items-center gap-2 text-sm text-muted-foreground"
                >
                  <Copyright className="h-4 w-4" />
                  <p>MERICAPS, creado por Dr. Felipe Concha, Centro Árbol. © {new Date().getFullYear()}</p>
                </div>
                <a
                  href="mailto:felipeconcha@centroarbol.cl"
                  className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-primary"
                >
                  <Mail className="h-4 w-4" />
                  <span>Contacto</span>
                </a>
                <UserManual />
              </div>
            </footer>
            <Toaster />
          </ThemeProvider>
        </FirebaseClientProvider>
      </body>
    </html>
  );
}
