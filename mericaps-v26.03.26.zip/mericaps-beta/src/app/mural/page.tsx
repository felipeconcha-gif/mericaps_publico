
"use client";

import { useState, useEffect, useMemo } from 'react';
import { Button } from "@/components/ui/button";
import Link from "next/link";
import { ArrowLeft, PlusCircle, Edit, Trash2, Construction } from "lucide-react";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { cn } from "@/lib/utils";
import { useUser, useFirestore, useCollection, useMemoFirebase } from '@/firebase';
import { collection } from 'firebase/firestore';
import type { User as AppUser, Supervisor, Therapist } from '@/lib/definitions';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import useLocalStorage from '@/hooks/use-local-storage';
import { Badge } from '@/components/ui/badge';
import { AlertDialog, AlertDialogAction, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from '@/components/ui/alert-dialog';


// --- Types ---
type ContentItem = {
    id: string;
    title: string;
    description: string;
    createdDate: string; // ISO date string
};

type MuralContent = {
    'anuncios': ContentItem[];
    'normativa-nacional': ContentItem[];
    'normativa-interna': ContentItem[];
    'cursos': ContentItem[];
    'recursos': ContentItem[];
};

// --- Initial Data ---
const initialBannerItems: ContentItem[] = [
    { id: 'normativas-ley', title: 'Nueva Ley de Salud Mental en Chile', description: 'Conoce los detalles de la nueva normativa que rige la salud mental en el país.', createdDate: new Date('2024-05-20T10:00:00Z').toISOString() },
    { id: 'clip-publicacion', title: 'Última publicación de CLIP', description: 'Revisa el nuevo paper sobre eficacia terapéutica en la región.', createdDate: new Date('2024-05-18T11:00:00Z').toISOString() },
    { id: 'guia-clinica', title: 'Guía Clínica para el manejo de la Ansiedad', description: 'Se ha publicado una nueva guía con recomendaciones actualizadas.', createdDate: new Date('2024-05-15T12:00:00Z').toISOString() },
];

const initialMuralContent: MuralContent = {
    'anuncios': [
        { id: 'anc-1', title: '¡Bienvenido al nuevo Mural!', description: 'Este espacio está diseñado para compartir noticias, normativas y recursos relevantes para nuestra comunidad profesional.', createdDate: new Date('2024-05-22T09:00:00Z').toISOString()},
    ],
    'normativa-nacional': [
        { id: 'nac-1', title: 'Ley 21.331 sobre Salud Mental', description: 'Análisis detallado de la ley que reconoce y protege los derechos de las personas en la atención de salud mental.', createdDate: new Date('2024-05-01T10:00:00Z').toISOString()},
        { id: 'nac-2', title: 'Guía Clínica GES para Depresión', description: 'Documento oficial con las garantías explícitas en salud para el tratamiento de la depresión en personas de 15 años y más.', createdDate: new Date('2024-04-15T14:00:00Z').toISOString()},
    ],
    'normativa-interna': [
        { id: 'int-1', title: 'Protocolo de Consentimiento Informado', description: 'Pautas actualizadas para la obtención del consentimiento informado en atenciones presenciales y remotas.', createdDate: new Date('2024-05-02T09:00:00Z').toISOString()},
    ],
    'cursos': [
        { id: 'cur-1', title: 'Formación en Terapia Sistémica Breve', description: 'Inscripciones abiertas para el ciclo de formación continua. Inicia en Agosto.', createdDate: new Date('2024-05-10T18:00:00Z').toISOString()},
        { id: 'cur-2', title: 'Workshop: Herramientas de Mindfulness en la Práctica Clínica', description: 'Taller intensivo de fin de semana. Cupos limitados.', createdDate: new Date('2024-04-20T11:00:00Z').toISOString()},
    ],
    'recursos': [
        { id: 'rec-1', title: 'Banco de Escalas y Cuestionarios', description: 'Acceso a una selección de instrumentos de evaluación validados para uso clínico.', createdDate: new Date('2024-03-05T16:00:00Z').toISOString()},
    ],
};


export default function MuralPage() {
  const { user: firebaseUser, isUserLoading } = useUser();
  const firestore = useFirestore();
  const [currentUser, setCurrentUser] = useState<AppUser | null>(null);

  const { data: supervisors = [], isLoading: supervisorsLoading } = useCollection<Supervisor>(
    useMemoFirebase(() => firestore ? collection(firestore, 'supervisors') : null, [firestore])
  );
  const { data: therapists = [], isLoading: therapistsLoading } = useCollection<Therapist>(
    useMemoFirebase(() => firestore ? collection(firestore, 'therapists') : null, [firestore])
  );

  const [activeTab, setActiveTab] = useState('anuncios');
  const [currentBannerIndex, setCurrentBannerIndex] = useState(0);

  // --- State for dynamic content ---
  const [bannerItems, setBannerItems] = useState<ContentItem[]>(initialBannerItems);
  const [content, setContent] = useState<MuralContent>(initialMuralContent);

  // --- Form state for adding/editing content ---
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [editingItem, setEditingItem] = useState<ContentItem | null>(null);
  const [editingSection, setEditingSection] = useState<keyof MuralContent | 'banner' | null>(null);
  const [formTitle, setFormTitle] = useState('');
  const [formDescription, setFormDescription] = useState('');

  // --- Notification State ---
  const [sectionLastVisited, setSectionLastVisited] = useLocalStorage<Record<string, string>>(
    'muralSectionLastVisited',
    {}
  );
  const [notifications, setNotifications] = useState<Record<string, number>>({});
  const [showConstructionNotice, setShowConstructionNotice] = useState(true);


  // Effect to determine user role
  useEffect(() => {
    if (firebaseUser && supervisors && therapists) {
      const supervisor = supervisors.find(s => s.id === firebaseUser.uid);
      if (supervisor) {
        setCurrentUser({ id: firebaseUser.uid, role: 'supervisor', name: supervisor.name, data: supervisor });
        return;
      }
      
      const therapist = therapists.find(t => t.id === firebaseUser.uid);
      if (therapist) {
        setCurrentUser({ id: firebaseUser.uid, role: 'therapist', name: therapist.name, data: therapist });
        return;
      }

      setCurrentUser({
        id: firebaseUser.uid,
        role: 'admin',
        name: firebaseUser.email || 'Administrador',
        data: { id: 'admin', name: 'Admin' }
      });

    } else if (!isUserLoading && !supervisorsLoading && !therapistsLoading) {
        setCurrentUser(null);
    }
  }, [firebaseUser, isUserLoading, supervisors, therapists, supervisorsLoading, therapistsLoading]);


  // Effect for banner auto-scrolling
  useEffect(() => {
    if (bannerItems.length === 0) return;
    const timer = setInterval(() => {
      setCurrentBannerIndex(prevIndex => (prevIndex + 1) % bannerItems.length);
    }, 3000); // Changes every 3 seconds
    return () => clearInterval(timer);
  }, [bannerItems.length]);
  
  // Effect to calculate notifications
  useEffect(() => {
      const newNotifications: Record<string, number> = {};
      
      // Check main content sections
      Object.entries(content).forEach(([sectionKey, items]) => {
          const lastVisit = sectionLastVisited[sectionKey] ? new Date(sectionLastVisited[sectionKey]) : new Date(0);
          const newCount = items.filter(item => new Date(item.createdDate) > lastVisit).length;
          if (newCount > 0) {
              newNotifications[sectionKey] = newCount;
          }
      });
      
      // Check banner items and add their notifications to the 'anuncios' section
      const anunciosLastVisit = sectionLastVisited['anuncios'] ? new Date(sectionLastVisited['anuncios']) : new Date(0);
      const newBannerCount = bannerItems.filter(item => new Date(item.createdDate) > anunciosLastVisit).length;
      if (newBannerCount > 0) {
          newNotifications['anuncios'] = (newNotifications['anuncios'] || 0) + newBannerCount;
      }

      setNotifications(newNotifications);
  }, [content, bannerItems, sectionLastVisited]);

  const handleTabClick = (tab: string) => {
      setActiveTab(tab);
      // Update the last visited time for this tab to now, clearing the notification
      setSectionLastVisited(prev => ({
          ...prev,
          [tab]: new Date().toISOString()
      }));
  };

  const handleOpenForm = (item: ContentItem | null, section: keyof MuralContent | 'banner') => {
    setEditingItem(item);
    setEditingSection(section);
    if (item) {
        setFormTitle(item.title);
        setFormDescription(item.description);
    } else {
        setFormTitle('');
        setFormDescription('');
    }
    setIsFormOpen(true);
  };

  const handleFormSubmit = () => {
    if (!formTitle || !formDescription || !editingSection) return;

    const newItem: ContentItem = {
        id: editingItem ? editingItem.id : `item-${Date.now()}`,
        title: formTitle,
        description: formDescription,
        createdDate: new Date().toISOString(), // Always set new date for new items or use current for edits
    };

    if (editingSection === 'banner') {
        if (editingItem) {
            setBannerItems(bannerItems.map(item => item.id === editingItem.id ? { ...newItem, createdDate: item.createdDate } : item));
        } else {
            setBannerItems([newItem, ...bannerItems]);
        }
    } else {
        setContent(prevContent => {
            const sectionContent = prevContent[editingSection as keyof MuralContent];
            let updatedSectionContent;
            if (editingItem) {
                updatedSectionContent = sectionContent.map(i => i.id === editingItem.id ? { ...newItem, createdDate: i.createdDate } : i);
            } else {
                updatedSectionContent = [newItem, ...sectionContent];
            }
            return {
                ...prevContent,
                [editingSection as keyof MuralContent]: updatedSectionContent
            };
        });
    }
    setIsFormOpen(false);
    setEditingItem(null);
    setEditingSection(null);
  };

  const handleDeleteItem = (itemId: string, section: keyof MuralContent | 'banner') => {
     if (section === 'banner') {
        setBannerItems(bannerItems.filter(item => item.id !== itemId));
        if (bannerItems.length <= 1) setCurrentBannerIndex(0);
    } else {
        setContent(prevContent => ({
            ...prevContent,
            [section as keyof MuralContent]: prevContent[section as keyof MuralContent].filter(item => item.id !== itemId)
        }));
    }
  };


  const currentBanner = bannerItems.length > 0 ? bannerItems[currentBannerIndex] : null;
  const isAdminOrSupervisor = currentUser?.role === 'admin' || currentUser?.role === 'supervisor';
  const normativaNotificationCount = (notifications['normativa-nacional'] || 0) + (notifications['normativa-interna'] || 0);

  const renderContentSection = (sectionKey: keyof MuralContent, title: string) => (
    <div>
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold">{title}</h1>
        {isAdminOrSupervisor && (
          <Button onClick={() => handleOpenForm(null, sectionKey)}>
            <PlusCircle className="mr-2 h-4 w-4" /> Nueva Entrada
          </Button>
        )}
      </div>
      <Accordion type="single" collapsible className="w-full space-y-4">
        {content[sectionKey].length > 0 ? (
          content[sectionKey]
          .sort((a, b) => new Date(b.createdDate).getTime() - new Date(a.createdDate).getTime())
          .map(item => (
            <AccordionItem value={item.id} key={item.id} className="border-none">
              <Card className="relative group/item">
                 <AccordionTrigger className="p-6 hover:no-underline text-left w-full">
                    <CardTitle>{item.title}</CardTitle>
                 </AccordionTrigger>
                 <AccordionContent className="px-6 pb-6 pt-0">
                    <p className="text-muted-foreground mb-2">{item.description}</p>
                    <p className="text-xs text-muted-foreground/80">
                        Publicado: {new Date(item.createdDate).toLocaleDateString('es-ES', { year: 'numeric', month: 'long', day: 'numeric' })}
                    </p>
                 </AccordionContent>
                 {isAdminOrSupervisor && (
                    <div className="absolute top-4 right-12 flex gap-2 opacity-0 group-hover/item:opacity-100 transition-opacity">
                      <Button variant="outline" size="icon" className="h-8 w-8" onClick={(e) => { e.stopPropagation(); handleOpenForm(item, sectionKey); }}>
                        <Edit className="h-4 w-4" />
                      </Button>
                      <Button variant="destructive" size="icon" className="h-8 w-8" onClick={(e) => { e.stopPropagation(); handleDeleteItem(item.id, sectionKey); }}>
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  )}
              </Card>
            </AccordionItem>
          ))
        ) : (
          <div className="text-center py-12 text-muted-foreground bg-secondary/30 rounded-lg">
            <p>No hay entradas en esta sección.</p>
          </div>
        )}
      </Accordion>
    </div>
  );

  return (
    <>
      <AlertDialog open={showConstructionNotice} onOpenChange={setShowConstructionNotice}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle className="flex items-center gap-2 text-xl">
              <Construction className="h-6 w-6 text-amber-500" />
              ¡Mural en Construcción!
            </AlertDialogTitle>
            <AlertDialogDescription className="pt-4">
              ¡Hola! Estás viendo una nueva funcionalidad que estamos construyendo.
              <br/><br/>
              Puedes explorar y probar todo lo que ves, pero ten en cuenta que el contenido es de ejemplo y <strong>los cambios que hagas no se guardarán permanentemente</strong>.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogAction onClick={() => setShowConstructionNotice(false)}>¡Entendido!</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
      <main 
        className="flex min-h-screen flex-col p-4 sm:p-8 bg-secondary/20"
        style={{
          backgroundImage: `url('https://images.unsplash.com/photo-1448375240586-882707db888b?auto=format&fit=crop&w=2070&q=80')`,
          backgroundSize: 'cover',
          backgroundPosition: 'center',
          backgroundAttachment: 'fixed',
        }}
      >
        <div className="w-full max-w-6xl mx-auto bg-card/90 backdrop-blur-sm rounded-2xl p-4 sm:p-6 shadow-2xl border">
          <div className="mb-6">
            <Button asChild variant="outline">
              <Link href="/">
                <ArrowLeft className="mr-2 h-4 w-4" />
                Volver al Panel
              </Link>
            </Button>
          </div>
          
          {/* Banner Section */}
          <div className="mb-6 border rounded-lg bg-card/80 text-card-foreground shadow-sm p-6 min-h-[140px] flex flex-col items-center justify-center transition-all duration-500 relative group">
              {currentBanner ? (
                  <div key={currentBanner.id} className="text-center animate-in fade-in">
                      <h2 className="text-2xl font-bold tracking-tight">{currentBanner.title}</h2>
                      <p className="text-muted-foreground mt-2">{currentBanner.description}</p>
                      <p className="text-xs text-muted-foreground/80 mt-2">
                          Publicado: {new Date(currentBanner.createdDate).toLocaleDateString('es-ES', { year: 'numeric', month: 'long', day: 'numeric' })}
                      </p>
                  </div>
              ) : (
                  <div className="text-center">
                       <h2 className="text-2xl font-bold tracking-tight">No hay noticias</h2>
                       <p className="text-muted-foreground mt-2">Agrega una nueva entrada para mostrarla aquí.</p>
                  </div>
              )}
              
               {isAdminOrSupervisor && (
                  <div className="absolute top-2 right-2 flex items-center gap-2">
                      <Button variant="outline" size="sm" onClick={() => handleOpenForm(null, 'banner')}>
                          <PlusCircle className="mr-2 h-4 w-4" /> Nueva Noticia
                      </Button>
                  </div>
               )}

              {isAdminOrSupervisor && currentBanner && (
                   <div className="absolute bottom-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity flex gap-2">
                      <Button variant="outline" size="icon" className="h-8 w-8" onClick={() => handleOpenForm(currentBanner, 'banner')}>
                          <Edit className="h-4 w-4" />
                      </Button>
                      <Button variant="destructive" size="icon" className="h-8 w-8" onClick={() => handleDeleteItem(currentBanner.id, 'banner')}>
                          <Trash2 className="h-4 w-4" />
                      </Button>
                  </div>
              )}
          </div>

          {/* --- Dialog for Adding/Editing Content --- */}
          <Dialog open={isFormOpen} onOpenChange={setIsFormOpen}>
              <DialogContent>
                  <DialogHeader>
                      <DialogTitle>{editingItem ? 'Editar Entrada' : 'Agregar Nueva Entrada'}</DialogTitle>
                  </DialogHeader>
                  <div className="grid gap-4 py-4">
                      <div className="grid grid-cols-4 items-center gap-4">
                          <Label htmlFor="title" className="text-right">Título</Label>
                          <Input id="title" value={formTitle} onChange={(e) => setFormTitle(e.target.value)} className="col-span-3" />
                      </div>
                      <div className="grid grid-cols-4 items-center gap-4">
                          <Label htmlFor="description" className="text-right">Descripción</Label>
                          <Textarea id="description" value={formDescription} onChange={(e) => setFormDescription(e.target.value)} className="col-span-3" />
                      </div>
                  </div>
                  <DialogFooter>
                      <Button type="submit" onClick={handleFormSubmit}>Guardar</Button>
                  </DialogFooter>
              </DialogContent>
          </Dialog>


          <div className="flex flex-1 border rounded-lg bg-card/80 text-card-foreground shadow-sm min-h-[60vh]">
            {/* Sidebar Menu */}
            <nav className="w-1/4 md:w-1/5 border-r p-4">
              <h2 className="text-lg font-bold mb-4">Secciones</h2>
              <ul className="space-y-2">
                <li>
                  <Button 
                    variant={activeTab === 'anuncios' ? 'secondary' : 'ghost'} 
                    className="w-full justify-start relative"
                    onClick={() => handleTabClick('anuncios')}
                  >
                    Anuncios
                    {notifications.anuncios > 0 && (
                      <Badge variant="destructive" className="absolute right-2 top-1/2 -translate-y-1/2 h-5 flex items-center justify-center rounded-full w-5 p-0">{notifications.anuncios}</Badge>
                    )}
                  </Button>
                </li>
                <li>
                  <Accordion type="single" collapsible className="w-full" defaultValue={activeTab.startsWith('normativa') ? 'normativas' : ''}>
                      <AccordionItem value="normativas" className="border-b-0">
                          <AccordionTrigger className={cn("py-2 rounded-md px-3 hover:no-underline relative", {
                              'bg-secondary text-secondary-foreground hover:bg-secondary/80': activeTab.startsWith('normativa')
                          })}>
                              Normativas
                              {normativaNotificationCount > 0 && (
                                  <Badge variant="destructive" className="absolute right-8 top-1/2 -translate-y-1/2 h-5 flex items-center justify-center rounded-full w-5 p-0">
                                      {normativaNotificationCount}
                                  </Badge>
                              )}
                          </AccordionTrigger>
                          <AccordionContent className="pt-2 pl-4">
                              <ul className="space-y-1">
                                  <li>
                                      <Button 
                                      variant={activeTab === 'normativa-nacional' ? 'secondary' : 'ghost'} 
                                      className="w-full justify-start relative"
                                      onClick={() => handleTabClick('normativa-nacional')}
                                      >
                                      Normativa Nacional
                                      {notifications['normativa-nacional'] > 0 && (
                                          <Badge variant="destructive" className="absolute right-2 top-1/2 -translate-y-1/2 h-5 flex items-center justify-center rounded-full w-5 p-0">{notifications['normativa-nacional']}</Badge>
                                      )}
                                      </Button>
                                  </li>
                                  <li>
                                      <Button 
                                      variant={activeTab === 'normativa-interna' ? 'secondary' : 'ghost'} 
                                      className="w-full justify-start relative"
                                      onClick={() => handleTabClick('normativa-interna')}
                                      >
                                      Normativa Interna
                                       {notifications['normativa-interna'] > 0 && (
                                          <Badge variant="destructive" className="absolute right-2 top-1/2 -translate-y-1/2 h-5 flex items-center justify-center rounded-full w-5 p-0">{notifications['normativa-interna']}</Badge>
                                      )}
                                      </Button>
                                  </li>
                              </ul>
                          </AccordionContent>
                      </AccordionItem>
                  </Accordion>
                </li>
                <li>
                  <Button 
                    variant={activeTab === 'cursos' ? 'secondary' : 'ghost'} 
                    className="w-full justify-start relative"
                    onClick={() => handleTabClick('cursos')}
                  >
                    Cursos
                    {notifications.cursos > 0 && (
                      <Badge variant="destructive" className="absolute right-2 top-1/2 -translate-y-1/2 h-5 flex items-center justify-center rounded-full w-5 p-0">{notifications.cursos}</Badge>
                    )}
                  </Button>
                </li>
                <li>
                  <Button 
                    variant={activeTab === 'recursos' ? 'secondary' : 'ghost'} 
                    className="w-full justify-start relative"
                    onClick={() => handleTabClick('recursos')}
                  >
                    Recursos Clínicos
                    {notifications.recursos > 0 && (
                      <Badge variant="destructive" className="absolute right-2 top-1/2 -translate-y-1/2 h-5 flex items-center justify-center rounded-full w-5 p-0">{notifications.recursos}</Badge>
                    )}
                  </Button>
                </li>
              </ul>
            </nav>

            {/* Content Area */}
            <div className="w-3/4 md:w-4/5 p-6">
              {activeTab === 'anuncios' && renderContentSection('anuncios', 'Anuncios Generales')}
              {activeTab === 'normativa-nacional' && renderContentSection('normativa-nacional', 'Normativa Nacional')}
              {activeTab === 'normativa-interna' && renderContentSection('normativa-interna', 'Normativa Interna')}
              {activeTab === 'cursos' && renderContentSection('cursos', 'Cursos y Capacitaciones')}
              {activeTab === 'recursos' && renderContentSection('recursos', 'Recursos Clínicos')}
            </div>
          </div>
        </div>
      </main>
    </>
  );
}
 

    